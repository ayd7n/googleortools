from __future__ import annotations

import logging
import os
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
import pandas as pd
from flask import Flask, flash, jsonify, redirect, render_template, request, send_file, url_for
from sqlalchemy import inspect, text

# Import database models and helper from src
import sys
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from otocam.web.models import db, Order, BOM, Stock, Furnace, Product, SAGModelMoldCapacity, \
    SAGFurnaceCapacity, FurnaceProductYield, SAGMOQ, MaterialArrival, \
    MandatoryDummyModel, NearSAGOpening, FarSAGOpening, InitialFurnaceModelState, \
    InitialFurnaceSetupCarry
from otocam.web.db_helper import import_excel_to_db, export_db_to_excel

# Create instance and upload folders
INSTANCE_DIR = ROOT / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)
UPLOAD_DIR = ROOT / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# Configure logging
LOG_FILE = INSTANCE_DIR / "web_app.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("otocam_web")

app = Flask(__name__)
app.secret_key = "otocam_secret_key_for_flash_messages"
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{INSTANCE_DIR / 'otocam.db'}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

# Global solver execution state
solver_state = {
    "status": "idle",       # "idle", "running", "finished"
    "status_step": "",      # "validate", "prepare", "solve", "save"
    "result_status": "",    # "OPTIMAL", "FEASIBLE", "INFEASIBLE", "PRECHECK_ERROR", "FAILED"
    "proc": None,           # Subprocess handle
    "active_excel": None,
}


def find_most_recent_excel() -> Path | None:
    """Find the most recently modified input Excel file in the project folder."""
    excel_files = []
    # Search root folder
    for f in ROOT.glob("*.xlsx"):
        if f.name.startswith("~$") or f.name in ["cikti_plan.xlsx", "sample_input.xlsx"]:
            continue
        excel_files.append(f)
    
    # Also check uploads folder
    for f in UPLOAD_DIR.glob("*.xlsx"):
        if f.name.startswith("~$"):
            continue
        excel_files.append(f)

    # Return most recent, or sample_input.xlsx if nothing else exists
    if excel_files:
        return max(excel_files, key=os.path.getmtime)
    
    sample_file = ROOT / "sample_input.xlsx"
    if sample_file.exists():
        return sample_file
    return None


@app.before_request
def initialize_app():
    """Initial startup: Create tables and auto-load most recent Excel."""
    # Ensure this runs once in active request context
    if not hasattr(app, "_db_initialized"):
        db.create_all()
        most_recent = find_most_recent_excel()
        if most_recent and most_recent.exists():
            try:
                logger.info(f"Otomatik girdi yükleniyor: {most_recent.name}")
                import_excel_to_db(str(most_recent))
                solver_state["active_excel"] = most_recent.name
            except Exception as e:
                logger.error(f"Başlangıç Excel yükleme hatası: {str(e)}")
        app._db_initialized = True


def get_active_excel_name() -> str | None:
    return solver_state["active_excel"]


def get_all_tables_lower() -> set[str]:
    """Helper to return all table names in the database in lowercase, fresh from sqlite_master."""
    try:
        rows = db.session.execute(text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()
        return {r[0].lower() for r in rows}
    except Exception as e:
        logger.error(f"Veritabanı tabloları okunurken hata: {str(e)}")
        return set()
    finally:
        db.session.remove()


def has_plan_outputs() -> bool:
    """Check if solver output tables exist in SQLite database."""
    return "output_uretim" in get_all_tables_lower()


def get_plan_summary_metrics() -> dict:
    """Read plan summary metrics from output_planlama_ozet table."""
    metrics = {
        "oem_rate": "-",
        "oyc_rate": "-",
        "total_net_qty": "-",
        "shifts_count": "-"
    }
    tables = get_all_tables_lower()
    if "output_planlama_ozet" not in tables:
        return metrics

    try:
        rows = db.session.execute(text("SELECT * FROM output_planlama_ozet")).fetchall()
        for row in rows:
            # Row index or columns can vary, let's look at row values
            # Typically has: Metrik, Değer
            k = str(row[1]).strip() if len(row) > 1 else ""
            v = str(row[2]).strip() if len(row) > 2 else ""
            
            if "OEM Sipariş Karşılama Oranı" in k or "OEM Karşılama Oranı" in k:
                metrics["oem_rate"] = v
            elif "OYC Sipariş Karşılama Oranı" in k or "OYC Karşılama Oranı" in k:
                metrics["oyc_rate"] = v
            elif "Toplam Net Üretilen Adet" in k or "Toplam Üretilen" in k or "Net Üretim" in k:
                metrics["total_net_qty"] = v
            elif "Plan Ufku Vardiya Sayısı" in k or "Plan Ufku" in k:
                metrics["shifts_count"] = v.split(" ")[0]
    except Exception as e:
        logger.error(f"Özet metrik okuma hatası: {str(e)}")
    
    # Fallback to counts if empty
    if metrics["shifts_count"] == "-" and "output_uretim" in tables:
        try:
            val = db.session.execute(text("SELECT COUNT(DISTINCT [Vardiya Sıra No]) FROM output_uretim")).scalar()
            if val:
                metrics["shifts_count"] = str(val)
        except Exception:
            pass

    return metrics


# --- CORE ROUTES ---

@app.route("/")
def dashboard():
    return render_template(
        "dashboard.html",
        active_page="dashboard",
        active_excel=get_active_excel_name(),
        has_outputs=has_plan_outputs(),
        metrics=get_plan_summary_metrics()
    )


@app.route("/upload-excel", methods=["POST"])
def upload_excel():
    if "excel_file" not in request.files:
        flash("Yüklenecek dosya seçilmedi!", "danger")
        return redirect(url_for("dashboard"))
    
    file = request.files["excel_file"]
    if file.filename == "":
        flash("Yüklenecek dosya seçilmedi!", "danger")
        return redirect(url_for("dashboard"))

    if file and file.filename.endswith(".xlsx"):
        filepath = UPLOAD_DIR / file.filename
        file.save(filepath)
        try:
            logger.info(f"Yeni Excel yüklendi ve aktarılıyor: {file.filename}")
            import_excel_to_db(str(filepath))
            solver_state["active_excel"] = file.filename
            
            # Clear output tables since new input is loaded
            clear_output_tables()
            
            flash(f"Girdi dosyası başarıyla yüklendi: {file.filename}", "success")
        except Exception as e:
            logger.error(f"Excel içeri aktarma hatası: {str(e)}")
            flash(f"Dosya aktarılırken hata oluştu: {str(e)}", "danger")
    else:
        flash("Sadece .xlsx uzantılı Excel dosyaları desteklenir!", "danger")

    return redirect(url_for("dashboard"))


def clear_output_tables():
    """Drop all output tables from SQLite."""
    try:
        tables_to_drop = []
        rows = db.session.execute(text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()
        for r in rows:
            name = r[0]
            if name.lower().startswith("output_"):
                tables_to_drop.append(name)
        
        if tables_to_drop:
            with db.engine.begin() as conn:
                for table_name in tables_to_drop:
                    conn.execute(text(f"DROP TABLE [{table_name}]"))
            logger.info(f"Eski çıktı tabloları temizlendi: {tables_to_drop}")
    except Exception as e:
        logger.error(f"Eski çıktı tablolarını temizleme hatası: {str(e)}")
    finally:
        db.session.remove()


# --- GANTT ROUTE ---

@app.route("/gantt")
def gantt_chart():
    if not has_plan_outputs():
        flash("Öncelikle planı çalıştırıp sonuç üretmelisiniz!", "warning")
        return redirect(url_for("dashboard"))

    try:
        # 1. Fetch furnaces list
        furnaces = Furnace.query.all()
        
        # 2. Fetch all chronological shifts from output_uretim or output_firin_kullanim
        shifts_df = pd.read_sql("SELECT DISTINCT Tarih, [Vardiya], [Vardiya Sıra No] FROM output_firin_kullanim ORDER BY [Vardiya Sıra No]", db.engine)
        
        shifts = []
        for _, row in shifts_df.iterrows():
            # Date can be string or datetime
            dt = row["Tarih"]
            if isinstance(dt, str):
                dt = datetime.fromisoformat(dt.split(" ")[0]).date()
            elif isinstance(dt, datetime):
                dt = dt.date()
            
            shifts.append({
                "index": int(row["Vardiya Sıra No"]),
                "date": dt,
                "shift_no": int(row["Vardiya"]),
            })

        # 3. Read raw outputs to map into the cells
        uretim_rows = pd.read_sql("SELECT * FROM output_uretim", db.engine).to_dict(orient="records")
        kullanim_rows = pd.read_sql("SELECT * FROM output_firin_kullanim", db.engine).to_dict(orient="records")
        tables = get_all_tables_lower()
        setup_rows = pd.read_sql("SELECT * FROM output_sag_setup", db.engine).to_dict(orient="records") if "output_sag_setup" in tables else []

        # Create structured nested dict for cells: gantt_data[furnace_name][shift_idx]
        gantt_data = {}
        for f in furnaces:
            gantt_data[f.name] = {}
            for s in shifts:
                gantt_data[f.name][s["index"]] = {
                    "is_open": False,
                    "segments": [],
                    "setup": None,
                    "dummy_count": 0,
                    "optional_dummy_count": 0,
                    "firin_tipi": "",
                    "ana_is_tipi": "",
                    "sag_tur_kapasitesi": 0,
                    "sag_uretim_turu": 0,
                    "sag_kullanilan_vagon": 0,
                    "sag_vagon_kapasitesi": 0,
                    "pres_kapasite_limiti": 0,
                    "pres_kullanilan_kapasite": 0
                }

        # Map Furnace Usage
        for row in kullanim_rows:
            f_name = row.get("Fırın Adı")
            s_idx = row.get("Vardiya Sıra No")
            if f_name in gantt_data and s_idx in gantt_data[f_name]:
                cell = gantt_data[f_name][s_idx]
                cell["is_open"] = (row.get("Fırın Durumu") == "Açık")
                cell["dummy_count"] = int(row.get("SAG Mecburi Maket Sayısı") or 0)
                cell["optional_dummy_count"] = int(row.get("SAG Opsiyonel Maket Sayısı") or 0)
                cell["firin_tipi"] = row.get("Fırın Tipi") or ""
                cell["ana_is_tipi"] = row.get("Ana İş Tipi") or ""
                cell["sag_tur_kapasitesi"] = int(row.get("SAG Tur Kapasitesi") or 0)
                cell["sag_uretim_turu"] = int(row.get("SAG Üretim Turu") or 0)
                cell["sag_kullanilan_vagon"] = int(row.get("SAG Kullanılan Vagon") or 0)
                cell["sag_vagon_kapasitesi"] = int(row.get("SAG Vagon Kapasitesi") or 0)
                cell["pres_kapasite_limiti"] = int(row.get("Pres Kapasite Limiti") or 0)
                cell["pres_kullanilan_kapasite"] = int(row.get("Pres Kullanılan Kapasite") or 0)

        # Map Production segments
        for row in uretim_rows:
            f_name = row.get("Fırın Adı")
            s_idx = row.get("Vardiya Sıra No")
            if f_name in gantt_data and s_idx in gantt_data[f_name]:
                # Find or create segment for this model in the cell
                model = row.get("Model Kodu")
                segments = gantt_data[f_name][s_idx]["segments"]
                
                seg = None
                for s in segments:
                    if s["model_code"] == model:
                        seg = s
                        break
                
                if not seg:
                    seg = {
                        "model_code": model,
                        "model_name": row.get("Model Tanımı") or "",
                        "campaign_id": row.get("Kampanya ID") or "",
                        "mold_count": int(row.get("SAG Kalıp Sayısı") or 0),
                        "turn_count": int(row.get("SAG Üretim Tur Sayısı") or 0),
                        "products": []
                    }
                    segments.append(seg)
                
                seg["products"].append({
                    "code": row.get("Bitmiş Ürün Kodu"),
                    "net_qty": int(row.get("Net Üretim Adedi") or 0),
                    "gross_qty": int(row.get("Brüt Üretim Adedi") or 0),
                    "yield_rate": float(row.get("Randıman") or 0.0),
                })

        # Map Setup events
        for row in setup_rows:
            f_name = row.get("Fırın Adı")
            s_idx = row.get("Vardiya Sıra No")
            if f_name in gantt_data and s_idx in gantt_data[f_name]:
                gantt_data[f_name][s_idx]["setup"] = {
                    "source_model": row.get("Kaynak Model Kodu"),
                    "target_model": row.get("Hedef Model Kodu"),
                    "completed_turns": int(row.get("Tamamlanan Setup Turu") or 0),
                    "remaining_turns": int(row.get("Vardiya Sonu Setup Carry Turu") or 0),
                    "is_completed": (row.get("Setup Tamamlandı mı?") == "Evet"),
                }

        return render_template(
            "gantt.html",
            active_page="gantt",
            active_excel=get_active_excel_name(),
            has_outputs=has_plan_outputs(),
            shifts=shifts,
            furnaces=furnaces,
            gantt_data=gantt_data
        )

    except Exception as e:
        logger.error(f"Gantt derleme hatası: {str(e)}")
        flash(f"Gantt şeması yüklenirken hata oluştu: {str(e)}", "danger")
        return redirect(url_for("dashboard"))


# --- ORDER STATUS ROUTE ---

@app.route("/orders-status")
def orders_status():
    if not has_plan_outputs():
        flash("Öncelikle planı çalıştırıp sonuç üretmelisiniz!", "warning")
        return redirect(url_for("dashboard"))

    try:
        # Read Orders output table
        orders_df = pd.read_sql("SELECT * FROM output_siparis", db.engine)
        
        # Read Allocations
        alloc_df = pd.read_sql("SELECT * FROM output_siparis_karsilama", db.engine)
        allocations_by_order = {}
        for _, row in alloc_df.iterrows():
            oid = row["Sipariş ID"]
            alloc_dict = {
                "Karşılama Tarihi": row["Tarih"],
                "Karşılama Vardiyası": row["Vardiya"],
                "Karşılanan Miktar": row["Karşılanan Miktar"],
                "Karşılama Miktarı": row["Karşılanan Miktar"],
                "Kaynak Tipi": row["Kaynak"],
                "Kaynak ID": row["Karşılama ID"],
                "Zamanında mı?": row["Termin İçi mi?"],
            }
            allocations_by_order.setdefault(oid, []).append(alloc_dict)

        # Read Delay Reasons
        reasons_by_order = {}
        if "output_neden_kodlari" in get_all_tables_lower():
            reasons_df = pd.read_sql("SELECT * FROM output_neden_kodlari", db.engine)
            for _, row in reasons_df.iterrows():
                oid = row.get("Ürün/Model/Sipariş/Bileşen/Fırın")
                if oid:
                    reasons_by_order[oid] = {
                        "Neden Kodu": row.get("Neden Kodu"),
                        "Mesaj": row.get("Mesaj"),
                        "Context": row.get("Context")
                    }

        # Map orders to processed dictionaries for the template
        orders = []
        for _, row in orders_df.iterrows():
            r = row.to_dict()
            
            # Map/calculate keys for the template
            r['Stoktan Karşılanan'] = int(r.get('Başlangıç Stoktan Kapanan') or 0)
            # 'Zamanında Karşılanan' başlangıç stoğundan kapatılanı da içerir; saf üretim
            # katkısını bulmak için stok payını düşürüyoruz (aksi halde stok iki kez sayılır:
            # Stoktan + Üretimle toplamı sipariş miktarını aşardı).
            r['Üretimle Karşılanan'] = (
                int(r.get('Zamanında Karşılanan') or 0)
                + int(r.get('Geç Karşılanan') or 0)
                - r['Stoktan Karşılanan']
            )
            r['Açık Kalan'] = int(r.get('Açık Miktar') or 0)
            
            # Determine status
            qty = int(r.get('Sipariş Miktarı') or 0)
            stok = r['Stoktan Karşılanan']
            uretim = r['Üretimle Karşılanan']
            acik = r['Açık Kalan']
            
            if acik >= qty:
                status = 'Açık'
            elif stok >= qty:
                status = 'Stoktan Kapandı'
            elif acik > 0 or int(r.get('Geç Karşılanan') or 0) > 0:
                status = 'Kısmi Gecikmeli'
            else:
                status = 'Tam Zamanında'
                
            r['Sipariş Durumu'] = status
            r['Ana Neden'] = r.get('Neden Kodu') or ''
            
            orders.append(r)

        pdf = pd.DataFrame(orders)

        # Compute summary stats
        stats = {
            "total_qty": int(pdf["Sipariş Miktarı"].sum()) if not pdf.empty else 0,
            "on_time_qty": int(pdf["Zamanında Karşılanan"].sum()) if not pdf.empty else 0,
            "late_qty": int(pdf["Geç Karşılanan"].sum()) if not pdf.empty else 0,
            "open_qty": int(pdf["Açık Kalan"].sum()) if not pdf.empty else 0,
            "oem_count": int((pdf["Sipariş Türü"] == "OEM").sum()) if not pdf.empty else 0,
            "oyc_count": int((pdf["Sipariş Türü"] == "OYC").sum()) if not pdf.empty else 0,
        }

        return render_template(
            "orders_status.html",
            active_page="orders_status",
            active_excel=get_active_excel_name(),
            has_outputs=has_plan_outputs(),
            orders=orders,
            allocations_by_order=allocations_by_order,
            reason_by_order=reasons_by_order,
            stats=stats,
        )

    except Exception as e:
        logger.error(f"Sipariş durum derleme hatası: {str(e)}")
        flash(f"Siparişlerin son durumu yüklenirken hata oluştu: {str(e)}", "danger")
        return redirect(url_for("dashboard"))


# --- INPUT TABLES CRUD ROUTES ---

# Dynamic schema configs for input forms
INPUT_SHEETS_COLS = {
    "orders": [
        {"id": "product_code", "name": "Bitmiş Ürün Kodu", "type": "select", "choices_from": "Product"},
        {"id": "due_date", "name": "Termin Tarihi", "type": "date"},
        {"id": "quantity", "name": "Sipariş Miktarı", "type": "number"},
        {"id": "order_type", "name": "Sipariş Türü", "type": "select", "choices": ["OEM", "OYC"]},
    ],
    "bom": [
        {"id": "product_code", "name": "Bitmiş Ürün Kodu", "type": "select", "choices_from": "Product"},
        {"id": "component_code", "name": "Bileşen Malzeme Kodu", "type": "text"},
        {"id": "component_type", "name": "Bileşen Malzeme Türü", "type": "select", "choices": ["Malzeme", "Yarımamul"]},
        {"id": "quantity", "name": "Bileşen Miktarı", "type": "number", "step": "0.001"},
    ],
    "stock": [
        {"id": "code", "name": "Kod", "type": "text"},
        {"id": "stock_type", "name": "Stok Türü", "type": "select", "choices": ["Bitmiş Ürün", "Malzeme", "Yarımamul"]},
        {"id": "quantity", "name": "Stok Miktarı", "type": "number"},
    ],
    "furnaces": [
        {"id": "name", "name": "Fırın Adı", "type": "text"},
        {"id": "furnace_type", "name": "Fırın Tipi", "type": "select", "choices": ["SAG", "Pres"]},
    ],
    "products": [
        {"id": "product_code", "name": "Bitmiş Ürün Kodu", "type": "text"},
        {"id": "model_code", "name": "Model Kodu", "type": "text"},
        {"id": "model_name", "name": "Model Tanımı", "type": "text"},
        {"id": "max_stock", "name": "Azami Stok Miktarı", "type": "number"},
    ],
    "sag_model_mold_capacity": [
        {"id": "model_code", "name": "Model Kodu", "type": "select", "choices_from": "Model"},
        {"id": "mold_count", "name": "Kalıp Sayısı", "type": "number"},
    ],
    "sag_furnace_capacity": [
        {"id": "furnace_name", "name": "Fırın Adı", "type": "select", "choices_from": "Furnace"},
        {"id": "turn_count", "name": "Vardiyadaki Tur Sayısı", "type": "number"},
        {"id": "wagon_count", "name": "Vagon Sayısı", "type": "number"},
        {"id": "model_limit", "name": "Vardiyadaki Çalışabileceği Farklı Model Sayısı", "type": "number"},
    ],
    "furnace_product_yield": [
        {"id": "furnace_name", "name": "Fırın Adı", "type": "select", "choices_from": "Furnace"},
        {"id": "product_code", "name": "Bitmiş Ürün Kodu", "type": "select", "choices_from": "Product"},
        {"id": "yield_rate", "name": "Randıman", "type": "number", "step": "0.01"},
    ],
    "sag_moq": [
        {"id": "model_code", "name": "Model Kodu", "type": "select", "choices_from": "Model"},
        {"id": "moq", "name": "MOQ Miktarı", "type": "number"},
    ],
    "material_arrivals": [
        {"id": "material_code", "name": "Malzeme", "type": "text"},
        {"id": "expected_date", "name": "Beklenen Teslimat Tarihi", "type": "date"},
        {"id": "quantity", "name": "Miktar", "type": "number"},
    ],
    "mandatory_dummy_models": [
        {"id": "model_code", "name": "Model", "type": "select", "choices_from": "Model"},
        {"id": "dummy_count", "name": "Mecburi Maket Adeti", "type": "number"},
    ],
    "near_sag_opening": [
        {"id": "date_str", "name": "Tarih", "type": "date"},
        {"id": "shift_1_count", "name": "1. Vardiyada Açılacak SAG Fırın Sayısı", "type": "number"},
        {"id": "shift_2_count", "name": "2. Vardiyada Açılacak SAG Fırın Sayısı", "type": "number"},
        {"id": "shift_3_count", "name": "3. Vardiyada Açılacak SAG Fırın Sayısı", "type": "number"},
    ],
    "far_sag_opening": [
        {"id": "date_str", "name": "Tarih", "type": "date"},
        {"id": "total_count", "name": "3 Vardiya Toplamında Açılacak SAG Fırın Sayısı", "type": "number"},
    ],
    "initial_furnace_model_state": [
        {"id": "furnace_name", "name": "Fırın Adı", "type": "select", "choices_from": "Furnace"},
        {"id": "model_code", "name": "Model Kodu", "type": "select", "choices_from": "Model"},
        {"id": "mold_count", "name": "Bağlı Kalıp Sayısı", "type": "number"},
        {"id": "initial_net_production", "name": "Başlangıç Kampanya Net Üretim Miktarı", "type": "number"},
    ],
    "initial_furnace_setup_carry": [
        {"id": "furnace_name", "name": "Fırın Adı", "type": "select", "choices_from": "Furnace"},
        {"id": "source_model", "name": "Kaynak Model Kodu", "type": "select", "choices_from": "ModelWithYok"},
        {"id": "target_model", "name": "Hedef Model Kodu", "type": "select", "choices_from": "ModelWithYok"},
        {"id": "remaining_turns", "name": "Kalan Setup Carry Turu", "type": "number"},
    ],
}


def get_foreign_key_choices(choice_source: str) -> list[str]:
    """Helper to load lookup lists dynamically from tables."""
    try:
        if choice_source == "Product":
            return [p.product_code for p in Product.query.order_by(Product.product_code).all()]
        elif choice_source == "Model":
            return sorted(list({p.model_code for p in Product.query.all() if p.model_code}))
        elif choice_source == "ModelWithYok":
            return ["Yok"] + sorted(list({p.model_code for p in Product.query.all() if p.model_code}))
        elif choice_source == "Furnace":
            return [f.name for f in Furnace.query.order_by(Furnace.name).all()]
    except Exception as e:
        logger.error(f"İlişkili veri yükleme hatası ({choice_source}): {str(e)}")
    return []


@app.route("/inputs/<sheet_name>")
def view_input_table(sheet_name):
    if sheet_name not in INPUT_SHEETS_COLS:
        flash("Bilinmeyen tablo!", "danger")
        return redirect(url_for("dashboard"))
    
    # Import mapping config to fetch model class
    from otocam.web.db_helper import TABLE_MAPPING
    model_cls = TABLE_MAPPING[sheet_name]["model"]
    query_rows = model_cls.query.all()

    # Convert sqlalchemy objects to dictionaries
    rows = []
    for r in query_rows:
        row_dict = {"id": r.id}
        for col_cfg in INPUT_SHEETS_COLS[sheet_name]:
            row_dict[col_cfg["id"]] = getattr(r, col_cfg["id"])
        rows.append(row_dict)

    # Populate choices dynamically for selects
    cols = []
    for col_cfg in INPUT_SHEETS_COLS[sheet_name]:
        new_col = dict(col_cfg)
        if "choices_from" in col_cfg:
            new_col["choices"] = get_foreign_key_choices(col_cfg["choices_from"])
            new_col["type"] = "select"
        cols.append(new_col)

    title_mapping = {
        "orders": "Siparişler (orders)",
        "bom": "Ürün Ağacı (bom)",
        "stock": "Stoklar (stock)",
        "furnaces": "Fırınlar (furnaces)",
        "products": "Ürün Master (products)",
        "sag_model_mold_capacity": "SAG Model Kalıp Kapasitesi",
        "sag_furnace_capacity": "SAG Fırın Kapasitesi",
        "furnace_product_yield": "Fırın Ürün Randıman",
        "sag_moq": "SAG MOQ",
        "material_arrivals": "Yoldaki Teslimatlar",
        "mandatory_dummy_models": "Mecburi Maketler",
        "near_sag_opening": "Yakın Plan Açılış",
        "far_sag_opening": "Uzak Plan Açılış",
        "initial_furnace_model_state": "Başlangıç Fırın Durumu",
        "initial_furnace_setup_carry": "Başlangıç Setup Carry"
    }

    return render_template(
        "input_table.html",
        active_page=f"input_{sheet_name}",
        active_excel=get_active_excel_name(),
        has_outputs=has_plan_outputs(),
        sheet_name=sheet_name,
        sheet_title=title_mapping.get(sheet_name, sheet_name),
        cols=cols,
        rows=rows
    )


@app.route("/inputs/<sheet_name>/add", methods=["POST"])
def add_input_row(sheet_name):
    if sheet_name not in INPUT_SHEETS_COLS:
        return "Table not found", 404
    
    from otocam.web.db_helper import TABLE_MAPPING
    model_cls = TABLE_MAPPING[sheet_name]["model"]

    params = {}
    for col in INPUT_SHEETS_COLS[sheet_name]:
        val = request.form.get(col["id"])
        # Cast values appropriately
        if col.get("type") == "number":
            val = float(val) if "step" in col else int(val)
        params[col["id"]] = val

    try:
        new_row = model_cls(**params)
        db.session.add(new_row)
        db.session.commit()
        flash("Kayıt başarıyla eklendi.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Kayıt eklenirken hata: {str(e)}", "danger")

    return redirect(url_for("view_input_table", sheet_name=sheet_name))


@app.route("/inputs/<sheet_name>/edit", methods=["POST"])
def edit_input_row(sheet_name):
    if sheet_name not in INPUT_SHEETS_COLS:
        return "Table not found", 404
    
    from otocam.web.db_helper import TABLE_MAPPING
    model_cls = TABLE_MAPPING[sheet_name]["model"]
    row_id = request.form.get("id")

    row = model_cls.query.get(row_id)
    if not row:
        flash("Düzenlenecek kayıt bulunamadı!", "danger")
        return redirect(url_for("view_input_table", sheet_name=sheet_name))

    try:
        for col in INPUT_SHEETS_COLS[sheet_name]:
            val = request.form.get(col["id"])
            if col.get("type") == "number":
                val = float(val) if "step" in col else int(val)
            setattr(row, col["id"], val)

        db.session.commit()
        flash("Kayıt başarıyla güncellendi.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Güncelleme hatası: {str(e)}", "danger")

    return redirect(url_for("view_input_table", sheet_name=sheet_name))


@app.route("/inputs/<sheet_name>/delete", methods=["POST"])
def delete_input_row(sheet_name):
    if sheet_name not in INPUT_SHEETS_COLS:
        return "Table not found", 404
    
    from otocam.web.db_helper import TABLE_MAPPING
    model_cls = TABLE_MAPPING[sheet_name]["model"]
    row_id = request.form.get("id")

    row = model_cls.query.get(row_id)
    if not row:
        flash("Silinecek kayıt bulunamadı!", "danger")
        return redirect(url_for("view_input_table", sheet_name=sheet_name))

    try:
        db.session.delete(row)
        db.session.commit()
        flash("Kayıt silindi.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Silme hatası: {str(e)}", "danger")

    return redirect(url_for("view_input_table", sheet_name=sheet_name))


# --- OUTPUT TABLES VIEW ROUTES ---

@app.route("/outputs/<sheet_name>")
def view_output_table(sheet_name):
    if not has_plan_outputs():
        flash("Öncelikle planı çalıştırıp sonuç üretmelisiniz!", "warning")
        return redirect(url_for("dashboard"))

    db_table_name = f"output_{sheet_name}"
    
    # Get actual table name from database case-insensitively
    actual_table_name = None
    try:
        rows = db.session.execute(text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()
        for r in rows:
            if r[0].lower() == db_table_name.lower():
                actual_table_name = r[0]
                break
    except Exception as e:
        logger.error(f"sqlite_master sorgu hatası: {str(e)}")
    finally:
        db.session.remove()
            
    if not actual_table_name:
        flash(f"Rapor tablosu bulunamadı: {sheet_name}", "danger")
        return redirect(url_for("dashboard"))

    try:
        # Load output data using Pandas
        df = pd.read_sql(f"SELECT * FROM [{actual_table_name}]", db.engine)
        
        # Clean index column if present
        if "index" in df.columns:
            df = df.drop(columns=["index"])
        
        headers = list(df.columns)
        rows = df.to_dict(orient="records")

        title_mapping = {
            "README": " README (Genel Açıklama)",
            "Planlama_Ozet": "Planlama Özeti",
            "Saha_Is_Emri": "Saha İş Emri",
            "Firin_Durum_Ozeti": "Fırın Durum Özeti",
            "Kalip_Degisim_Talimati": "Kalıp Değişim Talimatı",
            "Uretim": "Üretim Kararları Detayı",
            "Firin_Kullanim": "Fırın Vardiya Kullanımı",
            "SAG_Setup": "SAG Setup Detayları",
            "LSF12_Sira": "LSF-12 Sıra Takvimi",
            "Kampanya_Carry": "Kampanya Carry",
            "Stok": "Bitmiş Ürün Stok Akışı",
            "Malzeme_Akisi": "Satın Alınan Malzeme Akışı",
            "Yarimamul_Akisi": "Yarımamul Akışı",
            "Vardiya_Uyarilari": "Vardiya Uyarıları",
            "Darbogazlar": "Darboğaz Uyarıları",
            "Neden_Kodlari": "Neden Kodları Analizi",
            "Carry_Out": "Devreden Carry-Out Kayıtları",
            "Precheck_Hatalari": "Girdi Precheck Hata Raporu"
        }

        return render_template(
            "output_table.html",
            active_page=f"output_{sheet_name}",
            active_excel=get_active_excel_name(),
            has_outputs=has_plan_outputs(),
            sheet_name=sheet_name,
            sheet_title=title_mapping.get(sheet_name, sheet_name),
            headers=headers,
            rows=rows
        )
    except Exception as e:
        logger.error(f"Çıktı tablosu yükleme hatası ({sheet_name}): {str(e)}")
        flash(f"Rapor yüklenirken hata oluştu: {str(e)}", "danger")
        return redirect(url_for("dashboard"))


# --- DOWNLOAD ENDPOINTS ---

@app.route("/download-inputs")
def download_inputs():
    if not get_active_excel_name():
        return "Girdi Excel dosyası yüklü değil", 400
    
    export_path = UPLOAD_DIR / "guncel_girdiler.xlsx"
    try:
        logger.info("Düzenlenmiş girdi verileri Excel'e yazılıyor...")
        export_db_to_excel(str(export_path))
        
        # Build timestamp name
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
        download_name = f"guncel_girdi_{ts}.xlsx"
        
        return send_file(
            export_path,
            as_attachment=True,
            download_name=download_name
        )
    except Exception as e:
        logger.error(f"Girdi dosyası dışa aktarma hatası: {str(e)}")
        return f"Dosya oluşturulurken hata: {str(e)}", 500


@app.route("/download-outputs")
def download_outputs():
    output_file = OUTPUT_DIR / "web_cikti.xlsx"
    if not output_file.exists():
        return "Plan çıktısı bulunamadı", 404

    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    download_name = f"plan_cikti_{ts}.xlsx"
    
    return send_file(
        output_file,
        as_attachment=True,
        download_name=download_name
    )


# --- APPLICATION LOGS ROUTE ---

@app.route("/logs")
def view_logs():
    log_content = ""
    if LOG_FILE.exists():
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                # Read last 300 lines of log to prevent buffer overflow
                lines = f.readlines()
                log_content = "".join(lines[-300:])
        except Exception as e:
            log_content = f"Log okuma hatası: {str(e)}"
    else:
        log_content = "Log dosyası henüz oluşmadı."

    return render_template(
        "logs.html",
        active_page="logs",
        active_excel=get_active_excel_name(),
        has_outputs=has_plan_outputs(),
        log_content=log_content
    )


# --- BACKGROUND SOLVER RUNNER ---

@app.route("/run-status")
def run_status():
    return jsonify({
        "status": solver_state["status"],
        "status_step": solver_state["status_step"],
        "result_status": solver_state["result_status"]
    })


@app.route("/cancel-plan", methods=["POST"])
def cancel_plan():
    if solver_state["status"] == "running" and solver_state["proc"]:
        try:
            logger.info("Plan çözücü işlemi yarıda kesiliyor (iptal ediliyor)...")
            solver_state["proc"].kill()
            solver_state["proc"] = None
            solver_state["status"] = "idle"
            solver_state["status_step"] = ""
            solver_state["result_status"] = "CANCELLED"
            return jsonify({"status": "cancelled"})
        except Exception as e:
            logger.error(f"Solver durdurma hatası: {str(e)}")
            return jsonify({"status": "error", "message": str(e)}), 500
    return jsonify({"status": "not_running"})


@app.route("/run-plan", methods=["POST"])
def run_plan():
    if solver_state["status"] == "running":
        return jsonify({"status": "already_running"}), 400

    data = request.json or {}
    max_days = int(data.get("max_days", 30))
    time_limit = float(data.get("time_limit", 30.0))

    # Initialize runner thread
    solver_state["status"] = "running"
    solver_state["status_step"] = "validate"
    solver_state["result_status"] = ""

    thread = threading.Thread(target=background_solver_task, args=(max_days, time_limit))
    thread.daemon = True
    thread.start()

    return jsonify({"status": "started"})


def background_solver_task(max_days: int, time_limit: float):
    """Background task running solver in a separate subprocess."""
    ctx = app.app_context()
    ctx.push()
    temp_input = UPLOAD_DIR / "web_girdi.xlsx"
    temp_output = OUTPUT_DIR / "web_cikti.xlsx"

    try:
        # Step 1: Export DB back to Excel
        logger.info("Arka plan planlama görevi başladı. Girdiler Excel'e yazılıyor...")
        solver_state["status_step"] = "validate"
        export_db_to_excel(str(temp_input))

        # Clear old output data from DB
        clear_output_tables()

        # Step 2: Trigger subprocess runner
        logger.info("Optimizasyon çözücü subprocess olarak başlatılıyor...")
        solver_state["status_step"] = "solve"

        cmd = [
            "python", "run_plan.py",
            "--input", str(temp_input),
            "--output", str(temp_output),
            "--max-days", str(max_days),
            "--time-limit", str(time_limit),
            "--workers", "8"
        ]

        logger.info(f"Komut: {' '.join(cmd)}")
        # Run subprocess
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace"
        )
        solver_state["proc"] = proc

        # Monitor stdout and log progress
        for line in iter(proc.stdout.readline, ""):
            line_str = line.strip()
            if line_str:
                logger.info(f"[SOLVER] {line_str}")
                if "Stage 1" in line_str:
                    solver_state["status_step"] = "solve"

        proc.stdout.close()
        exit_code = proc.wait()
        solver_state["proc"] = None

        logger.info(f"Planlama çözücü çıkış kodu: {exit_code}")

        if exit_code == 2:
            # Precheck Error
            logger.warning("Precheck hatası bulundu, solver durduruldu.")
            solver_state["status_step"] = "save"
            load_excel_outputs_to_db(temp_output)
            solver_state["result_status"] = "PRECHECK_ERROR"
        elif exit_code == 0:
            # Optimal or Feasible
            logger.info("Planlama başarıyla çözüldü, çıktılar veritabanına yükleniyor...")
            solver_state["status_step"] = "save"
            load_excel_outputs_to_db(temp_output)
            
            # Read Solver Status from Planlama_Ozet
            solver_status = "FEASIBLE"
            try:
                summary_df = pd.read_sql("SELECT * FROM output_planlama_ozet", db.engine)
                for _, r in summary_df.iterrows():
                    # Columns usually: Metrik, Değer
                    k = str(r.iloc[0]).strip()
                    v = str(r.iloc[1]).strip()
                    if "Çalıştırma Durumu" in k or "Durumu" in k:
                        solver_status = v
                        break
            except Exception:
                pass
            
            solver_state["result_status"] = solver_status
        else:
            # Solver failed or unknown exception
            logger.error("Planlama çözümü başarısız oldu!")
            solver_state["result_status"] = "FAILED"

    except Exception as e:
        logger.error(f"Arka plan planlama görevi çöktü: {str(e)}")
        solver_state["result_status"] = "FAILED"
    finally:
        solver_state["status"] = "finished"
        solver_state["status_step"] = ""
        ctx.pop()


def load_excel_outputs_to_db(excel_path: Path):
    """Load all output sheets from resulting Excel file into SQLite dynamically using Pandas."""
    if not excel_path.exists():
        logger.error(f"Çıktı yüklenemedi: {excel_path} bulunamadı!")
        return

    try:
        xls = pd.ExcelFile(excel_path)
        for name in xls.sheet_names:
            df = pd.read_excel(xls, name)
            db_table_name = f"output_{name}"
            
            # Write to database (dynamically creates tables and schema)
            df.to_sql(db_table_name, db.engine, if_exists="replace", index=True)
            logger.info(f"Çıktı tablosu veritabanına aktarıldı: {db_table_name}")
            
    except Exception as e:
        logger.error(f"Çıktı Excel'ini veritabanına yükleme hatası: {str(e)}")


if __name__ == "__main__":
    logger.info("Otocam Web Sunucusu başlatılıyor: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
