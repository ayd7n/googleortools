"""MOQ gerçek kuralını test eder: bir model unbind edildiğinde (kampanya kapanır)
o ana kadarki campaign_net >= MOQ olmalı (devreden muaf kampanya hariç). Ayrıca
ufuk sonunda açık kalan minik kampanyaların kaynağını (bound/net seyri) yazdırır.
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

from ortools.sat.python import cp_model  # noqa: E402

from otocam.calendar import build_calendar  # noqa: E402
from otocam.io import read_input_workbook  # noqa: E402
import otocam.planner as planner_mod  # noqa: E402
from otocam.planner import _CpSatPlanBuilder, PRES_FURNACE  # noqa: E402
from otocam.preprocess import estimate_planning_days, prepare_data  # noqa: E402
from otocam.sample_data import create_sample_workbook  # noqa: E402
from otocam.schemas import PlanOptions  # noqa: E402

PLAN_START = date(2026, 6, 22)


def run(scenario: str):
    root = Path(__file__).resolve().parent
    inp = root / f"{scenario}_moq_input.xlsx"
    create_sample_workbook(inp, PLAN_START, scenario=scenario)
    wb = read_input_workbook(inp)
    days = estimate_planning_days(wb, PLAN_START, 30)
    shifts = build_calendar(PLAN_START, days)
    options = PlanOptions(plan_start=PLAN_START, max_days=30, solver_time_limit=30.0, workers=8)
    prepared = prepare_data(wb, options, shifts)

    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()
    builder._add_stock_constraints()
    builder._add_order_priority_constraints()
    builder._add_unbound_completion_constraints()
    builder._add_component_constraints()
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 30.0
    solver.parameters.num_search_workers = 8
    # Tek aşama yeterli: model kısıtları her aşamada aynı; feasibility yeter.
    status = solver.Solve(builder.model)
    print(f"\n##### {scenario}: build-only solve status={solver.StatusName(status)} shifts={len(shifts)}")
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        print("  cozulmedi, atla")
        return

    viol = 0
    # SAG unbind -> campaign_net(t-1) >= MOQ (muaf devreden hala aktifse istisna)
    for (furnace, model, t), unbound in builder.sag_unbound.items():
        if solver.Value(unbound) != 1 or t == 0:
            continue
        moq = prepared.sag_moq.get(model, 0)
        if moq <= 0:
            continue
        exempt = prepared.initial_campaign_moq_exempt.get((furnace, model), False)
        init_active = solver.Value(builder.initial_campaign_active_sag[(furnace, model, t - 1)]) if exempt else 0
        net_before = solver.Value(builder.campaign_net_sag[(furnace, model, t - 1)])
        if exempt and init_active:
            continue
        if net_before < moq:
            viol += 1
            print(f"  !! SAG MOQ-on-unbind ihlali {furnace}/{model} shift{t}: net_before={net_before} MOQ={moq}")

    # Pres unbind benzeri: active_pres 1->0 gecisi
    for model in prepared.models:
        for shift in shifts:
            t = shift.index
            if t == 0:
                continue
            cur = builder.active_pres.get((model, t))
            prev = builder.active_pres.get((model, t - 1))
            if cur is None or prev is None:
                continue
            if solver.Value(prev) == 1 and solver.Value(cur) == 0:
                moq = planner_mod.PRES_MOQ
                exempt = prepared.initial_campaign_moq_exempt.get((PRES_FURNACE, model), False)
                init_active = solver.Value(builder.initial_campaign_active_pres[(model, t - 1)]) if exempt else 0
                net_before = solver.Value(builder.campaign_net_pres[(model, t - 1)])
                if exempt and init_active:
                    continue
                if net_before < moq:
                    viol += 1
                    print(f"  !! PRES MOQ-on-switch ihlali {model} shift{t}: net_before={net_before} MOQ={moq}")

    print(f"  unbind/switch MOQ ihlali sayisi: {viol}")

    # Ufuk sonu acik minik kampanyalarin seyri
    final = shifts[-1].index
    print("  -- ufuk sonu acik SAG kampanyalari (bound modeller) --")
    for furnace in prepared.sag_furnaces:
        for model in builder._compatible_models_for_furnace(furnace):
            key = (furnace, model, final)
            if key not in builder.bound_sag:
                continue
            if solver.Value(builder.bound_sag[key]) != 1:
                continue
            net = solver.Value(builder.campaign_net_sag[key])
            moq = prepared.sag_moq.get(model, 0)
            if net < moq:
                # bound seyri
                trace = []
                for s in shifts:
                    b = solver.Value(builder.bound_sag[(furnace, model, s.index)])
                    cn = solver.Value(builder.campaign_net_sag[(furnace, model, s.index)])
                    trace.append(f"{s.index}:b{b}n{cn}")
                print(f"    {furnace}/{model} final_net={net} MOQ={moq} | " + " ".join(trace[-8:]))


for sc in ("base", "stress"):
    run(sc)
