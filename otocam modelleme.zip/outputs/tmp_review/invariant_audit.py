"""Uçtan uca invariant denetimi: base + stress senaryolarını çözer ve
çıktı sayfalarını iş kurallarına karşı doğrular. Hiçbir kurala güvenmeden
çıktının kendi içinde tutarlı + sınırlar içinde olduğunu kontrol eder.
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))

import pandas as pd  # noqa: E402

from otocam.calendar import build_calendar  # noqa: E402
from otocam.io import read_input_workbook  # noqa: E402
from otocam.planner import solve_plan  # noqa: E402
from otocam.preprocess import estimate_planning_days, prepare_data  # noqa: E402
from otocam.sample_data import create_sample_workbook  # noqa: E402
from otocam.schemas import PlanOptions  # noqa: E402
from otocam.validation import validate_workbook  # noqa: E402

PLAN_START = date(2026, 6, 22)
violations: list[str] = []


def check(cond: bool, msg: str) -> None:
    if not cond:
        violations.append(msg)


def fnum(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def audit(scenario: str) -> None:
    root = Path(__file__).resolve().parent
    inp = root / f"{scenario}_audit_input.xlsx"
    create_sample_workbook(inp, PLAN_START, scenario=scenario)
    wb = read_input_workbook(inp)
    days = estimate_planning_days(wb, PLAN_START, 30)
    shifts = build_calendar(PLAN_START, days)
    options = PlanOptions(plan_start=PLAN_START, max_days=30, solver_time_limit=30.0, workers=8)
    issues = validate_workbook(wb, options, shifts)
    check(not issues, f"[{scenario}] precheck {len(issues)} hata verdi: {[i.rule for i in issues][:5]}")
    if issues:
        return
    prepared = prepare_data(wb, options, shifts)
    result = solve_plan(prepared, options)
    print(f"[{scenario}] status={result.status} days={days} shifts={len(shifts)}")
    check(result.status in ("OPTIMAL", "FEASIBLE"), f"[{scenario}] solver durumu {result.status}")
    t = result.tables

    # --- A. SAG kapasite: setup + üretim turu <= tur kapasitesi (açık SAG vardiyaları) ---
    fk = t["Firin_Kullanim"]
    for _, r in fk.iterrows():
        if r.get("Fırın Tipi") != "SAG" or r.get("Fırın Durumu") != "Açık":
            continue
        cap = fnum(r["SAG Tur Kapasitesi"])
        setup = fnum(r["SAG Setup Turu"])
        prod = fnum(r["SAG Üretim Turu"])
        check(setup + prod <= cap + 1e-6,
              f"[{scenario}] SAG tur aşımı {r['Fırın Adı']} {r['Tarih']} V{r['Vardiya']}: setup{setup}+prod{prod}>cap{cap}")
        check(abs((setup + prod) - cap) < 1e-6,
              f"[{scenario}] SAG tur eşitsizliği {r['Fırın Adı']} {r['Tarih']} V{r['Vardiya']}: setup{setup}+prod{prod}!=cap{cap}")
        # Vagon/maket kapasitesi
        wagon = fnum(r["SAG Vagon Kapasitesi"])
        used = (fnum(r["SAG Üretim Kalıbı Sayısı"]) + fnum(r["SAG Setup Kalıbı Sayısı"])
                + fnum(r["SAG Mecburi Maket Sayısı"]) + fnum(r["SAG Opsiyonel Maket Sayısı"]))
        check(used <= wagon + 1e-6,
              f"[{scenario}] SAG vagon aşımı {r['Fırın Adı']} {r['Tarih']} V{r['Vardiya']}: kullanım{used}>vagon{wagon}")

    # --- A2. Pres kapasite ---
    for _, r in fk.iterrows():
        if r.get("Fırın Tipi") == "SAG":
            continue
        check(fnum(r["Pres Kullanılan Kapasite"]) <= fnum(r["Pres Kapasite Limiti"]) + 1e-6,
              f"[{scenario}] Pres aşımı {r['Tarih']} V{r['Vardiya']}: {r['Pres Kullanılan Kapasite']}>{r['Pres Kapasite Limiti']}")

    # --- B. MOQ: Kampanya_Carry satırları "Plan Sonunda Açık" kampanyalardır. MOQ kuralı
    # yalnızca kampanya KAPANIRKEN geçerli; ufuk sonunda hâlâ açık kampanya MOQ altında
    # olabilir (sonraki pencerede devam eder). Bu yüzden burada MOQ dayatılmaz; kapanış
    # üzerindeki MOQ kuralı moq_diag.py ile builder düzeyinde ayrıca doğrulanır. ---
    kc = t["Kampanya_Carry"]
    below = [f"{r['Fırın Adı']}/{r['Model Kodu']} net{fnum(r['Carry-Out Neti'])}<MOQ{fnum(r['MOQ'])}"
             for _, r in kc.iterrows() if fnum(r["Carry-Out Neti"]) < fnum(r["MOQ"])]
    if below:
        print(f"[{scenario}] bilgi: ufuk sonu MOQ-altı açık kampanya (ihlal değil): {below}")

    # --- C. Kampanya_Carry <-> Carry_Out model durumu tutarlılığı ---
    co = t["Carry_Out"]
    co_models = co[co["Kayıt Tipi"] == "Fırın Model Durumu"]
    for _, r in co_models.iterrows():
        match = kc[(kc["Fırın Adı"] == r["Fırın"]) & (kc["Model Kodu"] == r["Kod"])]
        check(not match.empty,
              f"[{scenario}] Carry_Out model {r['Fırın']}/{r['Kod']} Kampanya_Carry'de yok")
        if not match.empty:
            check(fnum(r["Carry-Out Kampanya Neti"]) == fnum(match.iloc[0]["Carry-Out Neti"]),
                  f"[{scenario}] kampanya net uyuşmazlık {r['Fırın']}/{r['Kod']}: "
                  f"{r['Carry-Out Kampanya Neti']} vs {match.iloc[0]['Carry-Out Neti']}")

    # --- D. Yarımamul: stok hiç negatife düşmüyor, kullanım <= başlangıç stoğu ---
    ya = t["Yarimamul_Akisi"]
    for _, r in ya.iterrows():
        check(fnum(r["Vardiya Sonu Stok"]) >= -1e-6,
              f"[{scenario}] negatif yarımamul stok {r['Yarımamul Kodu']} {r['Tarih']} V{r['Vardiya']}: {r['Vardiya Sonu Stok']}")
        check(fnum(r["Kullanılan Miktar"]) <= fnum(r["Vardiya Başı Stok"]) + 1e-6,
              f"[{scenario}] yarımamul aşırı tüketim {r['Yarımamul Kodu']} {r['Tarih']} V{r['Vardiya']}: "
              f"kullanım{r['Kullanılan Miktar']}>başı{r['Vardiya Başı Stok']}")

    # --- E. Sipariş bütünlüğü: zamanında+geç+açık == sipariş miktarı ---
    si = t["Siparis"]
    for _, r in si.iterrows():
        q = fnum(r["Sipariş Miktarı"])
        s = fnum(r["Zamanında Karşılanan"]) + fnum(r["Geç Karşılanan"]) + fnum(r["Açık Miktar"])
        check(abs(q - s) < 1e-6,
              f"[{scenario}] sipariş toplamı tutmuyor {r['Sipariş ID']}: miktar{q} != z+g+a {s}")

    # --- F. Uyarı sayfası kapsama: her açık siparişe OPEN_DEMAND, her geç(açık=0) LATE_CAPACITY ---
    vu = t["Vardiya_Uyarilari"]
    open_ids = {r["Sipariş ID"] for _, r in si.iterrows() if fnum(r["Açık Miktar"]) > 0}
    late_only_ids = {r["Sipariş ID"] for _, r in si.iterrows()
                     if fnum(r["Geç Karşılanan"]) > 0 and fnum(r["Açık Miktar"]) == 0}
    open_warned = set()
    late_warned = set()
    for _, w in vu.iterrows():
        msg = str(w.get("Mesaj", ""))
        if w.get("Neden Kodu") == "OPEN_DEMAND":
            for oid in open_ids:
                if oid in msg:
                    open_warned.add(oid)
        if w.get("Neden Kodu") == "LATE_CAPACITY":
            for oid in late_only_ids:
                if oid in msg:
                    late_warned.add(oid)
    check(open_ids <= open_warned,
          f"[{scenario}] OPEN_DEMAND uyarısı eksik siparişler: {open_ids - open_warned}")
    check(late_only_ids <= late_warned,
          f"[{scenario}] LATE_CAPACITY uyarısı eksik siparişler: {late_only_ids - late_warned}")

    print(f"[{scenario}] açık sipariş={len(open_ids)} geç-only={len(late_only_ids)} "
          f"kampanya={len(kc)} firin_kullanim_satir={len(fk)} yarimamul_satir={len(ya)}")


for sc in ("base", "stress"):
    audit(sc)

print("\n=== SONUC ===")
if violations:
    print(f"{len(violations)} INVARIANT IHLALI:")
    for v in violations:
        print("  -", v)
    sys.exit(1)
else:
    print("Tum invariant'lar gecti. Ihlal yok.")
