document.addEventListener("DOMContentLoaded", () => {
    // 1. Drag and Drop Upload Zone Handler
    const uploadZone = document.getElementById("upload-zone");
    const fileInput = document.getElementById("excel-file-input");

    if (uploadZone && fileInput) {
        uploadZone.addEventListener("click", () => fileInput.click());

        uploadZone.addEventListener("dragover", (e) => {
            e.preventDefault();
            uploadZone.classList.add("dragover");
        });

        uploadZone.addEventListener("dragleave", () => {
            uploadZone.classList.remove("dragover");
        });

        uploadZone.addEventListener("drop", (e) => {
            e.preventDefault();
            uploadZone.classList.remove("dragover");
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                uploadZone.querySelector("p").textContent = e.dataTransfer.files[0].name;
                document.getElementById("upload-form").submit();
            }
        });

        fileInput.addEventListener("change", () => {
            if (fileInput.files.length) {
                uploadZone.querySelector("p").textContent = fileInput.files[0].name;
                document.getElementById("upload-form").submit();
            }
        });
    }

    // 2. Modals Show / Hide
    window.openModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.style.display = "flex";
    };

    window.closeModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) modal.style.display = "none";
    };

    // Close modal on overlay click
    document.querySelectorAll(".modal-overlay").forEach(overlay => {
        overlay.addEventListener("click", (e) => {
            if (e.target === overlay) {
                overlay.style.display = "none";
            }
        });
    });

    // 3. Client-side Search and Pagination for Tables
    window.initTableSearch = function(tableId, searchInputId) {
        const searchInput = document.getElementById(searchInputId);
        const table = document.getElementById(tableId);
        if (!searchInput || !table) return;

        searchInput.addEventListener("input", () => {
            const filter = searchInput.value.toLowerCase();
            const rows = table.querySelectorAll("tbody tr");

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? "" : "none";
            });
        });
    };

    // 4. Solver progress poller
    const runBtn = document.getElementById("run-optimizer-btn");
    const loadingOverlay = document.getElementById("loading-overlay");
    const loadingText = document.getElementById("loading-status-text");
    const loadingTime = document.getElementById("loading-time-text");
    const stopBtn = document.getElementById("stop-optimizer-btn");

    let statusInterval = null;
    let secondsElapsed = 0;
    let timerInterval = null;

    // Saniyeyi "dk:ss" biçiminde gösterir (ör. 125 -> "2:05")
    function formatDuration(totalSeconds) {
        const s = Math.max(0, Math.round(totalSeconds));
        const minutes = Math.floor(s / 60);
        const seconds = s % 60;
        return `${minutes}:${String(seconds).padStart(2, "0")}`;
    }

    if (runBtn) {
        runBtn.addEventListener("click", () => {
            const maxDays = document.getElementById("max-days-select")?.value || 30;
            const timeLimitMinutes = parseFloat(document.getElementById("time-limit-select")?.value) || 1;
            const timeLimit = timeLimitMinutes * 60; // dakika -> saniye (backend saniye bekler)

            loadingOverlay.style.display = "flex";
            loadingText.textContent = "Veriler doğrulanıyor...";
            loadingTime.textContent = `${formatDuration(0)} / ${formatDuration(timeLimit)}`;
            secondsElapsed = 0;

            // Start timer (seçilen süreyi aşmayacak şekilde gösterilir)
            timerInterval = setInterval(() => {
                secondsElapsed++;
                const shown = Math.min(secondsElapsed, timeLimit);
                loadingTime.textContent = `${formatDuration(shown)} / ${formatDuration(timeLimit)}`;
                if (secondsElapsed >= timeLimit) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                }
            }, 1000);

            // Trigger Run
            fetch("/run-plan", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ max_days: maxDays, time_limit: timeLimit })
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === "started") {
                    pollStatus();
                } else {
                    handleSolverFinished(data);
                }
            })
            .catch(err => {
                alert("Plan başlatılırken hata oluştu!");
                resetProgressOverlay();
            });
        });
    }

    if (stopBtn) {
        stopBtn.addEventListener("click", () => {
            fetch("/cancel-plan", { method: "POST" })
            .then(res => res.json())
            .then(data => {
                alert("Plan çözümü durduruldu.");
                resetProgressOverlay();
                window.location.reload();
            })
            .catch(err => {
                alert("Durdurma işlemi başarısız.");
            });
        });
    }

    function pollStatus() {
        statusInterval = setInterval(() => {
            fetch("/run-status")
            .then(res => res.json())
            .then(data => {
                loadingText.textContent = getStatusMessage(data.status_step);
                if (data.status === "finished" || data.status === "idle") {
                    handleSolverFinished(data);
                }
            })
            .catch(() => {
                // Ignore temporary network errors
            });
        }, 1000);
    }

    function getStatusMessage(step) {
        switch (step) {
            case "validate": return "Girdi dosyası doğrulanıyor (Precheck)...";
            case "prepare": return "Veriler solver için optimize ediliyor...";
            case "solve": return "Google OR-Tools CP-SAT çalışıyor (Plan çözülüyor)...";
            case "save": return "Sonuçlar SQLite veritabanına ve çıktı Excel'ine aktarılıyor...";
            default: return "İşleniyor, lütfen bekleyin...";
        }
    }

    function handleSolverFinished(data) {
        resetProgressOverlay();
        if (data.result_status === "PRECHECK_ERROR") {
            alert("Girdi verilerinde hatalar bulundu! Hata listesi yükleniyor.");
            window.location.href = "/outputs/Precheck_Hatalari";
        } else if (data.result_status === "OPTIMAL" || data.result_status === "FEASIBLE") {
            alert(`Planlama başarıyla tamamlandı! Durum: ${data.result_status}`);
            window.location.href = "/gantt";
        } else {
            alert(`Plan çözülemedi! Çözücü Durumu: ${data.result_status || 'HATA'}`);
            window.location.href = "/outputs/Planlama_Ozet";
        }
    }

    function resetProgressOverlay() {
        if (statusInterval) clearInterval(statusInterval);
        if (timerInterval) clearInterval(timerInterval);
        loadingOverlay.style.display = "none";
    }

    // 5. Automatic Dynamic Model Color Mapping
    // Generates a highly vibrant color (HSL) based on model code string
    window.getModelColor = function(modelCode) {
        if (!modelCode || modelCode === "Yok") return "transparent";
        
        let hash = 0;
        for (let i = 0; i < modelCode.length; i++) {
            hash = modelCode.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        const hue = Math.abs(hash) % 360;
        return `hsl(${hue}, 100%, 55%)`;
    };

    // Auto-apply model left-border accent colors in Gantt
    document.querySelectorAll(".gantt-card").forEach(card => {
        const model = card.getAttribute("data-model");
        if (model) {
            const baseColor = window.getModelColor(model);
            card.style.borderLeftColor = baseColor;
        }
    });

    // 6. Sidebar Collapsible Sections
    window.toggleMenuSection = function(sectionId, headerEl) {
        const section = document.getElementById(sectionId);
        if (!section || !headerEl) return;
        
        const isExpanded = section.classList.toggle("expanded");
        headerEl.classList.toggle("expanded", isExpanded);
    };

    // 7. Gantt Chart Interactivity & Filters
    
    // Zoom control
    window.changeZoom = function(level, btnEl) {
        // Toggle active button
        document.querySelectorAll(".gantt-zoom-btn").forEach(btn => btn.classList.remove("active"));
        btnEl.classList.add("active");
        
        const gridContainer = document.getElementById("gantt-grid-container");
        if (!gridContainer) return;
        
        let width = "220px";
        if (level === "compact") width = "150px";
        if (level === "wide") width = "300px";
        
        gridContainer.style.setProperty("--gantt-cell-width", width);
    };

    // Filter furnaces by type (SAG vs Pres)
    window.filterFurnaces = function(type, btnEl) {
        document.querySelectorAll(".gantt-tab-btn").forEach(btn => btn.classList.remove("active"));
        btnEl.classList.add("active");

        const furnaceCells = document.querySelectorAll("[data-furnace-name]");
        const furnaceNames = Array.from(new Set(Array.from(furnaceCells).map(el => el.getAttribute("data-furnace-name"))));
        let visibleRowIndex = 2; // Row 1 is the header row
        
        furnaceNames.forEach(name => {
            const cells = document.querySelectorAll(`[data-furnace-name="${name}"]`);
            if (cells.length === 0) return;
            
            const furnaceType = cells[0].getAttribute("data-furnace-type");
            const shouldShow = (type === "all" || furnaceType === type);
            
            cells.forEach(cell => {
                if (shouldShow) {
                    cell.style.display = "";
                    cell.style.gridRow = visibleRowIndex;
                } else {
                    cell.style.display = "none";
                }
            });
            
            if (shouldShow) {
                visibleRowIndex++;
            }
        });

        // Readjust explicit grid template rows
        const gridContainer = document.getElementById("gantt-grid-container");
        if (gridContainer) {
            gridContainer.style.gridTemplateRows = `50px repeat(${visibleRowIndex - 2}, auto)`;
        }
    };

    // Search model code and highlight
    window.searchGanttModel = function(query) {
        const cleanQuery = query.trim().toLowerCase();
        const cards = document.querySelectorAll(".gantt-card");
        
        if (!cleanQuery) {
            // Reset search states
            cards.forEach(card => {
                card.classList.remove("highlighted");
                card.classList.remove("dimmed");
            });
            return;
        }

        cards.forEach(card => {
            const model = card.getAttribute("data-model").toLowerCase();
            const modelName = card.getAttribute("data-model-name").toLowerCase();
            
            if (model.includes(cleanQuery) || modelName.includes(cleanQuery)) {
                card.classList.add("highlighted");
                card.classList.remove("dimmed");
            } else {
                card.classList.remove("highlighted");
                card.classList.add("dimmed");
            }
        });
    };

    // Drawer details modal handler
    window.showGanttDetail = function(cardEl) {
        const drawer = document.getElementById("gantt-drawer");
        const overlay = document.getElementById("gantt-drawer-overlay");
        const titleEl = document.getElementById("drawer-title");
        const bodyEl = document.getElementById("drawer-body");
        
        if (!drawer || !bodyEl) return;
        
        // Retrieve info from data attributes
        const model = cardEl.getAttribute("data-model");
        const modelName = cardEl.getAttribute("data-model-name");
        const moldCount = cardEl.getAttribute("data-mold-count");
        const campaign = cardEl.getAttribute("data-campaign");
        const turns = cardEl.getAttribute("data-turns");
        const furnace = cardEl.getAttribute("data-furnace");
        const shift = cardEl.getAttribute("data-shift");
        const date = cardEl.getAttribute("data-date");
        
        let products = [];
        try {
            products = JSON.parse(cardEl.getAttribute("data-products-json") || "[]");
        } catch (e) {
            console.error("Error parsing products json", e);
        }

        titleEl.textContent = `Model: ${model}`;

        // Construct HTML content for drawer
        let productsHtml = "";
        if (products.length > 0) {
            productsHtml = `
                <table class="data-table" style="font-size: 0.8rem; width: 100%;">
                    <thead>
                        <tr style="background-color: var(--bg-primary);">
                            <th>Ürün Kodu</th>
                            <th>Net/Brüt Miktar</th>
                            <th>Randıman</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${products.map(p => `
                            <tr>
                                <td style="font-weight: 700;">${p.code}</td>
                                <td>${p.net_qty} N / ${p.gross_qty} B</td>
                                <td>%${Math.round(p.yield_rate * 100)} R</td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
            `;
        } else {
            productsHtml = `<p style="font-size: 0.8rem; color: var(--text-secondary); font-style: italic;">Ürün detay bilgisi bulunmamaktadır.</p>`;
        }

        bodyEl.innerHTML = `
            <div class="gantt-detail-section">
                <div class="gantt-detail-section-title">Zaman ve Konum</div>
                <div class="gantt-detail-grid">
                    <div class="gantt-detail-item">
                        <span class="gantt-detail-label">Fırın</span>
                        <span class="gantt-detail-value">${furnace}</span>
                    </div>
                    <div class="gantt-detail-item">
                        <span class="gantt-detail-label">Tarih</span>
                        <span class="gantt-detail-value">${date}</span>
                    </div>
                    <div class="gantt-detail-item">
                        <span class="gantt-detail-label">Vardiya</span>
                        <span class="gantt-detail-value">${shift}. Vardiya</span>
                    </div>
                </div>
            </div>

            <div class="gantt-detail-section">
                <div class="gantt-detail-section-title">Model Parametreleri</div>
                <div class="gantt-detail-grid">
                    <div class="gantt-detail-item">
                        <span class="gantt-detail-label">Model Adı</span>
                        <span class="gantt-detail-value" style="grid-column: span 2;">${modelName || '-'}</span>
                    </div>
                    <div class="gantt-detail-item" style="margin-top: 6px;">
                        <span class="gantt-detail-label">Kalıp Sayısı</span>
                        <span class="gantt-detail-value">${moldCount} Kalıp</span>
                    </div>
                    <div class="gantt-detail-item" style="margin-top: 6px;">
                        <span class="gantt-detail-label">Kampanya Kodu</span>
                        <span class="gantt-detail-value">${campaign}</span>
                    </div>
                    <div class="gantt-detail-item" style="margin-top: 6px;">
                        <span class="gantt-detail-label">Toplam Tur</span>
                        <span class="gantt-detail-value">${turns} Tur</span>
                    </div>
                </div>
            </div>

            <div class="gantt-detail-section">
                <div class="gantt-detail-section-title">Üretim Detayları</div>
                ${productsHtml}
            </div>
        `;

        // Open Drawer
        overlay.classList.add("active");
        drawer.classList.add("active");
    };

    window.closeGanttDrawer = function() {
        const drawer = document.getElementById("gantt-drawer");
        const overlay = document.getElementById("gantt-drawer-overlay");
        
        if (drawer) drawer.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
    };

    // 8. Sidebar Manual Toggle
    window.toggleSidebar = function() {
        document.body.classList.toggle("sidebar-collapsed");
    };
});
