from __future__ import annotations

from pathlib import Path
from typing import Iterable

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .schemas import PlanResult, PrecheckIssue
from .specs import OUTPUT_SHEET_ORDER, PRECHECK_COLUMNS


def write_precheck_errors(output_path: str | Path, issues: Iterable[PrecheckIssue]) -> Path:
    rows = [issue.as_dict() for issue in issues]
    tables = {
        "Planlama_Ozet": pd.DataFrame(
            [
                ("Çalıştırma Durumu", "PRECHECK_ERROR"),
                ("Hata Sayısı", len(rows)),
                ("Mesaj", "Girdi workbook ön kontrolden geçemedi; solver başlatılmadı."),
            ],
            columns=["Metrik", "Değer"],
        ),
        "Precheck_Hatalari": pd.DataFrame(rows, columns=PRECHECK_COLUMNS),
        "Precheck_Infeasible": pd.DataFrame(rows, columns=PRECHECK_COLUMNS),
    }
    return write_tables(output_path, tables)


def write_plan_result(output_path: str | Path, result: PlanResult) -> Path:
    return write_tables(output_path, result.tables)


def write_tables(output_path: str | Path, tables: dict[str, pd.DataFrame]) -> Path:
    output = Path(output_path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    default = wb.active
    wb.remove(default)

    tables_to_write = dict(tables)
    tables_to_write.setdefault("README", _readme_table(tables_to_write))

    ordered_names = list(OUTPUT_SHEET_ORDER)
    for name in tables_to_write:
        if name not in ordered_names:
            ordered_names.append(name)

    for sheet_name in ordered_names:
        df = tables_to_write.get(sheet_name)
        if df is None:
            continue
        ws = wb.create_sheet(_safe_sheet_name(sheet_name))
        _write_dataframe(ws, df)
        _format_sheet(ws)

    if not wb.sheetnames:
        ws = wb.create_sheet("Planlama_Ozet")
        _write_dataframe(ws, pd.DataFrame([{"Mesaj": "Yazılacak tablo oluşmadı."}]))
        _format_sheet(ws)

    wb.save(output)
    return output


def _readme_table(tables: dict[str, pd.DataFrame]) -> pd.DataFrame:
    status = _workbook_status(tables)
    return pd.DataFrame(
        [
            {
                "Bölüm": "Durum",
                "Açıklama": status,
            },
            {
                "Bölüm": "İlk Kontrol",
                "Açıklama": "Precheck_Hatalari doluysa girdi düzeltilmeden solver sonucu kullanılmamalıdır.",
            },
            {
                "Bölüm": "Plan Özeti",
                "Açıklama": "Planlama_Ozet, genel durum, açık miktar, slack ve darboğaz özetini verir.",
            },
            {
                "Bölüm": "Saha Kullanımı",
                "Açıklama": "Saha_Is_Emri, Firin_Durum_Ozeti ve Firin_Vardiya_Gantt vardiya uygulama görünümüdür.",
            },
            {
                "Bölüm": "Teknik Detay",
                "Açıklama": "Siparis, Uretim, Firin_Kullanim, SAG_Setup, stok ve akış sheetleri karar detayını açıklar.",
            },
        ]
    )


def _has_rows(df: pd.DataFrame | None) -> bool:
    return df is not None and not df.empty


def _workbook_status(tables: dict[str, pd.DataFrame]) -> str:
    if _has_rows(tables.get("Precheck_Hatalari")):
        return "PRECHECK_ERROR"
    summary = tables.get("Planlama_Ozet")
    if summary is not None and not summary.empty and len(summary.columns) >= 2:
        metric_col = summary.columns[0]
        value_col = summary.columns[1]
        matches = summary[summary[metric_col].astype(str).str.contains("Durumu", na=False)]
        if not matches.empty:
            return str(matches.iloc[0][value_col])
    return "PLAN"


def _write_dataframe(ws, df: pd.DataFrame) -> None:
    if df.empty and len(df.columns) == 0:
        ws.append(["Durum"])
        ws.append(["Kayıt yok"])
        return
    if df.empty:
        ws.append(list(df.columns))
        return
    ws.append(list(df.columns))
    for row in df.itertuples(index=False, name=None):
        ws.append([_excel_value(value) for value in row])


def _format_sheet(ws) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.freeze_panes = "A2"
    if ws.max_column and ws.max_row:
        ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"

    for column_cells in ws.columns:
        max_len = 0
        column_letter = get_column_letter(column_cells[0].column)
        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            max_len = max(max_len, min(len(value), 80))
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.column_dimensions[column_letter].width = min(max(max_len + 2, 10), 42)

    for row in ws.iter_rows(min_row=2):
        ws.row_dimensions[row[0].row].height = 18


def _excel_value(value):
    if pd.isna(value):
        return ""
    return value


def _safe_sheet_name(name: str) -> str:
    invalid = set("[]:*?/\\")
    safe = "".join("_" if char in invalid else char for char in name)
    return safe[:31]
