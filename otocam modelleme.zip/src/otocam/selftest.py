from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd

from .calendar import build_calendar
from .carry import apply_carry_out
from .io import read_input_workbook
from .output import write_plan_result, write_precheck_errors, write_tables
from .planner import solve_plan
from .preprocess import estimate_planning_days, prepare_data
from .sample_data import SYNTHETIC_SCENARIOS, create_sample_workbook
from .schemas import PlanOptions, PlanResult, PrecheckIssue, WorkbookData
from .specs import SHEET_SPEC_BY_NAME
from .validation import validate_workbook

OK_STATUSES = {"OPTIMAL", "FEASIBLE"}


@dataclass(frozen=True)
class SelfTestRunResult:
    report_path: Path
    passed: bool
    summary: pd.DataFrame
    failures: pd.DataFrame


def run_self_test(
    output_dir: str | Path,
    plan_start: date,
    scenarios: tuple[str, ...] | None = None,
    max_days: int = 30,
    time_limit: float = 20.0,
    workers: int = 8,
) -> SelfTestRunResult:
    selected = scenarios or SYNTHETIC_SCENARIOS
    output_root = Path(output_dir).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    summary_rows: list[dict[str, Any]] = []
    failure_rows: list[dict[str, Any]] = []

    for scenario in selected:
        try:
            input_path = output_root / f"{scenario}_input.xlsx"
            output_path = output_root / f"{scenario}_output.xlsx"
            rolling_output_path = output_root / f"{scenario}_rolling_output.xlsx"

            create_sample_workbook(input_path, plan_start, scenario=scenario)
            first = _run_pipeline(
                scenario=scenario,
                run_name="ilk_plan",
                input_path=input_path,
                output_path=output_path,
                plan_start=plan_start,
                max_days=max_days,
                time_limit=time_limit,
                workers=workers,
            )
            summary_rows.append(first.summary)
            failure_rows.extend(first.failures)

            if first.result is not None and first.result.status in OK_STATUSES:
                rolling = _run_pipeline(
                    scenario=scenario,
                    run_name="rolling_carry_out",
                    input_path=input_path,
                    output_path=rolling_output_path,
                    plan_start=plan_start,
                    max_days=max_days,
                    time_limit=time_limit,
                    workers=workers,
                    carry_out_path=output_path,
                )
                summary_rows.append(rolling.summary)
                failure_rows.extend(rolling.failures)
            else:
                failure_rows.append(
                    _failure(
                        scenario,
                        "rolling_carry_out",
                        "SKIPPED",
                        "İlk plan başarılı olmadığı için rolling carry-out koşusu atlandı.",
                    )
                )
        except Exception as exc:  # pragma: no cover - defensive self-test reporting
            failure_rows.append(_failure(scenario, "self_test", type(exc).__name__, str(exc)))
            summary_rows.append(
                {
                    "Senaryo": scenario,
                    "Koşu": "self_test",
                    "Durum": "EXCEPTION",
                    "Başarılı mı?": "Hayır",
                    "Çıktı": "",
                    "Precheck Hata": "",
                    "Açık Sipariş": "",
                    "Üretim Satırı": "",
                    "Carry-Out Model Durumu": "",
                    "LSF-12 Carry-Out Model Satırı": "",
                    "Direkt V710 Dışı Geçiş": "",
                }
            )

    summary = pd.DataFrame(summary_rows)
    failures = pd.DataFrame(
        failure_rows,
        columns=["Senaryo", "Koşu", "Kural", "Mesaj"],
    )
    report_path = output_root / "selftest_report.xlsx"
    write_tables(
        report_path,
        {
            "Self_Test_Ozet": summary,
            "Self_Test_Hatalari": failures,
        },
    )
    return SelfTestRunResult(
        report_path=report_path,
        passed=failures.empty,
        summary=summary,
        failures=failures,
    )


@dataclass(frozen=True)
class _PipelineResult:
    summary: dict[str, Any]
    failures: list[dict[str, str]]
    result: PlanResult | None


def _run_pipeline(
    scenario: str,
    run_name: str,
    input_path: Path,
    output_path: Path,
    plan_start: date,
    max_days: int,
    time_limit: float,
    workers: int,
    carry_out_path: Path | None = None,
) -> _PipelineResult:
    workbook = read_input_workbook(input_path)
    if carry_out_path is not None:
        workbook = apply_carry_out(workbook, carry_out_path)
        workbook = _with_rolling_acceptance_orders(workbook, carry_out_path, plan_start)

    days = estimate_planning_days(workbook, plan_start, max_days)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(
        plan_start=plan_start,
        max_days=max_days,
        solver_time_limit=time_limit,
        workers=workers,
    )
    issues = validate_workbook(workbook, options, shifts)
    if issues:
        write_precheck_errors(output_path, issues)
        failures = [_issue_failure(scenario, run_name, issue) for issue in issues]
        return _PipelineResult(
            summary={
                "Senaryo": scenario,
                "Koşu": run_name,
                "Durum": "PRECHECK_ERROR",
                "Başarılı mı?": "Hayır",
                "Çıktı": str(output_path),
                "Precheck Hata": len(issues),
                "Açık Sipariş": "",
                "Üretim Satırı": "",
                "Carry-Out Model Durumu": "",
                "LSF-12 Carry-Out Model Satırı": "",
                "Direkt V710 Dışı Geçiş": "",
            },
            failures=failures,
            result=None,
        )

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)
    write_plan_result(output_path, result)
    metrics = _result_metrics(result)
    failures = _result_failures(scenario, run_name, result, workbook)

    return _PipelineResult(
        summary={
            "Senaryo": scenario,
            "Koşu": run_name,
            "Durum": result.status,
            "Başarılı mı?": "Evet" if not failures else "Hayır",
            "Çıktı": str(output_path),
            "Precheck Hata": 0,
            "Açık Sipariş": metrics["open_orders"],
            "Üretim Satırı": metrics["production_rows"],
            "Carry-Out Model Durumu": metrics["carry_model_rows"],
            "LSF-12 Carry-Out Model Satırı": metrics["pres_carry_model_rows"],
            "Direkt V710 Dışı Geçiş": metrics["direct_non_v710_transition_rows"],
        },
        failures=failures,
        result=result,
    )


def _result_metrics(result: PlanResult) -> dict[str, int]:
    orders = result.tables.get("Siparis", pd.DataFrame())
    production = result.tables.get("Uretim", pd.DataFrame())
    carry_out = result.tables.get("Carry_Out", pd.DataFrame())
    lsf12 = result.tables.get("LSF12_Sira", pd.DataFrame())

    carry_model_rows = _rows(carry_out, "Kayıt Tipi", "Fırın Model Durumu")
    pres_carry_model_rows = carry_model_rows[carry_model_rows.get("Fırın", pd.Series(dtype=object)) == "LSF-12"]
    direct_non_v710 = _rows(lsf12, "Doğrudan V710 Dışı Geçiş", "Evet")
    open_orders = int(orders["Açık Miktar"].sum()) if "Açık Miktar" in orders.columns else 0

    return {
        "open_orders": open_orders,
        "production_rows": len(production),
        "carry_model_rows": len(carry_model_rows),
        "pres_carry_model_rows": len(pres_carry_model_rows),
        "direct_non_v710_transition_rows": len(direct_non_v710),
    }


def _result_failures(
    scenario: str,
    run_name: str,
    result: PlanResult,
    workbook: WorkbookData,
) -> list[dict[str, str]]:
    failures: list[dict[str, str]] = []
    metrics = _result_metrics(result)
    if result.status not in OK_STATUSES:
        failures.append(_failure(scenario, run_name, "SOLVER_STATUS", f"Solver durumu: {result.status}"))
    if metrics["open_orders"] != 0:
        failures.append(
            _failure(scenario, run_name, "OPEN_ORDER", f"{metrics['open_orders']} adet açık sipariş kaldı.")
        )
    if metrics["production_rows"] <= 0:
        failures.append(_failure(scenario, run_name, "NO_PRODUCTION", "Üretim satırı oluşmadı."))
    if metrics["pres_carry_model_rows"] > 1:
        failures.append(
            _failure(
                scenario,
                run_name,
                "PRES_CARRY_SINGLE_MODEL",
                "Carry_Out içinde LSF-12 için birden fazla model durumu var.",
            )
        )
    if metrics["direct_non_v710_transition_rows"] > 0:
        failures.append(
            _failure(
                scenario,
                run_name,
                "DIRECT_NON_V710_TRANSITION",
                "LSF-12 sıralamasında direkt V710 dışı geçiş bulundu.",
            )
        )
    failures.extend(_carry_out_revalidation_failures(scenario, run_name, result, workbook))
    return failures


def _carry_out_revalidation_failures(
    scenario: str,
    run_name: str,
    result: PlanResult,
    workbook: WorkbookData,
) -> list[dict[str, str]]:
    carry_out = result.tables.get("Carry_Out")
    if carry_out is None or carry_out.empty:
        return [_failure(scenario, run_name, "CARRY_OUT_EMPTY", "Carry_Out boş oluştu.")]

    patched = WorkbookData(
        path=workbook.path,
        sheets={
            **workbook.sheets,
            "initial_furnace_model_state": _carry_out_model_state(carry_out),
            "initial_furnace_setup_carry": _carry_out_setup_carry(carry_out),
            "stock": _carry_out_stock(workbook.sheets["stock"], carry_out),
        },
        missing_sheets=workbook.missing_sheets,
    )
    days = estimate_planning_days(patched, result.shifts[0].date, 30)
    shifts = build_calendar(result.shifts[0].date, days)
    options = PlanOptions(plan_start=result.shifts[0].date)
    issues = validate_workbook(patched, options, shifts)
    return [_issue_failure(scenario, run_name, issue) for issue in issues]


def _with_rolling_acceptance_orders(
    workbook: WorkbookData,
    carry_out_path: Path,
    plan_start: date,
) -> WorkbookData:
    carry_out = pd.read_excel(carry_out_path, sheet_name="Carry_Out", dtype=object)
    fg_stock = _rows(carry_out, "Kayıt Tipi", "Bitmiş Ürün Stok")
    order_rows: list[dict[str, Any]] = []
    for _, row in fg_stock.iterrows():
        quantity = int(row["Miktar"]) if pd.notna(row["Miktar"]) else 0
        if quantity <= 0:
            continue
        order_rows.append(
            {
                "Bitmiş Ürün Kodu": row["Kod"],
                "Termin Tarihi": plan_start,
                "Sipariş Miktarı": min(quantity, 120),
                "Sipariş Türü": "OEM",
            }
        )
        if len(order_rows) >= 4:
            break

    if not order_rows:
        return workbook

    sheets = {name: df.copy() for name, df in workbook.sheets.items()}
    sheets["orders"] = pd.DataFrame(order_rows, columns=SHEET_SPEC_BY_NAME["orders"].columns)
    return WorkbookData(path=workbook.path, sheets=sheets, missing_sheets=workbook.missing_sheets)


def _carry_out_model_state(carry_out: pd.DataFrame) -> pd.DataFrame:
    rows = _rows(carry_out, "Kayıt Tipi", "Fırın Model Durumu")
    return pd.DataFrame(
        [
            {
                "Fırın Adı": row["Fırın"],
                "Model Kodu": row["Kod"],
                "Bağlı Kalıp Sayısı": row.get("Bağlı Kalıp Sayısı", 0),
                "Başlangıç Kampanya Net Üretim Miktarı": row.get("Carry-Out Kampanya Neti", 0),
            }
            for _, row in rows.iterrows()
        ],
        columns=SHEET_SPEC_BY_NAME["initial_furnace_model_state"].columns,
    )


def _carry_out_setup_carry(carry_out: pd.DataFrame) -> pd.DataFrame:
    rows = _rows(carry_out, "Kayıt Tipi", "Setup Carry")
    return pd.DataFrame(
        [
            {
                "Fırın Adı": row["Fırın"],
                "Kaynak Model Kodu": row["Kaynak Model"],
                "Hedef Model Kodu": row["Hedef Model"],
                "Kalan Setup Carry Turu": row["Kalan Lead Time/Tur"],
            }
            for _, row in rows.iterrows()
        ],
        columns=SHEET_SPEC_BY_NAME["initial_furnace_setup_carry"].columns,
    )


def _carry_out_stock(original_stock: pd.DataFrame, carry_out: pd.DataFrame) -> pd.DataFrame:
    stock = original_stock.copy()
    stock.loc[:, "Stok Miktarı"] = 0
    type_map = {
        "Bitmiş Ürün Stok": "Bitmiş Ürün",
        "Malzeme Stok": "Malzeme",
        "Yarımamul Stok": "Yarımamul",
    }
    for carry_type, stock_type in type_map.items():
        rows = _rows(carry_out, "Kayıt Tipi", carry_type)
        for _, row in rows.iterrows():
            mask = (stock["Kod"] == row["Kod"]) & (stock["Stok Türü"] == stock_type)
            if mask.any():
                stock.loc[mask, "Stok Miktarı"] = row["Miktar"]
            else:
                stock.loc[len(stock)] = [row["Kod"], stock_type, row["Miktar"]]
    return stock


def _rows(df: pd.DataFrame, column: str, value: str) -> pd.DataFrame:
    if column not in df.columns:
        return df.iloc[0:0]
    return df[df[column] == value]


def _issue_failure(scenario: str, run_name: str, issue: PrecheckIssue) -> dict[str, str]:
    return _failure(scenario, run_name, issue.rule, issue.message)


def _failure(scenario: str, run_name: str, rule: str, message: str) -> dict[str, str]:
    return {
        "Senaryo": scenario,
        "Koşu": run_name,
        "Kural": rule,
        "Mesaj": message,
    }
