from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from .specs import SHEET_SPECS

SYNTHETIC_SCENARIOS = ("base", "stress")


def create_sample_workbook(path: str | Path, plan_start: date, scenario: str = "base") -> Path:
    if scenario not in SYNTHETIC_SCENARIOS:
        allowed = ", ".join(SYNTHETIC_SCENARIOS)
        raise ValueError(f"Bilinmeyen sentetik senaryo: {scenario}. Geçerli değerler: {allowed}")

    output = Path(path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    wb.remove(wb.active)

    rows_by_sheet = _sample_rows(plan_start) if scenario == "base" else _stress_rows(plan_start)
    for spec in SHEET_SPECS:
        ws = wb.create_sheet(spec.sheet)
        ws.append(list(spec.columns))
        for row in rows_by_sheet.get(spec.sheet, []):
            ws.append(row)
        _format(ws)

    wb.save(output)
    return output


def _sample_rows(plan_start: date) -> dict[str, list[list]]:
    dates = [plan_start + timedelta(days=i) for i in range(30)]
    near_rows = [
        [day, 1, 1, 1]
        for day in dates[:7]
    ]
    far_rows = [
        [day, 3]
        for day in dates[7:]
    ]

    return {
        "orders": [
            ["FG_V710_A", plan_start + timedelta(days=1), 900, "OEM"],
            ["FG_V710_B", plan_start + timedelta(days=2), 650, "OYC"],
            ["FG_FORD_LDW", plan_start + timedelta(days=2), 420, "OEM"],
            ["FG_JEEP_DEC", plan_start + timedelta(days=3), 260, "OEM"],
            ["FG_CHEVY_EXP", plan_start + timedelta(days=4), 500, "OYC"],
        ],
        "bom": [
            ["FG_V710_A", "COMP_PVB_CLEAR", "Malzeme", 1],
            ["FG_V710_A", "SEMI_V710_M", "Yarımamul", 1],
            ["FG_V710_B", "SEMI_V710_M", "Yarımamul", 1],
            ["FG_FORD_LDW", "COMP_SENSOR", "Malzeme", 1],
            ["FG_FORD_LDW", "SEMI_FORD_M", "Yarımamul", 1],
            ["FG_JEEP_DEC", "SEMI_JEEP_M1", "Yarımamul", 1],
            ["FG_JEEP_DEC", "SEMI_JEEP_M2", "Yarımamul", 1],
            ["FG_CHEVY_EXP", "COMP_GLASS_CLEAR", "Malzeme", 2],
            ["FG_CHEVY_EXP", "SEMI_CHEVY_M", "Yarımamul", 1],
        ],
        "stock": [
            ["FG_V710_A", "Bitmiş Ürün", 100],
            ["FG_V710_B", "Bitmiş Ürün", 0],
            ["FG_FORD_LDW", "Bitmiş Ürün", 50],
            ["FG_JEEP_DEC", "Bitmiş Ürün", 0],
            ["FG_CHEVY_EXP", "Bitmiş Ürün", 0],
            ["COMP_PVB_CLEAR", "Malzeme", 3500],
            ["COMP_SENSOR", "Malzeme", 800],
            ["COMP_GLASS_CLEAR", "Malzeme", 3000],
            # Press (LSF-12) açık her vardiyada tam kapasite (700) üretir ve yarımamul
            # hazırlığı 2 vardiya sonra olgunlaştığından ilk 2 vardiya yalnız başlangıç
            # stoğuyla beslenir: V710 için en az 2*floor(700*0.95)=1330 başlangıç yarımamul
            # gerekir, aksi halde precheck PRES_FULL_CAPACITY_SEMI_FEED hatası verir.
            ["SEMI_V710_M", "Yarımamul", 1400],
            ["SEMI_JEEP_M1", "Yarımamul", 120],
            ["SEMI_JEEP_M2", "Yarımamul", 120],
            ["SEMI_FORD_M", "Yarımamul", 400],
            ["SEMI_CHEVY_M", "Yarımamul", 250],
        ],
        "furnaces": [
            ["LSF04", "SAG"],
            ["LSF05", "SAG"],
            ["LSF08", "SAG"],
            ["LSF-12", "Pres"],
        ],
        "products": [
            ["FG_V710_A", "V710", "V710 Ana Model", 2500],
            ["FG_V710_B", "V710", "V710 Varyant", 1800],
            ["FG_FORD_LDW", "V363_LOW", "Ford V363 Alçak", 900],
            ["FG_JEEP_DEC", "JEEP_AVG", "Jeep Avenger", 700],
            ["FG_CHEVY_EXP", "CHEVY_EXP", "Chevy Express", 1000],
        ],
        "sag_model_mold_capacity": [
            ["V363_LOW", 6],
            ["JEEP_AVG", 6],
            ["CHEVY_EXP", 6],
        ],
        "sag_furnace_capacity": [
            ["LSF04", 8, 26, 4],
            ["LSF05", 8, 30, 4],
            ["LSF08", 8, 34, 5],
        ],
        "furnace_product_yield": [
            ["LSF-12", "FG_V710_A", 0.95],
            ["LSF-12", "FG_V710_B", 0.95],
            ["LSF05", "FG_FORD_LDW", 0.91],
            ["LSF08", "FG_JEEP_DEC", 0.90],
            ["LSF04", "FG_CHEVY_EXP", 0.92],
            ["LSF-12", "FG_CHEVY_EXP", 0.94],
        ],
        "sag_moq": [
            ["V363_LOW", 300],
            ["JEEP_AVG", 250],
            ["CHEVY_EXP", 300],
        ],
        "material_arrivals": [
            ["COMP_SENSOR", plan_start + timedelta(days=1), 300],
            ["COMP_GLASS_CLEAR", plan_start + timedelta(days=2), 1000],
        ],
        "mandatory_dummy_models": [
            ["JEEP_AVG", 1],
            ["CHEVY_EXP", 1],
        ],
        "near_sag_opening": near_rows,
        "far_sag_opening": far_rows,
        "initial_furnace_model_state": [
            ["LSF-12", "V710", 0, 1000],
        ],
        "initial_furnace_setup_carry": [],
    }


def _stress_rows(plan_start: date) -> dict[str, list[list]]:
    dates = [plan_start + timedelta(days=i) for i in range(45)]
    near_rows = [
        [day, 2, 2, 2]
        for day in dates[:10]
    ]
    far_rows = [
        [day, 6]
        for day in dates[10:]
    ]

    return {
        "orders": [
            ["FG_V710_A", plan_start + timedelta(days=1), 700, "OEM"],
            ["FG_V710_B", plan_start + timedelta(days=2), 500, "OYC"],
            ["FG_V710_C", plan_start + timedelta(days=3), 450, "OEM"],
            ["FG_FORD_LDW", plan_start + timedelta(days=1), 380, "OEM"],
            ["FG_FORD_LDW_PLUS", plan_start + timedelta(days=4), 360, "OYC"],
            ["FG_JEEP_DEC", plan_start + timedelta(days=3), 320, "OEM"],
            ["FG_CHEVY_EXP", plan_start + timedelta(days=4), 620, "OEM"],
            ["FG_RAM_EXT", plan_start + timedelta(days=6), 420, "OYC"],
            ["FG_NISSAN_MED", plan_start + timedelta(days=7), 390, "OEM"],
            ["FG_CHEVY_EXP", plan_start + timedelta(days=9), 360, "OYC"],
        ],
        "bom": [
            ["FG_V710_A", "COMP_PVB_CLEAR", "Malzeme", 1],
            ["FG_V710_A", "SEMI_V710_M", "Yarımamul", 1],
            ["FG_V710_B", "SEMI_V710_M", "Yarımamul", 1],
            ["FG_V710_C", "COMP_PVB_ACOUSTIC", "Malzeme", 1],
            ["FG_V710_C", "SEMI_V710_M", "Yarımamul", 1],
            ["FG_FORD_LDW", "COMP_SENSOR", "Malzeme", 1],
            ["FG_FORD_LDW", "SEMI_FORD_M", "Yarımamul", 1],
            ["FG_FORD_LDW_PLUS", "COMP_SENSOR", "Malzeme", 1],
            ["FG_FORD_LDW_PLUS", "SEMI_FORD_M", "Yarımamul", 1],
            ["FG_JEEP_DEC", "SEMI_JEEP_M1", "Yarımamul", 1],
            ["FG_JEEP_DEC", "SEMI_JEEP_M2", "Yarımamul", 1],
            ["FG_CHEVY_EXP", "COMP_GLASS_CLEAR", "Malzeme", 2],
            ["FG_CHEVY_EXP", "SEMI_CHEVY_M", "Yarımamul", 1],
            ["FG_RAM_EXT", "COMP_GLASS_CLEAR", "Malzeme", 2],
            ["FG_RAM_EXT", "SEMI_RAM_M", "Yarımamul", 1],
            ["FG_NISSAN_MED", "COMP_PVB_CLEAR", "Malzeme", 1],
            ["FG_NISSAN_MED", "SEMI_NISSAN_M", "Yarımamul", 1],
        ],
        "stock": [
            ["FG_V710_A", "Bitmiş Ürün", 50],
            ["FG_V710_B", "Bitmiş Ürün", 20],
            ["FG_V710_C", "Bitmiş Ürün", 0],
            ["FG_FORD_LDW", "Bitmiş Ürün", 30],
            ["FG_FORD_LDW_PLUS", "Bitmiş Ürün", 0],
            ["FG_JEEP_DEC", "Bitmiş Ürün", 0],
            ["FG_CHEVY_EXP", "Bitmiş Ürün", 0],
            ["FG_RAM_EXT", "Bitmiş Ürün", 0],
            ["FG_NISSAN_MED", "Bitmiş Ürün", 0],
            ["COMP_PVB_CLEAR", "Malzeme", 8000],
            ["COMP_PVB_ACOUSTIC", "Malzeme", 3000],
            ["COMP_SENSOR", "Malzeme", 3000],
            ["COMP_GLASS_CLEAR", "Malzeme", 9000],
            ["SEMI_V710_M", "Yarımamul", 3000],
            ["SEMI_FORD_M", "Yarımamul", 2200],
            ["SEMI_JEEP_M1", "Yarımamul", 1500],
            ["SEMI_JEEP_M2", "Yarımamul", 1500],
            ["SEMI_CHEVY_M", "Yarımamul", 2500],
            ["SEMI_RAM_M", "Yarımamul", 1800],
            ["SEMI_NISSAN_M", "Yarımamul", 1500],
        ],
        "furnaces": [
            ["LSF04", "SAG"],
            ["LSF05", "SAG"],
            ["LSF08", "SAG"],
            ["LSF-12", "Pres"],
        ],
        "products": [
            ["FG_V710_A", "V710", "V710 Ana Model", 2500],
            ["FG_V710_B", "V710", "V710 Varyant", 1800],
            ["FG_V710_C", "V710", "V710 Akustik", 1800],
            ["FG_FORD_LDW", "V363_LOW", "Ford V363 Alçak", 1000],
            ["FG_FORD_LDW_PLUS", "V363_LOW", "Ford V363 Plus", 1000],
            ["FG_JEEP_DEC", "JEEP_AVG", "Jeep Avenger", 800],
            ["FG_CHEVY_EXP", "CHEVY_EXP", "Chevy Express", 1200],
            ["FG_RAM_EXT", "RAM_HIGH", "RAM High Roof", 900],
            ["FG_NISSAN_MED", "NISSAN_MED", "Nissan Medium", 850],
        ],
        "sag_model_mold_capacity": [
            ["V363_LOW", 6],
            ["JEEP_AVG", 6],
            ["CHEVY_EXP", 6],
            ["RAM_HIGH", 5],
            ["NISSAN_MED", 5],
        ],
        "sag_furnace_capacity": [
            ["LSF04", 8, 28, 4],
            ["LSF05", 8, 30, 4],
            ["LSF08", 8, 34, 5],
        ],
        "furnace_product_yield": [
            ["LSF-12", "FG_V710_A", 0.95],
            ["LSF-12", "FG_V710_B", 0.95],
            ["LSF-12", "FG_V710_C", 0.94],
            ["LSF-12", "FG_CHEVY_EXP", 0.94],
            ["LSF05", "FG_FORD_LDW", 0.91],
            ["LSF05", "FG_FORD_LDW_PLUS", 0.91],
            ["LSF08", "FG_JEEP_DEC", 0.90],
            ["LSF04", "FG_CHEVY_EXP", 0.92],
            ["LSF04", "FG_RAM_EXT", 0.90],
            ["LSF08", "FG_NISSAN_MED", 0.90],
        ],
        "sag_moq": [
            ["V363_LOW", 300],
            ["JEEP_AVG", 250],
            ["CHEVY_EXP", 300],
            ["RAM_HIGH", 250],
            ["NISSAN_MED", 250],
        ],
        "material_arrivals": [
            ["COMP_SENSOR", plan_start + timedelta(days=1), 500],
            ["COMP_GLASS_CLEAR", plan_start + timedelta(days=2), 1500],
            ["COMP_PVB_ACOUSTIC", plan_start + timedelta(days=2), 700],
        ],
        "mandatory_dummy_models": [
            ["JEEP_AVG", 1],
            ["CHEVY_EXP", 1],
            ["RAM_HIGH", 1],
        ],
        "near_sag_opening": near_rows,
        "far_sag_opening": far_rows,
        "initial_furnace_model_state": [
            ["LSF-12", "V710", 0, 3200],
            ["LSF05", "V363_LOW", 4, 120],
        ],
        "initial_furnace_setup_carry": [
            ["LSF04", "CHEVY_EXP", "RAM_HIGH", 3],
        ],
    }


def _format(ws) -> None:
    fill = PatternFill("solid", fgColor="1F4E78")
    font = Font(color="FFFFFF", bold=True)
    for cell in ws[1]:
        cell.fill = fill
        cell.font = font
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    for column_cells in ws.columns:
        width = max(10, min(42, max(len(str(cell.value or "")) for cell in column_cells) + 2))
        ws.column_dimensions[get_column_letter(column_cells[0].column)].width = width
