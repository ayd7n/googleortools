from __future__ import annotations

from collections import defaultdict
from datetime import date
from math import ceil

from .calendar import due_shift_index
from .schemas import (
    FurnaceInfo,
    OrderInfo,
    PlanOptions,
    PreparedData,
    ProductInfo,
    Shift,
    WorkbookData,
)
from .specs import SCALE
from .utils import clean_code, parse_date, parse_float, parse_int, to_scaled


def estimate_planning_days(workbook: WorkbookData, plan_start: date, max_days: int) -> int:
    orders = workbook.sheets.get("orders")
    if orders is None or orders.empty or "Termin Tarihi" not in orders.columns:
        return min(max_days, 7)

    due_dates = [parse_date(value) for value in orders["Termin Tarihi"]]
    valid_due_dates = [value for value in due_dates if value is not None]
    latest_due = max(valid_due_dates, default=plan_start)
    due_days = max(1, (latest_due - plan_start).days + 1)

    total_qty = 0
    if "Sipariş Miktarı" in orders.columns:
        for value in orders["Sipariş Miktarı"]:
            qty = parse_int(value)
            if qty and qty > 0:
                total_qty += qty
    rough_extra_days = max(7, ceil(total_qty / 2500)) if total_qty else 7
    return max(1, min(max_days, due_days + rough_extra_days))


def prepare_data(workbook: WorkbookData, options: PlanOptions, shifts: tuple[Shift, ...]) -> PreparedData:
    products_df = workbook.sheets["products"]
    furnaces_df = workbook.sheets["furnaces"]
    orders_df = workbook.sheets["orders"]
    bom_df = workbook.sheets["bom"]
    stock_df = workbook.sheets["stock"]
    yield_df = workbook.sheets["furnace_product_yield"]

    products: dict[str, ProductInfo] = {}
    for _, row in products_df.iterrows():
        product = clean_code(row["Bitmiş Ürün Kodu"])
        products[product] = ProductInfo(
            product=product,
            model=clean_code(row["Model Kodu"]),
            model_name=clean_code(row["Model Tanımı"]),
            max_stock=parse_int(row["Azami Stok Miktarı"]) or 0,
        )

    furnaces: dict[str, FurnaceInfo] = {}
    for _, row in furnaces_df.iterrows():
        furnace = clean_code(row["Fırın Adı"])
        furnaces[furnace] = FurnaceInfo(furnace=furnace, furnace_type=clean_code(row["Fırın Tipi"]))

    initial_fg_raw: defaultdict[str, int] = defaultdict(int)
    initial_material_stock_scaled: defaultdict[str, int] = defaultdict(int)
    initial_semi_stock_scaled: defaultdict[str, int] = defaultdict(int)
    for _, row in stock_df.iterrows():
        code = clean_code(row["Kod"])
        stock_type = clean_code(row["Stok Türü"])
        if stock_type == "Bitmiş Ürün":
            initial_fg_raw[code] += parse_int(row["Stok Miktarı"]) or 0
        elif stock_type == "Malzeme":
            initial_material_stock_scaled[code] += to_scaled(row["Stok Miktarı"])
        elif stock_type == "Yarımamul":
            initial_semi_stock_scaled[code] += to_scaled(row["Stok Miktarı"])

    grouped_orders: defaultdict[tuple[str, date, str], int] = defaultdict(int)
    for _, row in orders_df.iterrows():
        qty = parse_int(row["Sipariş Miktarı"]) or 0
        if qty <= 0:
            continue
        product = clean_code(row["Bitmiş Ürün Kodu"])
        due = parse_date(row["Termin Tarihi"])
        order_type = clean_code(row["Sipariş Türü"]).upper()
        if due is None:
            continue
        grouped_orders[(product, due, order_type)] += qty

    order_items: list[dict] = []
    for (product, due, order_type), qty in sorted(
        grouped_orders.items(), key=lambda item: (item[0][0], 0 if item[0][2] == "OEM" else 1, item[0][1])
    ):
        order_items.append(
            {
                "product": product,
                "model": products[product].model,
                "due_date": due,
                "due_shift": due_shift_index(due, shifts),
                "order_type": order_type,
                "quantity": qty,
                "initial_allocated": 0,
                "open_quantity": qty,
            }
        )

    remaining_fg = dict(initial_fg_raw)
    for product in sorted({item["product"] for item in order_items}):
        product_orders = [
            item
            for item in order_items
            if item["product"] == product
        ]
        product_orders.sort(key=lambda item: (0 if item["order_type"] == "OEM" else 1, item["due_date"]))
        available = remaining_fg.get(product, 0)
        for item in product_orders:
            allocated = min(available, item["quantity"])
            item["initial_allocated"] = allocated
            item["open_quantity"] = item["quantity"] - allocated
            available -= allocated
        remaining_fg[product] = available

    orders: list[OrderInfo] = []
    for idx, item in enumerate(order_items, start=1):
        orders.append(
            OrderInfo(
                order_id=f"ORD{idx:05d}",
                product=item["product"],
                model=item["model"],
                due_date=item["due_date"],
                due_shift=item["due_shift"],
                order_type=item["order_type"],
                quantity=item["quantity"],
                initial_allocated=item["initial_allocated"],
                open_quantity=item["open_quantity"],
            )
        )

    component_qty_scaled: defaultdict[tuple[str, str, str], int] = defaultdict(int)
    for _, row in bom_df.iterrows():
        product = clean_code(row["Bitmiş Ürün Kodu"])
        component = clean_code(row["Bileşen Malzeme Kodu"])
        component_type = clean_code(row["Bileşen Malzeme Türü"])
        component_qty_scaled[(product, component, component_type)] += to_scaled(row["Bileşen Miktarı"])

    compatibility: dict[tuple[str, str], int] = {}
    for _, row in yield_df.iterrows():
        furnace = clean_code(row["Fırın Adı"])
        product = clean_code(row["Bitmiş Ürün Kodu"])
        yield_value = parse_float(row["Randıman"]) or 0
        compatibility[(furnace, product)] = int(round(yield_value * SCALE))

    material_arrivals_scaled: defaultdict[tuple[str, int], int] = defaultdict(int)
    for _, row in workbook.sheets["material_arrivals"].iterrows():
        material = clean_code(row["Malzeme"])
        arrival_date = parse_date(row["Beklenen Teslimat Tarihi"])
        qty_scaled = to_scaled(row["Miktar"])
        if arrival_date is None:
            continue
        shift_index = _first_shift_on_or_after(shifts, arrival_date)
        if shift_index is None:
            continue
        material_arrivals_scaled[(material, shift_index)] += qty_scaled

    sag_turns: dict[str, int] = {}
    sag_wagons: dict[str, int] = {}
    sag_model_limit: dict[str, int] = {}
    sag_capacity: dict[str, int] = {}
    for _, row in workbook.sheets["sag_furnace_capacity"].iterrows():
        furnace = clean_code(row["Fırın Adı"])
        turns = parse_int(row["Vardiyadaki Tur Sayısı"]) or 0
        wagons = parse_int(row["Vagon Sayısı"]) or 0
        model_limit = parse_int(row["Vardiyadaki Çalışabileceği Farklı Model Sayısı"]) or 0
        sag_turns[furnace] = turns
        sag_wagons[furnace] = wagons
        sag_model_limit[furnace] = model_limit
        sag_capacity[furnace] = max(0, turns * wagons)

    sag_mold_capacity = {
        clean_code(row["Model Kodu"]): parse_int(row["Kalıp Sayısı"]) or 0
        for _, row in workbook.sheets["sag_model_mold_capacity"].iterrows()
    }
    mandatory_dummy = {
        clean_code(row["Model"]): parse_int(row["Mecburi Maket Adeti"]) or 0
        for _, row in workbook.sheets["mandatory_dummy_models"].iterrows()
    }
    sag_moq = {
        clean_code(row["Model Kodu"]): parse_int(row["MOQ Miktarı"]) or 0
        for _, row in workbook.sheets["sag_moq"].iterrows()
    }

    near_sag_opening: dict[int, int] = {}
    for _, row in workbook.sheets["near_sag_opening"].iterrows():
        current = parse_date(row["Tarih"])
        if current is None:
            continue
        for shift_no, col in (
            (1, "1. Vardiyada Açılacak SAG Fırın Sayısı"),
            (2, "2. Vardiyada Açılacak SAG Fırın Sayısı"),
            (3, "3. Vardiyada Açılacak SAG Fırın Sayısı"),
        ):
            idx = _shift_index(shifts, current, shift_no)
            if idx is not None:
                near_sag_opening[idx] = parse_int(row[col]) or 0

    far_sag_opening: dict[int, int] = {}
    for _, row in workbook.sheets["far_sag_opening"].iterrows():
        current = parse_date(row["Tarih"])
        if current is None:
            continue
        day_idx = _day_index(shifts, current)
        if day_idx is not None:
            far_sag_opening[day_idx] = parse_int(row["3 Vardiya Toplamında Açılacak SAG Fırın Sayısı"]) or 0

    initial_furnace_models: dict[tuple[str, str], int] = {}
    initial_campaign_net: dict[tuple[str, str], int] = {}
    for _, row in workbook.sheets["initial_furnace_model_state"].iterrows():
        furnace = clean_code(row["Fırın Adı"])
        model = clean_code(row["Model Kodu"])
        initial_furnace_models[(furnace, model)] = parse_int(row["Bağlı Kalıp Sayısı"]) or 0
        initial_campaign_net[(furnace, model)] = parse_int(row["Başlangıç Kampanya Net Üretim Miktarı"]) or 0

    initial_setup_carry: dict[tuple[str, str, str], int] = {}
    for _, row in workbook.sheets["initial_furnace_setup_carry"].iterrows():
        furnace = clean_code(row["Fırın Adı"])
        source = clean_code(row["Kaynak Model Kodu"])
        target = clean_code(row["Hedef Model Kodu"])
        initial_setup_carry[(furnace, source, target)] = parse_int(row["Kalan Setup Carry Turu"]) or 0

    import dataclasses
    updated_orders = []
    for o in orders:
        is_urgent = _calculate_order_urgency(
            o,
            remaining_fg,
            component_qty_scaled,
            initial_material_stock_scaled,
            initial_semi_stock_scaled,
            compatibility,
        )
        updated_orders.append(dataclasses.replace(o, urgent=is_urgent))
    orders = updated_orders

    initial_campaign_moq_exempt: dict[tuple[str, str], bool] = {}
    from .specs import PRES_FURNACE, PRES_MOQ
    for (furnace, model), initial in initial_campaign_net.items():
        moq = PRES_MOQ if furnace == PRES_FURNACE else sag_moq.get(model, 0)
        needed = moq - initial
        if needed <= 0:
            initial_campaign_moq_exempt[(furnace, model)] = False
            continue

        model_orders_qty = sum(o.open_quantity for o in orders if o.model == model)
        if model_orders_qty == 0:
            initial_campaign_moq_exempt[(furnace, model)] = True
            continue

        products_of_M_on_F = [
            p for p in products
            if products[p].model == model and (furnace, p) in compatibility
        ]
        if not products_of_M_on_F:
            initial_campaign_moq_exempt[(furnace, model)] = True
            continue

        is_exempt = False
        for prod in products_of_M_on_F:
            for (prod_b, comp, comp_type), qty_scaled in component_qty_scaled.items():
                if prod_b != prod:
                    continue
                if qty_scaled <= 0:
                    continue

                if comp_type == "Malzeme":
                    available = initial_material_stock_scaled.get(comp, 0) + sum(
                        qty
                        for (arrival_comp, _), qty in material_arrivals_scaled.items()
                        if arrival_comp == comp
                    )
                else:
                    available = initial_semi_stock_scaled.get(comp, 0)

                max_prod = available // qty_scaled
                if max_prod < needed:
                    is_exempt = True
                    break
            if is_exempt:
                break
        initial_campaign_moq_exempt[(furnace, model)] = is_exempt

    clean_bom = bom_df.copy()
    clean_bom["Bitmiş Ürün Kodu"] = clean_bom["Bitmiş Ürün Kodu"].map(clean_code)
    clean_bom["Bileşen Malzeme Kodu"] = clean_bom["Bileşen Malzeme Kodu"].map(clean_code)
    clean_bom["Bileşen Malzeme Türü"] = clean_bom["Bileşen Malzeme Türü"].map(clean_code)
    clean_bom["Bileşen Miktarı"] = clean_bom["Bileşen Miktarı"].map(lambda value: parse_float(value) or 0)

    return PreparedData(
        shifts=shifts,
        products=products,
        furnaces=furnaces,
        orders=tuple(orders),
        bom=clean_bom,
        stock=stock_df.copy(),
        compatibility=compatibility,
        component_qty_scaled=dict(component_qty_scaled),
        initial_fg_stock={product: int(qty) for product, qty in remaining_fg.items()},
        initial_material_stock_scaled=dict(initial_material_stock_scaled),
        initial_semi_stock_scaled=dict(initial_semi_stock_scaled),
        initial_semi_prep_carry_scaled=dict(workbook.pending_semi_prep_scaled),
        material_arrivals_scaled=dict(material_arrivals_scaled),
        sag_capacity=sag_capacity,
        sag_turns=sag_turns,
        sag_wagons=sag_wagons,
        sag_model_limit=sag_model_limit,
        sag_mold_capacity=sag_mold_capacity,
        mandatory_dummy=mandatory_dummy,
        sag_moq=sag_moq,
        near_sag_opening=near_sag_opening,
        far_sag_opening=far_sag_opening,
        initial_furnace_models=initial_furnace_models,
        initial_campaign_net=initial_campaign_net,
        initial_setup_carry=initial_setup_carry,
        initial_campaign_moq_exempt=initial_campaign_moq_exempt,
    )


def _first_shift_on_or_after(shifts: tuple[Shift, ...], current: date) -> int | None:
    for shift in shifts:
        if shift.date >= current:
            return shift.index
    return None


def _shift_index(shifts: tuple[Shift, ...], current: date, shift_no: int) -> int | None:
    for shift in shifts:
        if shift.date == current and shift.shift_no == shift_no:
            return shift.index
    return None


def _day_index(shifts: tuple[Shift, ...], current: date) -> int | None:
    for shift in shifts:
        if shift.date == current:
            return shift.day_index
    return None


def _calculate_order_urgency(
    order: OrderInfo,
    initial_fg_stock: dict[str, int],
    component_qty_scaled: dict[tuple[str, str, str], int],
    initial_material_stock_scaled: dict[str, int],
    initial_semi_stock_scaled: dict[str, int],
    compatibility: dict[tuple[str, str], int],
) -> bool:
    if order.order_type != "OEM" or order.open_quantity <= 0:
        return False
        
    if order.due_shift >= 18:
        return False
        
    product = order.product
    has_compatible_furnace = any(p == product for f, p in compatibility.keys())
    if not has_compatible_furnace:
        return True
        
    for (p, comp, comp_type), qty_scaled in component_qty_scaled.items():
        if p != product or qty_scaled <= 0:
            continue
        required = order.open_quantity * qty_scaled
        if comp_type == "Malzeme":
            avail = initial_material_stock_scaled.get(comp, 0)
        else:
            avail = initial_semi_stock_scaled.get(comp, 0)
        if avail < required:
            return True
            
    return False
