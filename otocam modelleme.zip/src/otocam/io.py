from __future__ import annotations

from pathlib import Path

import pandas as pd

from .schemas import WorkbookData
from .specs import SHEET_SPECS


def read_input_workbook(path: str | Path) -> WorkbookData:
    workbook_path = Path(path).resolve()
    if not workbook_path.exists():
        raise FileNotFoundError(f"Girdi workbook bulunamadi: {workbook_path}")

    excel = pd.ExcelFile(workbook_path)
    available = set(excel.sheet_names)
    sheets: dict[str, pd.DataFrame] = {}
    missing: list[str] = []

    for spec in SHEET_SPECS:
        if spec.sheet not in available:
            missing.append(spec.sheet)
            continue

        df = pd.read_excel(excel, sheet_name=spec.sheet, dtype=object)
        df.columns = [str(col).strip() for col in df.columns]
        df = df.dropna(how="all").reset_index(drop=True)
        sheets[spec.sheet] = df

    return WorkbookData(path=workbook_path, sheets=sheets, missing_sheets=tuple(missing))


def empty_output_path(path: str | Path) -> Path:
    output = Path(path).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    return output

