from __future__ import annotations

from .schemas import TableSpec

SCALE = 1000
PRES_FURNACE = "LSF-12"
PRES_CAPACITY = 700
PRES_CHANGE_CAPACITY_LOSS = 350
PRES_MOQ = 3000

SHEET_SPECS: tuple[TableSpec, ...] = (
    TableSpec("orders", ("Bitmiş Ürün Kodu", "Termin Tarihi", "Sipariş Miktarı", "Sipariş Türü")),
    TableSpec(
        "bom",
        (
            "Bitmiş Ürün Kodu",
            "Bileşen Malzeme Kodu",
            "Bileşen Malzeme Türü",
            "Bileşen Miktarı",
        ),
    ),
    TableSpec("stock", ("Kod", "Stok Türü", "Stok Miktarı")),
    TableSpec("furnaces", ("Fırın Adı", "Fırın Tipi")),
    TableSpec(
        "products",
        ("Bitmiş Ürün Kodu", "Model Kodu", "Model Tanımı", "Azami Stok Miktarı"),
    ),
    TableSpec("sag_model_mold_capacity", ("Model Kodu", "Kalıp Sayısı")),
    TableSpec(
        "sag_furnace_capacity",
        (
            "Fırın Adı",
            "Vardiyadaki Tur Sayısı",
            "Vagon Sayısı",
            "Vardiyadaki Çalışabileceği Farklı Model Sayısı",
        ),
    ),
    TableSpec("furnace_product_yield", ("Fırın Adı", "Bitmiş Ürün Kodu", "Randıman")),
    TableSpec("sag_moq", ("Model Kodu", "MOQ Miktarı")),
    TableSpec("material_arrivals", ("Malzeme", "Beklenen Teslimat Tarihi", "Miktar")),
    TableSpec("mandatory_dummy_models", ("Model", "Mecburi Maket Adeti")),
    TableSpec(
        "near_sag_opening",
        (
            "Tarih",
            "1. Vardiyada Açılacak SAG Fırın Sayısı",
            "2. Vardiyada Açılacak SAG Fırın Sayısı",
            "3. Vardiyada Açılacak SAG Fırın Sayısı",
        ),
    ),
    TableSpec("far_sag_opening", ("Tarih", "3 Vardiya Toplamında Açılacak SAG Fırın Sayısı")),
    TableSpec(
        "initial_furnace_model_state",
        (
            "Fırın Adı",
            "Model Kodu",
            "Bağlı Kalıp Sayısı",
            "Başlangıç Kampanya Net Üretim Miktarı",
        ),
    ),
    TableSpec(
        "initial_furnace_setup_carry",
        ("Fırın Adı", "Kaynak Model Kodu", "Hedef Model Kodu", "Kalan Setup Carry Turu"),
    ),
)

SHEET_SPEC_BY_NAME = {spec.sheet: spec for spec in SHEET_SPECS}

PRECHECK_COLUMNS = (
    "Seviye",
    "Tablo",
    "Satır",
    "Kolon",
    "Kural",
    "Gerçek Değer",
    "Mesaj",
)

INFEASIBLE_COLUMNS = (
    "Kategori",
    "Tarih/Vardiya",
    "Ürün/Model/Sipariş/Bileşen/Fırın",
    "Neden Kodu",
    "Miktar",
    "Mesaj",
    "Context",
)

OUTPUT_SHEET_ORDER = (
    "README",
    "Precheck_Hatalari",
    "Planlama_Ozet",
    "Saha_Is_Emri",
    "Firin_Durum_Ozeti",
    "Firin_Vardiya_Gantt",
    "Plan_Karar_Aciklamalari",
    "Kalip_Degisim_Talimati",
    "Siparis",
    "Siparis_Karsilama",
    "Uretim",
    "Firin_Kullanim",
    "SAG_Setup",
    "LSF12_Sira",
    "Kampanya_Carry",
    "Stok",
    "Malzeme_Akisi",
    "Yarimamul_Akisi",
    "Vardiya_Uyarilari",
    "Darbogazlar",
    "Neden_Kodlari",
    "Carry_Out",
    "Precheck_Infeasible",
)
