from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from .schemas import WorkbookData
from .specs import SHEET_SPEC_BY_NAME
from .utils import clean_code, parse_float, parse_int, to_scaled

CARRY_OUT_SHEET = "Carry_Out"

TYPE_COL = "Kayıt Tipi"
CODE_COL = "Kod"
FURNACE_COL = "Fırın"
SOURCE_MODEL_COL = "Kaynak Model"
TARGET_MODEL_COL = "Hedef Model"
REMAINING_COL = "Kalan Lead Time/Tur"
QUANTITY_COL = "Miktar"
BOUND_MOLDS_COL = "Bağlı Kalıp Sayısı"
CAMPAIGN_NET_COL = "Carry-Out Kampanya Neti"

MODEL_STATE_TYPE = "Fırın Model Durumu"
SETUP_CARRY_TYPE = "Setup Carry"
SEMI_PREP_TYPE = "Yar\u0131mamul Haz\u0131rl\u0131k"

STOCK_TYPE_BY_CARRY_TYPE = {
    "Bitmiş Ürün Stok": "Bitmiş Ürün",
    "Malzeme Stok": "Malzeme",
    "Yarımamul Stok": "Yarımamul",
}


def apply_carry_out(workbook: WorkbookData, carry_out_path: str | Path) -> WorkbookData:
    path = Path(carry_out_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Carry-out workbook bulunamadi: {path}")

    carry_out = _read_carry_out(path)
    sheets = {name: df.copy() for name, df in workbook.sheets.items()}
    sheets["initial_furnace_model_state"] = _initial_model_state(carry_out)
    sheets["initial_furnace_setup_carry"] = _initial_setup_carry(carry_out)
    sheets["stock"] = _stock_from_carry_out(sheets.get("stock"), carry_out)
    pending_semi_prep_scaled = _pending_semi_prep(carry_out)

    patched_sheets = {"initial_furnace_model_state", "initial_furnace_setup_carry", "stock"}
    missing = tuple(sheet for sheet in workbook.missing_sheets if sheet not in patched_sheets)
    return WorkbookData(
        path=workbook.path,
        sheets=sheets,
        missing_sheets=missing,
        pending_semi_prep_scaled=pending_semi_prep_scaled,
    )


def _read_carry_out(path: Path) -> pd.DataFrame:
    try:
        carry_out = pd.read_excel(path, sheet_name=CARRY_OUT_SHEET, dtype=object)
    except ValueError as exc:
        raise ValueError(f"Carry-out workbook icinde {CARRY_OUT_SHEET} sheet'i bulunamadi: {path}") from exc

    carry_out.columns = [str(column).strip() for column in carry_out.columns]
    return carry_out.dropna(how="all").reset_index(drop=True)


def _initial_model_state(carry_out: pd.DataFrame) -> pd.DataFrame:
    columns = SHEET_SPEC_BY_NAME["initial_furnace_model_state"].columns
    rows: list[dict[str, Any]] = []
    for _, row in _rows_of_type(carry_out, MODEL_STATE_TYPE).iterrows():
        furnace = clean_code(_value(row, FURNACE_COL))
        model = clean_code(_value(row, CODE_COL) or _value(row, TARGET_MODEL_COL))
        if not furnace or not model:
            continue
        rows.append(
            {
                "Fırın Adı": furnace,
                "Model Kodu": model,
                "Bağlı Kalıp Sayısı": parse_int(_value(row, BOUND_MOLDS_COL)) or 0,
                "Başlangıç Kampanya Net Üretim Miktarı": parse_int(_value(row, CAMPAIGN_NET_COL))
                or parse_int(_value(row, QUANTITY_COL))
                or 0,
            }
        )
    return pd.DataFrame(rows, columns=columns)


def _initial_setup_carry(carry_out: pd.DataFrame) -> pd.DataFrame:
    columns = SHEET_SPEC_BY_NAME["initial_furnace_setup_carry"].columns
    rows: list[dict[str, Any]] = []
    for _, row in _rows_of_type(carry_out, SETUP_CARRY_TYPE).iterrows():
        furnace = clean_code(_value(row, FURNACE_COL))
        source = clean_code(_value(row, SOURCE_MODEL_COL))
        target = clean_code(_value(row, TARGET_MODEL_COL))
        remaining = parse_int(_value(row, REMAINING_COL)) or parse_int(_value(row, QUANTITY_COL)) or 0
        if not furnace or not source or not target or remaining <= 0:
            continue
        rows.append(
            {
                "Fırın Adı": furnace,
                "Kaynak Model Kodu": source,
                "Hedef Model Kodu": target,
                "Kalan Setup Carry Turu": remaining,
            }
        )
    return pd.DataFrame(rows, columns=columns)


def _stock_from_carry_out(original: pd.DataFrame | None, carry_out: pd.DataFrame) -> pd.DataFrame:
    columns = SHEET_SPEC_BY_NAME["stock"].columns
    original = _normalized_original_stock(original)

    quantities: dict[tuple[str, str], Any] = {}
    order: list[tuple[str, str]] = []
    for _, row in original.iterrows():
        code = clean_code(row["Kod"])
        stock_type = clean_code(row["Stok Türü"])
        if not code or not stock_type:
            continue
        key = (code, stock_type)
        if key not in quantities:
            order.append(key)
        quantities[key] = 0 if stock_type in STOCK_TYPE_BY_CARRY_TYPE.values() else row["Stok Miktarı"]

    for carry_type, stock_type in STOCK_TYPE_BY_CARRY_TYPE.items():
        grouped: dict[str, float] = {}
        for _, row in _rows_of_type(carry_out, carry_type).iterrows():
            code = clean_code(_value(row, CODE_COL))
            quantity = parse_float(_value(row, QUANTITY_COL)) or 0.0
            if not code:
                continue
            grouped[code] = grouped.get(code, 0.0) + quantity
        for code, quantity in grouped.items():
            key = (code, stock_type)
            if key not in quantities:
                order.append(key)
            quantities[key] = _integer_if_whole(quantity)

    rows = [
        {"Kod": code, "Stok Türü": stock_type, "Stok Miktarı": quantities[(code, stock_type)]}
        for code, stock_type in order
    ]
    return pd.DataFrame(rows, columns=columns)


def _pending_semi_prep(carry_out: pd.DataFrame) -> dict[tuple[str, int], int]:
    pending: dict[tuple[str, int], int] = {}
    for _, row in _rows_of_type(carry_out, SEMI_PREP_TYPE).iterrows():
        code = clean_code(_value(row, CODE_COL))
        remaining = parse_int(_value(row, REMAINING_COL))
        quantity_scaled = to_scaled(_value(row, QUANTITY_COL))
        if not code or remaining is None or remaining < 0 or quantity_scaled <= 0:
            continue
        key = (code, remaining)
        pending[key] = pending.get(key, 0) + quantity_scaled
    return pending


def _normalized_original_stock(original: pd.DataFrame | None) -> pd.DataFrame:
    columns = SHEET_SPEC_BY_NAME["stock"].columns
    if original is None or original.empty:
        return pd.DataFrame(columns=columns)

    normalized = original.copy()
    for column in columns:
        if column not in normalized.columns:
            normalized[column] = ""
    return normalized.loc[:, list(columns)]


def _rows_of_type(carry_out: pd.DataFrame, record_type: str) -> pd.DataFrame:
    if TYPE_COL not in carry_out.columns:
        return carry_out.iloc[0:0]
    types = carry_out[TYPE_COL].map(clean_code)
    return carry_out[types == record_type]


def _value(row: pd.Series, column: str) -> Any:
    if column not in row.index:
        return None
    return row[column]


def _integer_if_whole(value: float) -> int | float:
    rounded = round(value)
    if abs(value - rounded) < 1e-9:
        return int(rounded)
    return value
