from __future__ import annotations

from datetime import date, datetime
from math import ceil, floor
from typing import Any

import pandas as pd

from .specs import SCALE


def clean_code(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value)).strip()
    return str(value).strip()


def parse_date(value: Any) -> date | None:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, pd.Timestamp):
        return value.date()
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    parsed = pd.to_datetime(value, errors="coerce")
    if pd.isna(parsed):
        return None
    return parsed.date()


def parse_float(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, str):
        value = value.strip().replace(",", ".")
    parsed = pd.to_numeric(value, errors="coerce")
    if pd.isna(parsed):
        return None
    return float(parsed)


def parse_int(value: Any) -> int | None:
    parsed = parse_float(value)
    if parsed is None:
        return None
    if abs(parsed - round(parsed)) > 1e-9:
        return None
    return int(round(parsed))


def to_scaled(value: Any) -> int:
    parsed = parse_float(value)
    if parsed is None:
        return 0
    return int(round(parsed * SCALE))


def scaled_to_float(value: int) -> float:
    return value / SCALE


def safe_floor_scaled_div(numerator: int, denominator: int) -> int:
    if denominator <= 0:
        return 0
    return floor(numerator / denominator)


def ceil_div(numerator: int, denominator: int) -> int:
    if denominator <= 0:
        return 0
    return ceil(numerator / denominator)


def is_empty_frame(df: pd.DataFrame | None) -> bool:
    return df is None or df.empty

