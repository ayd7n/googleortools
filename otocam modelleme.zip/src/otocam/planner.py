from __future__ import annotations

from collections import defaultdict
from math import ceil, floor
from time import perf_counter
from typing import Any

import pandas as pd
from ortools.sat.python import cp_model

from .schemas import OrderInfo, PlanOptions, PlanResult, PreparedData, Shift
from .specs import (
    INFEASIBLE_COLUMNS,
    PRECHECK_COLUMNS,
    PRES_CAPACITY,
    PRES_CHANGE_CAPACITY_LOSS,
    PRES_FURNACE,
    PRES_MOQ,
    SCALE,
)
from .utils import scaled_to_float


def get_semi_root_and_suffix(code: str) -> tuple[str, str]:
    if code.endswith("M1"):
        return code[:-2], "M1"
    elif code.endswith("M2"):
        return code[:-2], "M2"
    elif code.endswith("M"):
        return code[:-1], "M"
    return code, ""


def solve_plan(data: PreparedData, options: PlanOptions) -> PlanResult:
    builder = _CpSatPlanBuilder(data, options)
    return builder.solve()


class _CpSatPlanBuilder:
    def __init__(self, data: PreparedData, options: PlanOptions) -> None:
        self.data = data
        self.options = options
        self.model = cp_model.CpModel()
        self.products = sorted(data.products)
        self.furnaces = sorted(data.furnaces)
        self.shifts = data.shifts
        self.orders = [order for order in data.orders if order.open_quantity > 0]
        self.product_model = {product: info.model for product, info in data.products.items()}

        self.gross: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.net: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.ship: dict[tuple[str, int], cp_model.IntVar] = {}
        self.order_complete: dict[tuple[str, int], cp_model.IntVar] = {}
        self.fg_stock: dict[tuple[str, int], cp_model.IntVar] = {}
        self.sag_product_active: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.pres_product_active: dict[tuple[str, int], cp_model.IntVar] = {}
        self.open_sag: dict[tuple[str, int], cp_model.IntVar] = {}
        self.active_sag: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.bound_sag: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.model_molds_sag: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.sag_new_setup_start: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.campaign_active_sag: dict[tuple[str, str], cp_model.IntVar] = {}
        self.campaign_net_sag: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.initial_campaign_active_sag: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.campaign_net_pres: dict[tuple[str, int], cp_model.IntVar] = {}
        self.initial_campaign_active_pres: dict[tuple[str, int], cp_model.IntVar] = {}
        self.initial_setup_carry_turns: dict[tuple[str, str, str, int], cp_model.IntVar] = {}
        self.initial_setup_carry_cleared: dict[tuple[str, int], cp_model.IntVar] = {}
        self.setup_start: dict[tuple[str, str, str, int], cp_model.IntVar] = {}
        self.new_setup_turns: dict[tuple[str, str, str, int], cp_model.IntVar] = {}
        self.carry_setup_turns: dict[tuple[str, str, str, int], cp_model.IntVar] = {}
        self.setup_carry: dict[tuple[str, str, str, int], cp_model.IntVar] = {}
        self.sag_open_deficit: dict[int, cp_model.IntVar] = {}
        self.sag_daily_deficit: dict[int, cp_model.IntVar] = {}
        self.active_pres: dict[tuple[str, int], cp_model.IntVar] = {}
        self.open_pres: dict[int, cp_model.IntVar] = {}
        self.pres_change: dict[int, cp_model.IntVar] = {}
        self.pres_slack: dict[int, cp_model.IntVar] = {}
        self.semi_prep: dict[tuple[str, int], cp_model.IntVar] = {}
        self.final_stock_excess: dict[str, cp_model.IntVar] = {}
        self.sag_unbound: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.pres_unbound: dict[tuple[str, int], cp_model.IntVar] = {}
        self.v710_exception: dict[int, cp_model.IntVar] = {}
        self.v710_exception_order: dict[tuple[str, int], cp_model.IntVar] = {}
        self.unbound_slack: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.unbound_open_order_slack: dict[tuple[str, str, int], cp_model.IntVar] = {}
        self.stage_summary: dict[str, Any] = {}

    def _hint_solution(self, solver) -> None:
        self.model.ClearHints()
        # Gross, net, ship
        for key, var in self.gross.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.net.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.ship.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        # SAG bounds and molds
        for key, var in self.bound_sag.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.active_sag.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.model_molds_sag.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        # Setups
        for key, var in self.setup_start.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.carry_setup_turns.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.new_setup_turns.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.setup_carry.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.open_sag.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.sag_new_setup_start.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.sag_unbound.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.initial_setup_carry_cleared.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        # Pres
        for key, var in self.active_pres.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.pres_unbound.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.pres_change.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.pres_product_active.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.sag_product_active.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        # Semi prep
        for key, var in self.semi_prep.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.final_stock_excess.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        # Slacks and exceptions
        for key, var in self.pres_slack.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.sag_open_deficit.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.sag_daily_deficit.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.v710_exception.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.v710_exception_order.items():
            self.model.AddHint(var, int(round(solver.Value(var))))
        for key, var in self.unbound_slack.items():
            self.model.AddHint(var, int(round(solver.Value(var))))

    def solve(self) -> PlanResult:
        start = perf_counter()
        self._build_variables()
        self._add_capacity_constraints()
        self._add_stock_constraints()
        self._add_order_priority_constraints()
        self._add_unbound_completion_constraints()
        self._add_component_constraints()

        total_limit = self.options.solver_time_limit
        workers = self.options.workers
        log_solver = self.options.log_solver

        # Stage 1: OEM maximization
        obj1 = self._get_obj1()
        self.model.Maximize(obj1)

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = max(1.0, total_limit * 0.6)
        solver.parameters.num_search_workers = workers
        solver.parameters.log_search_progress = log_solver

        status = solver.Solve(self.model)
        elapsed = perf_counter() - start
        self.stage_summary["stage1_oem_status"] = solver.StatusName(status)
        self.stage_summary["stage1_oem_objective"] = (
            float(solver.ObjectiveValue()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        self.stage_summary["stage1_oem_best_bound"] = (
            float(solver.BestObjectiveBound()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        print(f"--- Stage 1 Solve Status: {solver.StatusName(status)}, Obj: {solver.ObjectiveValue() if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else 'N/A'}, Time: {elapsed:.2f}s")
        
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            status_name = solver.StatusName(status)
            tables = _infeasible_tables(status_name)
            return PlanResult(
                status=status_name,
                objective=None,
                shifts=self.shifts,
                tables=tables,
                solver_summary={"status": status_name, "elapsed_seconds": round(elapsed, 3)},
            )

        opt1 = int(round(solver.ObjectiveValue()))
        self.model.Add(obj1 >= opt1)

        # Stage 2: OYC maximization
        obj2 = self._get_obj2()
        self.model.Maximize(obj2)
        
        solver2 = cp_model.CpSolver()
        solver2.parameters.max_time_in_seconds = max(1.0, (total_limit - elapsed) * 0.8)
        solver2.parameters.num_search_workers = workers
        solver2.parameters.log_search_progress = log_solver

        self._hint_solution(solver)
        status = solver2.Solve(self.model)
        elapsed = perf_counter() - start
        self.stage_summary["stage2_oyc_status"] = solver2.StatusName(status)
        self.stage_summary["stage2_oyc_objective"] = (
            float(solver2.ObjectiveValue()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        self.stage_summary["stage2_oyc_best_bound"] = (
            float(solver2.BestObjectiveBound()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        print(f"--- Stage 2 Solve Status: {solver2.StatusName(status)}, Obj: {solver2.ObjectiveValue() if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else 'N/A'}, Time: {elapsed:.2f}s")
        
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            status_name = solver2.StatusName(status)
            fallback_status = "FEASIBLE"
            tables = self._extract_tables(solver)
            tables["Planlama_Ozet"] = self._plan_summary_table(solver, fallback_status, float(opt1), elapsed)
            return PlanResult(
                status=fallback_status,
                objective=float(opt1),
                shifts=self.shifts,
                tables=tables,
                solver_summary={
                    "status": f"{status_name}_FALLBACK_STAGE1",
                    "objective": float(opt1),
                    "elapsed_seconds": round(elapsed, 3),
                    **self.stage_summary,
                },
            )

        opt2 = int(round(solver2.ObjectiveValue()))
        self.model.Add(obj2 >= opt2)

        # Stage 3: Operational Cost maximization
        self._add_unbound_open_order_slack_constraints()
        obj3 = self._get_obj3()
        self.model.Maximize(obj3)
        
        solver3 = cp_model.CpSolver()
        solver3.parameters.max_time_in_seconds = max(1.0, total_limit - elapsed)
        solver3.parameters.num_search_workers = workers
        solver3.parameters.log_search_progress = log_solver

        self._hint_solution(solver2)
        status = solver3.Solve(self.model)
        elapsed = perf_counter() - start
        status_name = solver3.StatusName(status)
        self.stage_summary["stage3_operational_status"] = status_name
        self.stage_summary["stage3_operational_objective"] = (
            float(solver3.ObjectiveValue()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        self.stage_summary["stage3_operational_best_bound"] = (
            float(solver3.BestObjectiveBound()) if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else None
        )
        print(f"--- Stage 3 Solve Status: {status_name}, Obj: {solver3.ObjectiveValue() if status in (cp_model.OPTIMAL, cp_model.FEASIBLE) else 'N/A'}, Time: {elapsed:.2f}s")

        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            fallback_status = "FEASIBLE"
            tables = self._extract_tables(solver2)
            tables["Planlama_Ozet"] = self._plan_summary_table(solver2, fallback_status, float(opt2), elapsed)
            return PlanResult(
                status=fallback_status,
                objective=float(opt2),
                shifts=self.shifts,
                tables=tables,
                solver_summary={
                    "status": f"{status_name}_FALLBACK_STAGE2",
                    "objective": float(opt2),
                    "elapsed_seconds": round(elapsed, 3),
                    **self.stage_summary,
                },
            )

        tables = self._extract_tables(solver3)
        objective = solver3.ObjectiveValue()
        tables["Planlama_Ozet"] = self._plan_summary_table(solver3, status_name, objective, elapsed)
        return PlanResult(
            status=status_name,
            objective=objective,
            shifts=self.shifts,
            tables=tables,
            solver_summary={
                "status": status_name,
                "objective": objective,
                "elapsed_seconds": round(elapsed, 3),
                **self.stage_summary,
                "conflicts": solver3.NumConflicts(),
                "branches": solver3.NumBranches(),
                "wall_time": solver3.WallTime(),
            },
        )

    def _build_variables(self) -> None:
        for furnace, product in sorted(self.data.compatibility):
            yield_scaled = self.data.compatibility[(furnace, product)]
            cap = self._furnace_gross_cap(furnace)
            if cap <= 0 or yield_scaled <= 0:
                continue
            for shift in self.shifts:
                key = (product, furnace, shift.index)
                self.gross[key] = self.model.NewIntVar(0, cap, f"gross_{product}_{furnace}_{shift.index}")
                net_ub = floor(cap * yield_scaled / SCALE)
                self.net[key] = self.model.NewIntVar(0, net_ub, f"net_{product}_{furnace}_{shift.index}")
                self.model.Add(self.net[key] * SCALE <= self.gross[key] * yield_scaled)
                self.model.Add(self.gross[key] * yield_scaled <= self.net[key] * SCALE + (SCALE - 1))
                self.model.Add(self.gross[key] <= ceil(SCALE / yield_scaled) * self.net[key])
                if self.data.furnaces[furnace].furnace_type == "SAG":
                    active = self.model.NewBoolVar(
                        f"sag_product_active_{product}_{furnace}_{shift.index}"
                    )
                    self.sag_product_active[(product, furnace, shift.index)] = active
                    self.model.Add(self.gross[key] <= cap * active)
                    self.model.Add(self.gross[key] >= active)
                elif furnace == PRES_FURNACE:
                    active = self.model.NewBoolVar(
                        f"pres_product_active_{product}_{shift.index}"
                    )
                    self.pres_product_active[(product, shift.index)] = active
                    self.model.Add(self.gross[key] <= cap * active)
                    self.model.Add(self.gross[key] >= active)

        for order in self.orders:
            for shift in self.shifts:
                self.ship[(order.order_id, shift.index)] = self.model.NewIntVar(
                    0,
                    order.open_quantity,
                    f"ship_{order.order_id}_{shift.index}",
                )
                self.order_complete[(order.order_id, shift.index)] = self.model.NewBoolVar(
                    f"complete_{order.order_id}_{shift.index}"
                )
            self.model.Add(
                sum(self.ship[(order.order_id, shift.index)] for shift in self.shifts)
                <= order.open_quantity
            )

        for product in self.products:
            ub = self._product_stock_upper_bound(product)
            for shift in self.shifts:
                self.fg_stock[(product, shift.index)] = self.model.NewIntVar(
                    0,
                    ub,
                    f"fg_stock_{product}_{shift.index}",
                )
            self.final_stock_excess[product] = self.model.NewIntVar(0, ub, f"final_excess_{product}")

        for furnace in self.data.sag_furnaces:
            compatible_models = self._compatible_models_for_furnace(furnace)
            for model in compatible_models:
                self.campaign_active_sag[(furnace, model)] = self.model.NewBoolVar(
                    f"campaign_active_sag_{furnace}_{model}"
                )
            for shift in self.shifts:
                self.open_sag[(furnace, shift.index)] = self.model.NewBoolVar(
                    f"open_sag_{furnace}_{shift.index}"
                )
                for model in compatible_models:
                    self.bound_sag[(furnace, model, shift.index)] = self.model.NewBoolVar(
                        f"bound_sag_{furnace}_{model}_{shift.index}"
                    )
                    self.active_sag[(furnace, model, shift.index)] = self.model.NewBoolVar(
                        f"active_sag_{furnace}_{model}_{shift.index}"
                    )
                    self.sag_new_setup_start[(furnace, model, shift.index)] = self.model.NewIntVar(
                        0,
                        self.data.sag_mold_capacity.get(model, 0),
                        f"sag_new_setup_start_{furnace}_{model}_{shift.index}",
                    )
                    self.model_molds_sag[(furnace, model, shift.index)] = self.model.NewIntVar(
                        0,
                        self.data.sag_mold_capacity.get(model, 0),
                        f"model_molds_sag_{furnace}_{model}_{shift.index}",
                    )
                    self.sag_unbound[(furnace, model, shift.index)] = self.model.NewBoolVar(
                        f"sag_unbound_{furnace}_{model}_{shift.index}"
                    )
                    self.campaign_net_sag[(furnace, model, shift.index)] = self.model.NewIntVar(
                        0,
                        self._campaign_net_upper_bound(furnace, model),
                        f"campaign_net_sag_{furnace}_{model}_{shift.index}",
                    )
                    self.initial_campaign_active_sag[
                        (furnace, model, shift.index)
                    ] = self.model.NewBoolVar(
                        f"initial_campaign_active_sag_{furnace}_{model}_{shift.index}"
                    )

        for furnace in self.data.sag_furnaces:
            compatible_models = self._compatible_models_for_furnace(furnace)
            M0 = compatible_models + ["Yok"]
            transitions = [(a, b) for a in M0 for b in M0 if a != b]
            shift_cap = self.data.sag_turns.get(furnace, 0)
            for source, target in transitions:
                initial_carry = self.data.initial_setup_carry.get((furnace, source, target), 0)
                mold_cap_a = self.data.sag_mold_capacity.get(source, 0) if source != "Yok" else 0
                mold_cap_b = self.data.sag_mold_capacity.get(target, 0) if target != "Yok" else 0
                max_molds = max(mold_cap_a, mold_cap_b)
                max_carry = max(initial_carry, max_molds)
                for shift in self.shifts:
                    key = (furnace, source, target, shift.index)
                    self.setup_start[key] = self.model.NewIntVar(0, max_molds, f"setup_start_{furnace}_{source}_{target}_{shift.index}")
                    self.new_setup_turns[key] = self.model.NewIntVar(0, shift_cap, f"new_setup_turns_{furnace}_{source}_{target}_{shift.index}")
                    self.carry_setup_turns[key] = self.model.NewIntVar(0, shift_cap, f"carry_setup_turns_{furnace}_{source}_{target}_{shift.index}")
                    self.setup_carry[key] = self.model.NewIntVar(0, max_carry, f"setup_carry_{furnace}_{source}_{target}_{shift.index}")

        for furnace in self.data.sag_furnaces:
            for shift in self.shifts:
                self.initial_setup_carry_cleared[(furnace, shift.index)] = self.model.NewBoolVar(
                    f"initial_setup_carry_cleared_{furnace}_{shift.index}"
                )

        for shift in self.shifts:
            if shift.index in self.data.near_sag_opening:
                target = self.data.near_sag_opening[shift.index]
                self.sag_open_deficit[shift.index] = self.model.NewIntVar(
                    0,
                    target,
                    f"sag_open_deficit_{shift.index}",
                )

        for day_index, target in self.data.far_sag_opening.items():
            self.sag_daily_deficit[day_index] = self.model.NewIntVar(
                0,
                target,
                f"sag_daily_deficit_{day_index}",
            )

        pres_models = self._compatible_models_for_furnace(PRES_FURNACE)
        for shift in self.shifts:
            pres_avail = getattr(shift, "pres_available", 1)
            self.open_pres[shift.index] = self.model.NewIntVar(
                pres_avail,
                pres_avail,
                f"open_pres_{shift.index}",
            )
            self.pres_slack[shift.index] = self.model.NewIntVar(
                0,
                PRES_CAPACITY,
                f"pres_slack_{shift.index}",
            )
            self.pres_change[shift.index] = self.model.NewBoolVar(f"pres_change_{shift.index}")
            for model in pres_models:
                self.active_pres[(model, shift.index)] = self.model.NewBoolVar(
                    f"active_pres_{model}_{shift.index}"
                )
                self.pres_unbound[(model, shift.index)] = self.model.NewBoolVar(
                    f"pres_unbound_{model}_{shift.index}"
                )
                self.campaign_net_pres[(model, shift.index)] = self.model.NewIntVar(
                    0,
                    self._campaign_net_upper_bound(PRES_FURNACE, model),
                    f"campaign_net_pres_{model}_{shift.index}",
                )
                self.initial_campaign_active_pres[(model, shift.index)] = self.model.NewBoolVar(
                    f"initial_campaign_active_pres_{model}_{shift.index}"
                )

        for component in self._all_semi_components():
            ub = self._semi_prep_upper_bound(component)
            for shift in self.shifts:
                self.semi_prep[(component, shift.index)] = self.model.NewIntVar(
                    0,
                    ub,
                    f"semi_prep_{component}_{shift.index}",
                )

    def _previous_setup_carry(self, furnace: str, source: str, target: str, shift_index: int) -> int | cp_model.IntVar:
        if shift_index == 0:
            return self.data.initial_setup_carry.get((furnace, source, target), 0)
        else:
            return self.setup_carry[(furnace, source, target, shift_index - 1)]

    def _add_capacity_constraints(self) -> None:
        for furnace in self.data.sag_furnaces:
            compatible_models = self._compatible_models_for_furnace(furnace)
            model_limit = self.data.sag_model_limit.get(furnace, 1)
            cap = self.data.sag_capacity.get(furnace, 0)
            wagon_cap = self.data.sag_wagons.get(furnace, 0)
            shift_cap = self.data.sag_turns.get(furnace, 0)
            M0 = compatible_models + ["Yok"]
            transitions = [(a, b) for a in M0 for b in M0 if a != b]
            
            for shift in self.shifts:
                open_var = self.open_sag[(furnace, shift.index)]
                bound_vars = [
                    self.bound_sag[(furnace, model, shift.index)] for model in compatible_models
                ]
                active_vars = [
                    self.active_sag[(furnace, model, shift.index)] for model in compatible_models
                ]
                
                # Model limit constraint
                if bound_vars:
                    self.model.Add(sum(bound_vars) <= model_limit)
                    for model, bound, active in zip(compatible_models, bound_vars, active_vars, strict=True):
                        self.model.Add(active <= open_var)
                        self.model.Add(active <= bound)
                        self.model.Add(active <= self.campaign_active_sag[(furnace, model)])
                        # Açık SAG vardiyasında bağlı kalan her model üretim kalıbıyla
                        # çalışır; bağlı ama pasif model kalmaz (spec 8.1 / 6.1). Bu yüzden
                        # fırın açık ve model bağlıysa model aktif (üretimde) olmak zorundadır.
                        self.model.Add(active >= open_var + bound - 1)

                        # Kapalı vardiyada kampanya kesilmez (spec 6.4 / "Kampanya Nedir?"):
                        # fırın o vardiyada kapalıysa bağlı model bağlı kalır, söküm veya
                        # yeniden bağlama yapılmaz. Böylece kapanış-açılış arasında fantom
                        # kalıp değişim turu (setup) üretilmez ve kampanya doğru sürer.
                        if shift.index > 0:
                            bound_prev = self.bound_sag[(furnace, model, shift.index - 1)]
                            self.model.Add(bound == bound_prev).OnlyEnforceIf(open_var.Not())

                        # Active reification for model gross
                        mold_var = self.model_molds_sag[(furnace, model, shift.index)]
                        self.model.Add(mold_var <= self.data.sag_mold_capacity.get(model, 0) * bound)
                        self.model.Add(mold_var >= bound)

                        initial_molds = self.data.initial_furnace_models.get((furnace, model), 0)
                        initial_campaign_active = self.initial_campaign_active_sag[
                            (furnace, model, shift.index)
                        ]
                        if initial_molds > 0:
                            if shift.index == 0:
                                self.model.Add(initial_campaign_active == bound)
                            else:
                                previous_initial_campaign = self.initial_campaign_active_sag[
                                    (furnace, model, shift.index - 1)
                                ]
                                self.model.Add(initial_campaign_active <= previous_initial_campaign)
                                self.model.Add(initial_campaign_active <= bound)
                                self.model.Add(
                                    initial_campaign_active >= previous_initial_campaign + bound - 1
                                )
                            self.model.Add(mold_var >= initial_molds * initial_campaign_active)
                        else:
                            self.model.Add(initial_campaign_active == 0)

                        # Unbound state
                        unbound = self.sag_unbound[(furnace, model, shift.index)]
                        previous_bound = self._sag_previous_bound_expr(furnace, model, shift.index)
                        if shift.index > 0:
                            self.model.Add(unbound >= previous_bound - bound)
                            self.model.Add(unbound <= previous_bound)
                            self.model.Add(unbound <= 1 - bound)
                        else:
                            initial_molds = self.data.initial_furnace_models.get((furnace, model), 0)
                            if initial_molds > 0:
                                self.model.Add(unbound == 1 - bound)
                            else:
                                self.model.Add(unbound == 0)
                                
                        # Initial model bound constraint if no initial carry
                        has_initial_carry = self._initial_setup_carry_total_for_furnace(furnace) > 0
                        if shift.index == 0 and initial_molds > 0 and not has_initial_carry:
                            self.model.Add(bound == 1)
                            self.model.Add(active == open_var)
                            self.model.Add(mold_var >= initial_molds)
                elif not self._initial_setup_carry_total_for_furnace(furnace) > 0:
                    self.model.Add(open_var == 0)

                # Setup carry and setup start constraints
                for source, target in transitions:
                    key = (furnace, source, target, shift.index)
                    prev_c = self._previous_setup_carry(furnace, source, target, shift.index)
                    max_setup = max(
                        self.data.sag_mold_capacity.get(source, 0) if source != "Yok" else 0,
                        self.data.sag_mold_capacity.get(target, 0) if target != "Yok" else 0,
                    )

                    self.model.Add(self.setup_start[key] <= max_setup * open_var)
                    self.model.Add(self.carry_setup_turns[key] <= prev_c)
                    self.model.Add(self.new_setup_turns[key] <= self.setup_start[key])
                    self.model.Add(self.setup_carry[key] == prev_c - self.carry_setup_turns[key] + self.setup_start[key] - self.new_setup_turns[key])
                
                # Carry finishes first logic
                prev_carry_terms = []
                for a, b in transitions:
                    p_c = self._previous_setup_carry(furnace, a, b, shift.index)
                    if isinstance(p_c, cp_model.IntVar) or p_c > 0:
                        prev_carry_terms.append(p_c)
                        
                if prev_carry_terms:
                    prev_carry_total = sum(prev_carry_terms)
                else:
                    prev_carry_total = 0
                    
                carry_setup_total = sum(
                    self.carry_setup_turns[(furnace, a, b, shift.index)]
                    for a, b in transitions
                )
                
                remaining_carry_var = self.model.NewIntVar(0, shift_cap + 100, f"remaining_carry_{furnace}_{shift.index}")
                self.model.Add(remaining_carry_var == prev_carry_total - carry_setup_total)
                
                cleared = self.initial_setup_carry_cleared[(furnace, shift.index)]
                self.model.Add(remaining_carry_var == 0).OnlyEnforceIf(cleared)
                self.model.Add(remaining_carry_var >= 1).OnlyEnforceIf(cleared.Not())
                
                self.model.Add(carry_setup_total == prev_carry_total).OnlyEnforceIf(cleared)
                self.model.Add(carry_setup_total == shift_cap * open_var).OnlyEnforceIf(cleared.Not())
                
                self.model.Add(shift_cap * open_var - carry_setup_total <= shift_cap * cleared)

                # Setup loss and capacity limit
                setup_loss = sum(
                    self.carry_setup_turns[(furnace, a, b, shift.index)]
                    + self.new_setup_turns[(furnace, a, b, shift.index)]
                    for a, b in transitions
                )
                self.model.Add(setup_loss <= shift_cap * open_var)

                # Üretime kalan tur sayısı = toplam tur − setup turu (spec 6.7). Kalıp değişimi
                # turları üretimden düşülür; bu değişken per-model gerçek kapasite hesabında
                # (brüt ≤ kalıp × üretim turu) kullanılır.
                prod_turns_f = self.model.NewIntVar(
                    0, shift_cap, f"prod_turns_{furnace}_{shift.index}"
                )
                self.model.Add(prod_turns_f == shift_cap - setup_loss)

                # Setup işleri boşta tur bırakmadan tamamlanır (spec 6.7): vardiya sonunda
                # tamamlanmamış setup carry kalıyorsa, o vardiyanın tüm turları setup'a
                # harcanmış olmalıdır. Böylece yalnız tur kapasitesini aşan kalıp değişimi
                # sonraki vardiyaya sarkar; boşta tur varken setup gereksiz yere bölünmez.
                end_carry_total = sum(
                    self.setup_carry[(furnace, a, b, shift.index)] for a, b in transitions
                )
                carry_remains = self.model.NewBoolVar(
                    f"setup_carry_remains_{furnace}_{shift.index}"
                )
                self.model.Add(end_carry_total >= 1).OnlyEnforceIf(carry_remains)
                self.model.Add(end_carry_total == 0).OnlyEnforceIf(carry_remains.Not())
                self.model.Add(setup_loss == shift_cap * open_var).OnlyEnforceIf(carry_remains)

                gross_terms = [
                    var
                    for (product, f, t), var in self.gross.items()
                    if f == furnace and t == shift.index
                ]
                if gross_terms:
                    self.model.Add(sum(gross_terms) + setup_loss * wagon_cap <= cap * open_var)
                    self.model.Add(sum(gross_terms) + setup_loss >= open_var)
                else:
                    self.model.Add(open_var == 0)

                # Wagon terms limit
                wagon_terms = []
                for model in compatible_models:
                    bound = self.bound_sag[(furnace, model, shift.index)]
                    mold_var = self.model_molds_sag[(furnace, model, shift.index)]
                    wagon_terms.append(mold_var + self.data.mandatory_dummy.get(model, 0) * bound)
                if wagon_terms:
                    self.model.Add(sum(wagon_terms) <= wagon_cap)

                # Model/mold transitions. Setup need is counted per changed mold, not per model:
                # completing one source->target setup turn removes one source mold and, unless
                # target is Yok, binds one target mold. Excess removals/additions pair with Yok.
                total_mold_increase_terms = []
                total_mold_decrease_terms = []
                for m in compatible_models:
                    previous_molds = self._sag_previous_molds_expr(furnace, m, shift.index)
                    current_molds = self.model_molds_sag[(furnace, m, shift.index)]

                    setup_starts_to_m = sum(self.setup_start[(furnace, a, m, shift.index)] for a in M0 if a != m)
                    completed_to_m = sum(
                        self.carry_setup_turns[(furnace, a, m, shift.index)]
                        + self.new_setup_turns[(furnace, a, m, shift.index)]
                        for a in M0
                        if a != m
                    )
                    completed_from_m = sum(
                        self.carry_setup_turns[(furnace, m, b, shift.index)]
                        + self.new_setup_turns[(furnace, m, b, shift.index)]
                        for b in M0
                        if b != m
                    )

                    mold_cap_m = self.data.sag_mold_capacity.get(m, 0)
                    mold_increase = self.model.NewIntVar(
                        0,
                        mold_cap_m,
                        f"mold_increase_{furnace}_{m}_{shift.index}",
                    )
                    mold_decrease = self.model.NewIntVar(
                        0,
                        mold_cap_m,
                        f"mold_decrease_{furnace}_{m}_{shift.index}",
                    )
                    self.model.AddMaxEquality(mold_increase, [current_molds - previous_molds, 0])
                    self.model.AddMaxEquality(mold_decrease, [previous_molds - current_molds, 0])
                    self.model.Add(completed_to_m == mold_increase)
                    self.model.Add(completed_from_m == mold_decrease)
                    self.model.Add(self.sag_new_setup_start[(furnace, m, shift.index)] == setup_starts_to_m)

                    total_mold_increase_terms.append(mold_increase)
                    total_mold_decrease_terms.append(mold_decrease)

                    # Model cannot be bound at the end of the shift if there is unfinished setup carry to it
                    M_cap = 100
                    for a in M0:
                        if a != m:
                            self.model.Add(self.setup_carry[(furnace, a, m, shift.index)] <= M_cap * (1 - self.bound_sag[(furnace, m, shift.index)]))

                    # Aktif model üretim bağı — TÜM fırın-model-vardiya için geçerlidir.
                    # Önceden bu blok yanlışlıkla yalnız shift 0 (else dalı) ve `for m`
                    # döngüsünden sızan son model için uygulanıyordu; bu yüzden vardiya>0'da
                    # bir model açık fırında bağlı olduğu hâlde hiç üretmeden durabiliyor ve
                    # üretim ile kullanılan kalıp/tur kapasitesi bağı kopuyordu. Doğrusu:
                    #  - brüt üretim <= kullanılan kalıp sayısı × ÜRETİM turu (tur − setup),
                    #  - üretim varsa model aktif (sum <= cap * active),
                    #  - model aktifse (açık+bağlı) en az 1 birim üretir (sum >= active).
                    active_m = self.active_sag[(furnace, m, shift.index)]
                    mold_m = self.model_molds_sag[(furnace, m, shift.index)]
                    model_gross_terms = [
                        self.gross[(product, furnace, shift.index)]
                        for product in self.products
                        if self.product_model[product] == m
                        and (product, furnace, shift.index) in self.gross
                    ]
                    if model_gross_terms:
                        # Gerçek kapasite = kalıp × üretim turu. Bu iki değişkenin çarpımı
                        # olduğundan (mold_m × prod_turns_f) doğrusal değildir; CP-SAT'ın
                        # AddMultiplicationEquality kısıtıyla tam olarak modellenir. Böylece
                        # setup olan vardiyalarda setup turlarının yediği kapasite üretime
                        # sayılmaz (önceki `tur × kalıp` sınırı setup turunu düşmüyordu).
                        mold_cap_m = self.data.sag_mold_capacity.get(m, 0)
                        prod_cap_m = self.model.NewIntVar(
                            0,
                            max(0, mold_cap_m * shift_cap),
                            f"prod_cap_{furnace}_{m}_{shift.index}",
                        )
                        self.model.AddMultiplicationEquality(prod_cap_m, [mold_m, prod_turns_f])
                        self.model.Add(sum(model_gross_terms) <= prod_cap_m)
                        self.model.Add(sum(model_gross_terms) <= cap * active_m)
                        self.model.Add(sum(model_gross_terms) >= active_m)

                    model_net_terms = [
                        self.net[(product, furnace, shift.index)]
                        for product in self.products
                        if self.product_model[product] == m
                        and (product, furnace, shift.index) in self.net
                    ]
                    net_this_shift = sum(model_net_terms) if model_net_terms else 0
                    campaign_net = self.campaign_net_sag[(furnace, m, shift.index)]
                    current_bound = self.bound_sag[(furnace, m, shift.index)]
                    if shift.index == 0:
                        initial_net = self.data.initial_campaign_net.get((furnace, m), 0)
                        if self.data.initial_furnace_models.get((furnace, m), 0) > 0:
                            self.model.Add(campaign_net == initial_net + net_this_shift).OnlyEnforceIf(
                                current_bound
                            )
                        else:
                            self.model.Add(campaign_net == net_this_shift).OnlyEnforceIf(
                                current_bound
                            )
                        self.model.Add(campaign_net == 0).OnlyEnforceIf(current_bound.Not())
                    else:
                        previous_bound = self.bound_sag[(furnace, m, shift.index - 1)]
                        previous_campaign_net = self.campaign_net_sag[(furnace, m, shift.index - 1)]
                        self.model.Add(campaign_net == previous_campaign_net + net_this_shift).OnlyEnforceIf(
                            [previous_bound, current_bound]
                        )
                        self.model.Add(campaign_net == net_this_shift).OnlyEnforceIf(
                            [previous_bound.Not(), current_bound]
                        )
                        self.model.Add(campaign_net == 0).OnlyEnforceIf(current_bound.Not())

                total_completed_setup = sum(
                    self.carry_setup_turns[(furnace, a, b, shift.index)]
                    + self.new_setup_turns[(furnace, a, b, shift.index)]
                    for a, b in transitions
                )
                total_required_setup = self.model.NewIntVar(
                    0,
                    sum(self.data.sag_mold_capacity.get(model, 0) for model in compatible_models),
                    f"total_required_setup_{furnace}_{shift.index}",
                )
                total_mold_increase = sum(total_mold_increase_terms) if total_mold_increase_terms else 0
                total_mold_decrease = sum(total_mold_decrease_terms) if total_mold_decrease_terms else 0
                self.model.AddMaxEquality(
                    total_required_setup,
                    [total_mold_increase, total_mold_decrease],
                )
                self.model.Add(total_completed_setup == total_required_setup)

                # Clear carry first: cannot start a setup to/from any model if there is remaining carry from previous shift
                if shift.index > 0:
                    M_cap = 100
                    prev_carry_total = sum(self.setup_carry[(furnace, x, y, shift.index - 1)] for x, y in transitions)
                    previous_carry_clear = self.model.NewBoolVar(
                        f"previous_setup_carry_clear_{furnace}_{shift.index}"
                    )
                    self.model.Add(prev_carry_total == 0).OnlyEnforceIf(previous_carry_clear)
                    self.model.Add(prev_carry_total >= 1).OnlyEnforceIf(previous_carry_clear.Not())
                    for source, target in transitions:
                        max_setup = max(
                            self.data.sag_mold_capacity.get(source, 0) if source != "Yok" else 0,
                            self.data.sag_mold_capacity.get(target, 0) if target != "Yok" else 0,
                        )
                        self.model.Add(
                            self.setup_start[(furnace, source, target, shift.index)]
                            <= max_setup * previous_carry_clear
                        )
                else:
                    initial_carry_sum = sum(self.data.initial_setup_carry.get((furnace, x, y), 0) for x, y in transitions)
                    if initial_carry_sum > 0:
                        for source, target in transitions:
                            max_setup = max(
                                self.data.sag_mold_capacity.get(source, 0) if source != "Yok" else 0,
                                self.data.sag_mold_capacity.get(target, 0) if target != "Yok" else 0,
                            )
                            self.model.Add(
                                self.setup_start[(furnace, source, target, 0)]
                                <= max_setup * self.initial_setup_carry_cleared[(furnace, 0)]
                            )

        for model in self.data.models:
            mold_cap = self.data.sag_mold_capacity.get(model)
            if mold_cap is None:
                continue
            for shift in self.shifts:
                mold_terms = [
                    self.model_molds_sag[(furnace, model, shift.index)]
                    for furnace in self.data.sag_furnaces
                    if (furnace, model, shift.index) in self.model_molds_sag
                ]
                if mold_terms:
                    self.model.Add(sum(mold_terms) <= mold_cap)

        for product in self.products:
            for shift in self.shifts:
                sag_furnace_terms = [
                    self.sag_product_active[(product, furnace, shift.index)]
                    for furnace in self.data.sag_furnaces
                    if (product, furnace, shift.index) in self.sag_product_active
                ]
                if len(sag_furnace_terms) > 1:
                    self.model.Add(sum(sag_furnace_terms) <= 1)
                pres_active = self.pres_product_active.get((product, shift.index))
                if (
                    pres_active is not None
                    and sag_furnace_terms
                    and not self._sag_pres_parallel_allowed(product, shift.index)
                ):
                    self.model.Add(sum(sag_furnace_terms) + pres_active <= 1)

        for furnace, model in self.campaign_active_sag:
            is_exempt = self.data.initial_campaign_moq_exempt.get((furnace, model), False)
            moq = self.data.sag_moq.get(model, 0)
            if moq <= 0:
                continue
            for shift in self.shifts:
                unbound = self.sag_unbound[(furnace, model, shift.index)]
                if shift.index == 0:
                    campaign_before_shift = self.data.initial_campaign_net.get((furnace, model), 0)
                    if not (
                        is_exempt
                        and self.data.initial_furnace_models.get((furnace, model), 0) > 0
                    ) and campaign_before_shift < moq:
                        self.model.Add(unbound == 0)
                    continue

                campaign_before_shift = self.campaign_net_sag[
                    (furnace, model, shift.index - 1)
                ]
                if is_exempt:
                    initial_campaign_still_active_before_shift = self.initial_campaign_active_sag[
                        (furnace, model, shift.index - 1)
                    ]
                    self.model.Add(campaign_before_shift >= moq).OnlyEnforceIf(
                        [unbound, initial_campaign_still_active_before_shift.Not()]
                    )
                else:
                    self.model.Add(campaign_before_shift >= moq).OnlyEnforceIf(unbound)

        for shift in self.shifts:
            if shift.index in self.data.near_sag_opening:
                target = self.data.near_sag_opening[shift.index]
                open_terms = [
                    self.open_sag[(furnace, shift.index)] for furnace in self.data.sag_furnaces
                ]
                self.model.Add(sum(open_terms) + self.sag_open_deficit[shift.index] == target)

        for day_index, target in self.data.far_sag_opening.items():
            day_shifts = [shift for shift in self.shifts if shift.day_index == day_index]
            open_terms = [
                self.open_sag[(furnace, shift.index)]
                for furnace in self.data.sag_furnaces
                for shift in day_shifts
            ]
            self.model.Add(sum(open_terms) + self.sag_daily_deficit[day_index] == target)

        self._add_pres_capacity_constraints()

    def _add_pres_capacity_constraints(self) -> None:
        if PRES_FURNACE not in self.data.furnaces:
            return
        pres_models = self._compatible_models_for_furnace(PRES_FURNACE)
        for shift in self.shifts:
            active_vars = [self.active_pres[(model, shift.index)] for model in pres_models]
            open_var = self.open_pres[shift.index]
            if active_vars:
                self.model.Add(sum(active_vars) == open_var)
            else:
                self.model.Add(self.pres_change[shift.index] == 0)

            for model in pres_models:
                unbound = self.pres_unbound[(model, shift.index)]
                if shift.index > 0:
                    previous = self.active_pres[(model, shift.index - 1)]
                    current = self.active_pres[(model, shift.index)]
                    self.model.Add(unbound >= previous - current)
                    self.model.Add(unbound <= previous)
                    self.model.Add(unbound <= 1 - current)
                else:
                    initial_model = self._initial_pres_model()
                    current = self.active_pres[(model, shift.index)]
                    if initial_model == model:
                        self.model.Add(unbound == 1 - current)
                    else:
                        self.model.Add(unbound == 0)

                current = self.active_pres[(model, shift.index)]
                initial_campaign_active = self.initial_campaign_active_pres[(model, shift.index)]
                initial_model = self._initial_pres_model()
                if initial_model == model:
                    if shift.index == 0:
                        self.model.Add(initial_campaign_active == current)
                    else:
                        previous_initial_campaign = self.initial_campaign_active_pres[
                            (model, shift.index - 1)
                        ]
                        self.model.Add(initial_campaign_active <= previous_initial_campaign)
                        self.model.Add(initial_campaign_active <= current)
                        self.model.Add(
                            initial_campaign_active >= previous_initial_campaign + current - 1
                        )
                else:
                    self.model.Add(initial_campaign_active == 0)

                model_net_terms = [
                    net_var
                    for (product, furnace, t), net_var in self.net.items()
                    if furnace == PRES_FURNACE
                    and t == shift.index
                    and self.product_model[product] == model
                ]
                net_this_shift = sum(model_net_terms) if model_net_terms else 0
                campaign_net = self.campaign_net_pres[(model, shift.index)]
                if shift.index == 0:
                    initial_net = self.data.initial_campaign_net.get((PRES_FURNACE, model), 0)
                    if initial_model == model:
                        self.model.Add(campaign_net == initial_net + net_this_shift).OnlyEnforceIf(
                            current
                        )
                    else:
                        self.model.Add(campaign_net == net_this_shift).OnlyEnforceIf(current)
                    self.model.Add(campaign_net == 0).OnlyEnforceIf(current.Not())
                else:
                    previous = self.active_pres[(model, shift.index - 1)]
                    previous_campaign_net = self.campaign_net_pres[(model, shift.index - 1)]
                    self.model.Add(campaign_net == previous_campaign_net + net_this_shift).OnlyEnforceIf(
                        [previous, current]
                    )
                    self.model.Add(campaign_net == net_this_shift).OnlyEnforceIf(
                        [previous.Not(), current]
                    )
                    self.model.Add(campaign_net == 0).OnlyEnforceIf(current.Not())

            pres_gross_terms = [
                var
                for (product, furnace, t), var in self.gross.items()
                if furnace == PRES_FURNACE and t == shift.index
            ]
            # Press sürekli bir hattır: açık (çalışan) her vardiyada TAM kapasite üretir;
            # kalıp/model değişimi olan vardiyada 4 saatlik setup (PRES_CHANGE_CAPACITY_LOSS)
            # düşülür ve geriye kalan kapasiteyle üretir. Kısmi/boşta (idle) üretime izin yoktur:
            # bileşen (yarımamul/malzeme) tam kapasiteyi besleyemiyorsa bu durum çözümden ÖNCE
            # precheck aşamasında net hata olarak raporlanır (bkz. validation: pres kapasite
            # beslemesi). Bu yüzden eski "pres_slack" gevşetme valfi kaldırıldı (0'a sabitlendi).
            self.model.Add(self.pres_slack[shift.index] == 0)
            self.model.Add(
                sum(pres_gross_terms)
                + PRES_CHANGE_CAPACITY_LOSS * self.pres_change[shift.index]
                == PRES_CAPACITY * open_var
            )

            for product in self.products:
                key = (product, PRES_FURNACE, shift.index)
                if key not in self.gross:
                    continue
                model = self.product_model[product]
                active = self.active_pres.get((model, shift.index))
                if active is None:
                    self.model.Add(self.gross[key] == 0)
                else:
                    self.model.Add(self.gross[key] <= PRES_CAPACITY * active)

            if active_vars:
                self._link_pres_change(shift, pres_models)
        self._add_pres_v710_transition_constraints(pres_models)

    def _add_pres_v710_transition_constraints(self, pres_models: list[str]) -> None:
        non_v710_models = [model for model in pres_models if model != "V710"]
        if not non_v710_models:
            return

        initial_model = self._initial_pres_model()
        
        # Calculate urgent orders for LSF-12 exception
        self.urgent_orders = [order for order in self.orders if order.urgent]

        for shift in self.shifts:
            t = shift.index
            self.v710_exception[t] = self.model.NewBoolVar(f"v710_exception_{t}")
            
            urgent_orders_at_t = [
                o for o in self.urgent_orders
                if t <= o.due_shift < t + 5 and o.model in non_v710_models
            ]
            
            order_vars = []
            for o in urgent_orders_at_t:
                var = self.model.NewBoolVar(f"v710_exception_order_{o.order_id}_{t}")
                self.v710_exception_order[(o.order_id, t)] = var
                order_vars.append(var)
                
                self.model.Add(var <= self.active_pres[(o.model, t)])
                if t > 0:
                    other_active = [
                        self.active_pres[(A, t - 1)]
                        for A in non_v710_models
                        if A != o.model and (A, t - 1) in self.active_pres
                    ]
                    if other_active:
                        self.model.Add(var <= sum(other_active))
                    else:
                        self.model.Add(var == 0)
                else:
                    if initial_model and initial_model in non_v710_models and initial_model != o.model:
                        pass
                    else:
                        self.model.Add(var == 0)
            
            if order_vars:
                self.model.Add(self.v710_exception[t] <= sum(order_vars))
            else:
                self.model.Add(self.v710_exception[t] == 0)

        for shift in self.shifts:
            self._add_pres_moq_before_leaving_constraints(shift, pres_models, initial_model)
            for source in non_v710_models:
                for target in non_v710_models:
                    if source == target:
                        continue
                    current = self.active_pres.get((target, shift.index))
                    if current is None:
                        continue
                    if shift.index == 0:
                        if initial_model == source:
                            self.model.Add(current == 0)
                        continue
                    previous = self.active_pres.get((source, shift.index - 1))
                    if previous is not None:
                        self.model.Add(previous + current <= 1 + self.v710_exception[shift.index])

            if "V710" not in pres_models:
                continue
            is_v710_exempt = self.data.initial_campaign_moq_exempt.get((PRES_FURNACE, "V710"), False)
            moq_v710 = 0 if is_v710_exempt else PRES_MOQ
            v710_done_before_shift = self._pres_model_net_until("V710", shift.index - 1)
            initial_v710 = self.data.initial_campaign_net.get((PRES_FURNACE, "V710"), 0)
            cumulative_v710_before_shift = v710_done_before_shift + initial_v710
            for target in non_v710_models:
                current = self.active_pres.get((target, shift.index))
                if current is None:
                    continue
                if shift.index == 0:
                    if initial_model == "V710":
                        self.model.Add(cumulative_v710_before_shift >= moq_v710 * current)
                    continue
                previous_v710 = self.active_pres.get(("V710", shift.index - 1))
                if previous_v710 is not None:
                    self.model.Add(
                        cumulative_v710_before_shift
                        >= moq_v710 - moq_v710 * (2 - previous_v710 - current)
                    )

    def _add_pres_moq_before_leaving_constraints(
        self,
        shift: Shift,
        pres_models: list[str],
        initial_model: str | None,
    ) -> None:
        for source in pres_models:
            is_exempt = self.data.initial_campaign_moq_exempt.get((PRES_FURNACE, source), False)
            for target in pres_models:
                if source == target:
                    continue
                current = self.active_pres.get((target, shift.index))
                if current is None:
                    continue
                if shift.index == 0:
                    if initial_model == source:
                        initial_source = self.data.initial_campaign_net.get((PRES_FURNACE, source), 0)
                        if not is_exempt and initial_source < PRES_MOQ:
                            self.model.Add(current == 0)
                    continue
                previous_source = self.active_pres.get((source, shift.index - 1))
                if previous_source is not None:
                    campaign_before_shift = self.campaign_net_pres[(source, shift.index - 1)]
                    if is_exempt:
                        initial_campaign_still_active_before_shift = self.initial_campaign_active_pres[
                            (source, shift.index - 1)
                        ]
                        self.model.Add(campaign_before_shift >= PRES_MOQ).OnlyEnforceIf(
                            [
                                previous_source,
                                current,
                                initial_campaign_still_active_before_shift.Not(),
                            ]
                        )
                    else:
                        self.model.Add(campaign_before_shift >= PRES_MOQ).OnlyEnforceIf(
                            [previous_source, current]
                        )

    def _link_pres_change(self, shift: Shift, pres_models: list[str]) -> None:
        current_change = self.pres_change[shift.index]
        curr_open_val = getattr(shift, "pres_available", 1)
        if curr_open_val == 0:
            self.model.Add(current_change == 0)
            return

        if shift.index == 0:
            initial_model = self._initial_pres_model()
            if initial_model is None or initial_model not in pres_models:
                self.model.Add(current_change == 0)
                return
            for model in pres_models:
                active = self.active_pres[(model, shift.index)]
                initial = 1 if model == initial_model else 0
                self.model.Add(current_change >= active - initial)
                self.model.Add(current_change >= initial - active)
                if initial:
                    self.model.Add(current_change <= 1 - active)
            return

        previous_index = shift.index - 1
        prev_open_val = getattr(self.shifts[previous_index], "pres_available", 1)
        if prev_open_val == 0:
            self.model.Add(current_change == 0)
            return

        for model in pres_models:
            current = self.active_pres[(model, shift.index)]
            previous = self.active_pres[(model, previous_index)]
            self.model.Add(current_change >= current - previous)
            self.model.Add(current_change >= previous - current)
            self.model.Add(current_change <= 2 - current - previous)

    def _add_stock_constraints(self) -> None:
        orders_by_product: defaultdict[str, list[OrderInfo]] = defaultdict(list)
        for order in self.orders:
            orders_by_product[order.product].append(order)

        for product in self.products:
            initial = self.data.initial_fg_stock.get(product, 0)
            for shift in self.shifts:
                production = sum(
                    var
                    for (p, _f, t), var in self.net.items()
                    if p == product and t == shift.index
                )
                shipments = sum(
                    self.ship[(order.order_id, shift.index)]
                    for order in orders_by_product.get(product, [])
                )
                stock_var = self.fg_stock[(product, shift.index)]
                if shift.index == 0:
                    self.model.Add(stock_var == initial + production - shipments)
                else:
                    previous_stock = self.fg_stock[(product, shift.index - 1)]
                    self.model.Add(stock_var == previous_stock + production - shipments)

            final_stock = self.fg_stock[(product, self.shifts[-1].index)]
            max_stock = self.data.products[product].max_stock
            excess = self.final_stock_excess[product]
            self.model.Add(excess >= final_stock - max_stock)
            self.model.Add(excess >= 0)

    def _add_order_priority_constraints(self) -> None:
        open_orders_by_product: defaultdict[str, list[OrderInfo]] = defaultdict(list)
        for order in self.orders:
            open_orders_by_product[order.product].append(order)

        for order in self.orders:
            for shift in self.shifts:
                cumulative_ship = sum(
                    self.ship[(order.order_id, prior_shift.index)]
                    for prior_shift in self.shifts
                    if prior_shift.index <= shift.index
                )
                complete = self.order_complete[(order.order_id, shift.index)]
                self.model.Add(cumulative_ship >= order.open_quantity * complete)
                self.model.Add(
                    cumulative_ship
                    <= (order.open_quantity - 1) + order.open_quantity * complete
                )

        for product_orders in open_orders_by_product.values():
            sorted_orders = sorted(
                product_orders,
                key=lambda order: (0 if order.order_type == "OEM" else 1, order.due_shift, order.order_id),
            )
            for earlier_index, earlier in enumerate(sorted_orders):
                for later in sorted_orders[earlier_index + 1 :]:
                    for shift in self.shifts:
                        self.model.Add(
                            self.ship[(later.order_id, shift.index)]
                            <= later.open_quantity * self.order_complete[(earlier.order_id, shift.index)]
                        )

    def _add_unbound_completion_constraints(self) -> None:
        for furnace in self.data.furnaces:
            furnace_type = self.data.furnaces[furnace].furnace_type
            compatible_models = self._compatible_models_for_furnace(furnace)
            
            for model in compatible_models:
                model_orders = [o for o in self.orders if o.model == model]
                if not model_orders:
                    continue
                    
                for shift in self.shifts:
                    t = shift.index
                    if furnace_type == "Pres":
                        unbound_var = self.pres_unbound.get((model, t))
                    else:
                        unbound_var = self.sag_unbound.get((furnace, model, t))
                        
                    if unbound_var is None:
                        continue
                        
                    due_orders = [o for o in model_orders if o.due_shift <= t]
                    for o in due_orders:
                        slack_var = self.model.NewIntVar(
                            0,
                            o.quantity,
                            f"unbound_slack_{o.order_id}_{furnace}_{t}",
                        )
                        self.unbound_slack[(o.order_id, furnace, t)] = slack_var
                        
                        ship_vars = [
                            self.ship[(o.order_id, t_prime.index)]
                            for t_prime in self.shifts
                            if t_prime.index <= t and (o.order_id, t_prime.index) in self.ship
                        ]
                        
                        self.model.Add(
                            sum(ship_vars) + o.initial_allocated + slack_var >= o.quantity * unbound_var
                        )

    def _add_unbound_open_order_slack_constraints(self) -> None:
        for furnace in self.data.furnaces:
            furnace_type = self.data.furnaces[furnace].furnace_type
            compatible_models = self._compatible_models_for_furnace(furnace)

            for model in compatible_models:
                model_orders = [o for o in self.orders if o.model == model]
                if not model_orders:
                    continue

                for shift in self.shifts:
                    t = shift.index
                    if furnace_type == "Pres":
                        unbound_var = self.pres_unbound.get((model, t))
                    else:
                        unbound_var = self.sag_unbound.get((furnace, model, t))

                    if unbound_var is None:
                        continue

                    future_orders = [o for o in model_orders if o.due_shift > t]
                    for order in future_orders:
                        slack_var = self.model.NewIntVar(
                            0,
                            order.quantity,
                            f"unbound_open_order_slack_{order.order_id}_{furnace}_{t}",
                        )
                        self.unbound_open_order_slack[(order.order_id, furnace, t)] = slack_var

                        ship_vars = [
                            self.ship[(order.order_id, prior_shift.index)]
                            for prior_shift in self.shifts
                            if prior_shift.index <= t
                            and (order.order_id, prior_shift.index) in self.ship
                        ]

                        self.model.Add(
                            sum(ship_vars) + order.initial_allocated + slack_var
                            >= order.quantity * unbound_var
                        )

    def _add_component_constraints(self) -> None:
        for component in self._material_components():
            for shift in self.shifts:
                consumption_terms = self._component_consumption_terms(component, "Malzeme", shift.index)
                available = self.data.initial_material_stock_scaled.get(component, 0)
                available += sum(
                    qty
                    for (arrival_component, arrival_shift), qty in self.data.material_arrivals_scaled.items()
                    if arrival_component == component and arrival_shift <= shift.index
                )
                if consumption_terms:
                    self.model.Add(sum(consumption_terms) <= available)

        all_semis = set(self._semi_components())
        for comp in self.data.initial_semi_stock_scaled:
            all_semis.add(comp)
            
        components_by_root = defaultdict(list)
        for comp in all_semis:
            root, suffix = get_semi_root_and_suffix(comp)
            components_by_root[root].append(comp)
            
        for root, comps in sorted(components_by_root.items()):
            has_M = (root + "M") in all_semis
            has_M1 = (root + "M1") in all_semis
            has_M2 = (root + "M2") in all_semis
            
            for shift in self.shifts:
                total_M_terms = []
                if has_M:
                    m_comp = root + "M"
                    total_M_terms.append(self.data.initial_semi_stock_scaled.get(m_comp, 0))
                    total_M_terms.append(self._semi_prep_carry_available_scaled(m_comp, shift.index))
                    total_M_terms.append(sum(
                        self.semi_prep[(m_comp, prep_shift.index)]
                        for prep_shift in self.shifts
                        if prep_shift.index + 2 <= shift.index
                    ))
                total_M = sum(total_M_terms) if total_M_terms else 0
                
                if has_M1 and has_M2:
                    m1_comp = root + "M1"
                    m2_comp = root + "M2"
                    
                    total_M1 = self.data.initial_semi_stock_scaled.get(m1_comp, 0) + sum(
                        self.semi_prep[(m1_comp, prep_shift.index)]
                        for prep_shift in self.shifts
                        if prep_shift.index + 2 <= shift.index
                    ) + self._semi_prep_carry_available_scaled(m1_comp, shift.index)
                    
                    total_M2 = self.data.initial_semi_stock_scaled.get(m2_comp, 0) + sum(
                        self.semi_prep[(m2_comp, prep_shift.index)]
                        for prep_shift in self.shifts
                        if prep_shift.index + 2 <= shift.index
                    ) + self._semi_prep_carry_available_scaled(m2_comp, shift.index)
                    
                    paired_var = self.model.NewIntVar(0, 1_000_000_000, f"paired_avail_{root}_{shift.index}")
                    self.model.Add(paired_var <= total_M1)
                    self.model.Add(paired_var <= total_M2)
                    available = total_M + paired_var
                else:
                    # M1 veya M2 tek başına kullanılamaz (alt/üst cam gibi; ancak ikisi
                    # birleşince yarımamul oluşur). Yalnız biri tanımlıysa çift kaynak 0'dır;
                    # bu kökten kullanılabilir miktar yalnız doğrudan M stokudur (spec 6.3).
                    available = total_M
                    
                consumption_terms = self._root_consumption_terms(root, shift.index)
                if consumption_terms:
                    self.model.Add(sum(consumption_terms) <= available)


    def _get_structural_rewards(self) -> cp_model.LinearExpr:
        terms = []
        for var in self.pres_slack.values():
            terms.append(-350 * var)
        for var in self.sag_open_deficit.values():
            terms.append(-180_000 * var)
        for var in self.sag_daily_deficit.values():
            terms.append(-180_000 * var)
        for var in self.v710_exception.values():
            terms.append(-150_000 * var)
        for var in self.unbound_slack.values():
            terms.append(-500_000 * var)
        for var in self.unbound_open_order_slack.values():
            terms.append(-500_000 * var)
            
        # Kalıp değişim (setup) turları bir KAYIPTIR: üretime gidecek turu yer, dolayısıyla
        # her setup turu net negatif katkı yapmalıdır. Önceki sürümde setup turları POZİTİF
        # ödüllendiriliyordu (recency ağırlıklı); ödül turun gerekliliğine değil sadece
        # sayısına bağlı olduğundan optimizatör gereksiz setup üretiyordu: kalıbı söküp
        # (X->Yok, bu söküm sag_new_setup_start cezasına da girmez) boş maketle vagonu
        # doldurup birkaç vardiya sonra aynı kalıbı tekrar takarak ödül topluyordu. Doğrusu
        # her tamamlanan setup turunu cezalandırmak; geç vardiyaları daha ağır cezalandırarak
        # ZORUNLU setup'ların erken tamamlanmasını hâlâ teşvik etmek. Carry tamamlama ve yeni
        # setup turu aynı (shift_index'e bağlı) ağırlıkla cezalandığından setup'ı bilerek
        # bölüp sonraki vardiyaya sarkıtmak da her zaman daha pahalı kalır; fantom carry oluşmaz.
        for key, var in self.carry_setup_turns.items():
            shift_index = key[3]
            terms.append(-10_000 * (shift_index + 1) * var)
        for key, var in self.new_setup_turns.items():
            shift_index = key[3]
            terms.append(-10_000 * (shift_index + 1) * var)

        return sum(terms)

    def _get_order_rewards(self, order_type: str) -> cp_model.LinearExpr:
        terms = []
        order_by_id = {order.order_id: order for order in self.orders}
        for (order_id, shift_index), var in self.ship.items():
            order = order_by_id[order_id]
            if order.order_type != order_type:
                continue
            timely = shift_index <= order.due_shift
            if order.order_type == "OEM":
                base = 120_000 if timely else 70_000
                late_step = 500
            else:
                base = 80_000 if timely else 45_000
                late_step = 300
            coefficient = max(1, base - max(0, shift_index - order.due_shift) * late_step)
            terms.append(coefficient * var)
        return sum(terms) if terms else 0

    def _get_obj1(self) -> cp_model.LinearExpr:
        return self._get_order_rewards("OEM")

    def _get_obj2(self) -> cp_model.LinearExpr:
        return self._get_order_rewards("OYC")

    def _get_obj3(self) -> cp_model.LinearExpr:
        terms = []
        for var in self.gross.values():
            terms.append(-1 * var)
        for var in self.sag_new_setup_start.values():
            terms.append(-5_000 * var)
        for var in self.semi_prep.values():
            terms.append(-1 * var)
        for var in self.final_stock_excess.values():
            terms.append(-2_000 * var)
        for var in self.pres_change.values():
            terms.append(-200_000 * var)
            
        return sum(terms) + self._get_structural_rewards()

    def _extract_tables(self, solver: cp_model.CpSolver) -> dict[str, pd.DataFrame]:
        production_rows = self._production_rows(solver)
        furnace_rows = self._furnace_rows(solver, production_rows)
        shipment_rows, order_rows = self._shipment_and_order_rows(solver)
        stock_rows = self._stock_rows(solver)
        material_rows = self._material_flow_rows(solver)
        semi_rows = self._semi_flow_rows(solver)
        warning_rows = self._warning_rows(solver, order_rows)
        decision_rows = self._decision_rows(solver, warning_rows)

        tables = {
            "Saha_Is_Emri": pd.DataFrame(self._field_order_rows(production_rows, furnace_rows)),
            "Firin_Durum_Ozeti": pd.DataFrame(self._furnace_status_rows(furnace_rows)),
            "Firin_Vardiya_Gantt": pd.DataFrame(self._gantt_rows(production_rows, furnace_rows)),
            "Kalip_Degisim_Talimati": pd.DataFrame(self._change_instruction_rows(solver)),
            "Siparis": pd.DataFrame(order_rows),
            "Siparis_Karsilama": pd.DataFrame(shipment_rows),
            "Uretim": pd.DataFrame(production_rows),
            "Firin_Kullanim": pd.DataFrame(furnace_rows),
            "SAG_Setup": pd.DataFrame(self._sag_setup_rows(solver)),
            "LSF12_Sira": pd.DataFrame(self._lsf12_rows(solver)),
            "Kampanya_Carry": pd.DataFrame(self._campaign_rows(solver, production_rows)),
            "Stok": pd.DataFrame(stock_rows),
            "Malzeme_Akisi": pd.DataFrame(material_rows),
            "Yarimamul_Akisi": pd.DataFrame(semi_rows),
            "Plan_Karar_Aciklamalari": pd.DataFrame(decision_rows),
            "Vardiya_Uyarilari": pd.DataFrame(warning_rows),
            "Darbogazlar": pd.DataFrame(self._bottleneck_rows(solver, order_rows)),
            "Neden_Kodlari": pd.DataFrame(self._reason_rows(solver, order_rows)),
            "Carry_Out": pd.DataFrame(self._carry_out_rows(solver)),
            "Precheck_Hatalari": pd.DataFrame(columns=PRECHECK_COLUMNS),
            "Precheck_Infeasible": pd.DataFrame(columns=INFEASIBLE_COLUMNS),
        }
        return tables

    def _production_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        production_id = 1
        for shift in self.shifts:
            for furnace in self.furnaces:
                for product in self.products:
                    key = (product, furnace, shift.index)
                    if key not in self.gross:
                        continue
                    gross = solver.Value(self.gross[key])
                    net = solver.Value(self.net[key])
                    if gross <= 0 and net <= 0:
                        continue
                    info = self.data.products[product]
                    furnace_type = self.data.furnaces[furnace].furnace_type
                    yield_scaled = self.data.compatibility[(furnace, product)]
                    is_sag = furnace_type == "SAG"
                    sag_molds = (
                        solver.Value(self.model_molds_sag[(furnace, info.model, shift.index)])
                        if is_sag and (furnace, info.model, shift.index) in self.model_molds_sag
                        else 0
                    )
                    sag_prod_turns = ceil(gross / max(1, sag_molds)) if is_sag and gross > 0 else 0
                    pres_limit = self._pres_capacity_at(solver, shift.index) if furnace == PRES_FURNACE else 0
                    has_material = any(
                        p == product and component_type == "Malzeme"
                        for p, _component, component_type in self.data.component_qty_scaled
                    )
                    rows.append(
                        {
                            "Üretim ID": f"URT{production_id:06d}",
                            "Tarih": shift.date.isoformat(),
                            "Vardiya": shift.shift_no,
                            "Vardiya Sıra No": shift.index + 1,
                            "Fırın Adı": furnace,
                            "Fırın Tipi": furnace_type,
                            "Segment Tipi": "Pres Geçiş"
                            if furnace == PRES_FURNACE and solver.Value(self.pres_change[shift.index])
                            else ("Pres Normal" if furnace == PRES_FURNACE else "Normal"),
                            "Kampanya ID": f"KMP-{furnace}-{info.model}",
                            "Model Kodu": info.model,
                            "Model Tanımı": info.model_name,
                            "Bitmiş Ürün Kodu": product,
                            "Brüt Üretim Adedi": gross,
                            "Randıman": round(yield_scaled / SCALE, 4),
                            "Net Üretim Adedi": net,
                            "Stok Giriş Tarihi": shift.date.isoformat(),
                            "Stok Giriş Vardiyası": shift.shift_no,
                            "SAG Kalıp Sayısı": sag_molds,
                            "SAG Üretim Tur Sayısı": sag_prod_turns,
                            "Pres Kapasite Limiti": pres_limit,
                            "Satın Alınan Malzeme Var mı?": "Evet" if has_material else "Hayır",
                            "Malzeme Kullanım Tarihi": shift.date.isoformat() if has_material else "Yok",
                            "Malzeme Kullanım Vardiyası": shift.shift_no if has_material else "Yok",
                        }
                    )
                    production_id += 1
        return rows

    def _furnace_rows(
        self,
        solver: cp_model.CpSolver,
        production_rows: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        production_by_furnace_shift: defaultdict[tuple[str, int], list[dict[str, Any]]] = defaultdict(list)
        for row in production_rows:
            production_by_furnace_shift[(row["Fırın Adı"], row["Vardiya Sıra No"] - 1)].append(row)

        for shift in self.shifts:
            for furnace in self.furnaces:
                furnace_type = self.data.furnaces[furnace].furnace_type
                production = production_by_furnace_shift[(furnace, shift.index)]
                total_gross = sum(int(row["Brüt Üretim Adedi"]) for row in production)
                total_net = sum(int(row["Net Üretim Adedi"]) for row in production)
                model_codes = sorted({row["Model Kodu"] for row in production})
                product_codes = sorted({row["Bitmiş Ürün Kodu"] for row in production})
                if furnace_type == "SAG":
                    is_open = solver.Value(self.open_sag[(furnace, shift.index)])
                    compatible_models = self._compatible_models_for_furnace(furnace)
                    M0 = compatible_models + ["Yok"]
                    transitions = [(a, b) for a in M0 for b in M0 if a != b]
                    carry_setup_turns = sum(
                        solver.Value(self.carry_setup_turns[(furnace, a, b, shift.index)])
                        for a, b in transitions
                    )
                    new_setup_turns = sum(
                        solver.Value(self.new_setup_turns[(furnace, a, b, shift.index)])
                        for a, b in transitions
                    )
                    setup_turns = carry_setup_turns + new_setup_turns
                    bound_model_codes = [
                        model
                        for (f, model, t), var in self.bound_sag.items()
                        if f == furnace and t == shift.index and solver.Value(var)
                    ]
                    sag_molds = sum(
                        solver.Value(var)
                        for (f, _model, t), var in self.model_molds_sag.items()
                        if f == furnace and t == shift.index
                    )
                    mandatory = sum(self.data.mandatory_dummy.get(model, 0) for model in bound_model_codes)
                    wagons = self.data.sag_wagons.get(furnace, 0)
                    optional = max(0, wagons - sag_molds - setup_turns - mandatory) if is_open else 0
                    production_turns = self.data.sag_turns.get(furnace, 0) - setup_turns if is_open else 0
                    used_wagons = wagons if is_open else 0
                    pres_limit = 0
                    pres_used = 0
                else:
                    is_open = 1
                    sag_molds = 0
                    mandatory = 0
                    optional = 0
                    wagons = 0
                    setup_turns = 0
                    production_turns = 0
                    used_wagons = 0
                    pres_limit = self._pres_capacity_at(solver, shift.index)
                    pres_used = total_gross

                rows.append(
                    {
                        "Tarih": shift.date.isoformat(),
                        "Vardiya": shift.shift_no,
                        "Vardiya Sıra No": shift.index + 1,
                        "Fırın Adı": furnace,
                        "Fırın Tipi": furnace_type,
                        "Fırın Durumu": "Açık" if is_open else "Kapalı",
                        "Ana İş Tipi": "Kapalı"
                        if not is_open
                        else (
                            "Üretim + Setup"
                            if furnace == PRES_FURNACE and solver.Value(self.pres_change[shift.index])
                            else ("Üretim" if total_gross > 0 else "Boş")
                        ),
                        "Aktif Model Sayısı": len(model_codes),
                        "Üretilen Ürün Sayısı": len(product_codes),
                        "Toplam Brüt Üretim": total_gross,
                        "Toplam Net Üretim": total_net,
                        "SAG Tur Kapasitesi": self.data.sag_turns.get(furnace, 0) if furnace_type == "SAG" else 0,
                        "SAG Setup Turu": setup_turns,
                        "SAG Üretim Turu": production_turns,
                        "SAG Vagon Kapasitesi": wagons,
                        "SAG Üretim Kalıbı Sayısı": sag_molds,
                        "SAG Setup Kalıbı Sayısı": setup_turns,
                        "SAG Mecburi Maket Sayısı": mandatory,
                        "SAG Opsiyonel Maket Sayısı": optional,
                        "SAG Kullanılan Vagon": used_wagons,
                        "Pres Kapasite Limiti": pres_limit,
                        "Pres Kullanılan Kapasite": pres_used,
                        "İlgili Üretim ID'leri": ", ".join(row["Üretim ID"] for row in production) or "Yok",
                    }
                )
        return rows

    def _shipment_and_order_rows(
        self,
        solver: cp_model.CpSolver,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        shipment_rows: list[dict[str, Any]] = []
        order_rows: list[dict[str, Any]] = []
        shipment_id = 1
        all_orders = list(self.data.orders)
        orders_by_id = {order.order_id: order for order in self.orders}

        for order in all_orders:
            timely = 0
            late = 0
            if order.initial_allocated:
                timely += order.initial_allocated
                shipment_rows.append(
                    {
                        "Karşılama ID": f"KRS{shipment_id:06d}",
                        "Sipariş ID": order.order_id,
                        "Bitmiş Ürün Kodu": order.product,
                        "Sipariş Türü": order.order_type,
                        "Kaynak": "Başlangıç Stok",
                        "Tarih": self.shifts[0].date.isoformat(),
                        "Vardiya": 1,
                        "Vardiya Sıra No": 1,
                        "Karşılanan Miktar": order.initial_allocated,
                        "Termin İçi mi?": "Evet",
                    }
                )
                shipment_id += 1

            if order.order_id in orders_by_id:
                for shift in self.shifts:
                    qty = solver.Value(self.ship[(order.order_id, shift.index)])
                    if qty <= 0:
                        continue
                    if shift.index <= order.due_shift:
                        timely += qty
                    else:
                        late += qty
                    shipment_rows.append(
                        {
                            "Karşılama ID": f"KRS{shipment_id:06d}",
                            "Sipariş ID": order.order_id,
                            "Bitmiş Ürün Kodu": order.product,
                            "Sipariş Türü": order.order_type,
                            "Kaynak": "Üretim/Stok",
                            "Tarih": shift.date.isoformat(),
                            "Vardiya": shift.shift_no,
                            "Vardiya Sıra No": shift.index + 1,
                            "Karşılanan Miktar": qty,
                            "Termin İçi mi?": "Evet" if shift.index <= order.due_shift else "Hayır",
                        }
                    )
                    shipment_id += 1
            open_qty = max(0, order.quantity - timely - late)
            first_ship = next((row for row in shipment_rows if row["Sipariş ID"] == order.order_id), None)
            last_ship = next(
                (row for row in reversed(shipment_rows) if row["Sipariş ID"] == order.order_id),
                None,
            )
            order_rows.append(
                {
                    "Sipariş ID": order.order_id,
                    "Bitmiş Ürün Kodu": order.product,
                    "Model Kodu": order.model,
                    "Sipariş Türü": order.order_type,
                    "Termin Tarihi": order.due_date.isoformat(),
                    "Termin Vardiya Sıra No": order.due_shift + 1,
                    "Sipariş Miktarı": order.quantity,
                    "Başlangıç Stoktan Kapanan": order.initial_allocated,
                    "Zamanında Karşılanan": timely,
                    "Geç Karşılanan": late,
                    "Açık Miktar": open_qty,
                    "İlk Karşılama": _ship_label(first_ship),
                    "Son Karşılama": _ship_label(last_ship),
                    "Gecikme Var mı?": "Evet" if late > 0 or open_qty > 0 else "Hayır",
                    "Neden Kodu": "OPEN_DEMAND" if open_qty > 0 else ("LATE_CAPACITY" if late > 0 else "OK"),
                }
            )

        return shipment_rows, order_rows

    def _stock_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for product in self.products:
            for shift in self.shifts:
                start_stock = self.data.initial_fg_stock.get(product, 0) if shift.index == 0 else solver.Value(
                    self.fg_stock[(product, shift.index - 1)]
                )
                production = sum(
                    solver.Value(var)
                    for (p, _f, t), var in self.net.items()
                    if p == product and t == shift.index
                )
                shipments = sum(
                    solver.Value(var)
                    for (order_id, t), var in self.ship.items()
                    if t == shift.index and self._order_by_id(order_id).product == product
                )
                end_stock = solver.Value(self.fg_stock[(product, shift.index)])
                max_stock = self.data.products[product].max_stock
                rows.append(
                    {
                        "Tarih": shift.date.isoformat(),
                        "Vardiya": shift.shift_no,
                        "Vardiya Sıra No": shift.index + 1,
                        "Bitmiş Ürün Kodu": product,
                        "Model Kodu": self.product_model[product],
                        "Vardiya Başı Stok": start_stock,
                        "Üretimden Gelen": production,
                        "Siparişe Bağlanan": shipments,
                        "Vardiya Sonu Kullanılabilir Stok": end_stock,
                        "Azami Stok Miktarı": max_stock,
                        "Azami Stok Aşımı": max(0, end_stock - max_stock),
                        "İlgili Üretim ID'leri": "Yok",
                        "İlgili Karşılama ID'leri": "Yok",
                    }
                )
        return rows

    def _material_flow_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for component in self._material_components():
            stock = self.data.initial_material_stock_scaled.get(component, 0)
            for shift in self.shifts:
                incoming = sum(
                    qty
                    for (arrival_component, arrival_shift), qty in self.data.material_arrivals_scaled.items()
                    if arrival_component == component and arrival_shift == shift.index
                )
                used = self._component_used_scaled(solver, component, "Malzeme", shift.index)
                start = stock + incoming
                end = start - used
                rows.append(
                    {
                        "Tarih": shift.date.isoformat(),
                        "Vardiya": shift.shift_no,
                        "Vardiya Sıra No": shift.index + 1,
                        "Malzeme Kodu": component,
                        "Vardiya Başı Stok": round(scaled_to_float(stock), 3),
                        "Gelen Miktar": round(scaled_to_float(incoming), 3),
                        "Kullanılan Miktar": round(scaled_to_float(used), 3),
                        "Vardiya Sonu Stok": round(scaled_to_float(end), 3),
                        "İlgili Üretim ID'leri": "Yok",
                    }
                )
                stock = end
        return rows

    def _semi_flow_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        flows = self._simulate_semi_flow(solver)
        rows = []
        for component in sorted(flows.keys()):
            rows.extend(flows[component])
        return rows

    def _simulate_semi_flow(self, solver: cp_model.CpSolver) -> dict[str, list[dict[str, Any]]]:
        all_semis = set(self._semi_components())
        for comp in self.data.initial_semi_stock_scaled:
            all_semis.add(comp)
            
        components_by_root = defaultdict(list)
        for comp in all_semis:
            root, suffix = get_semi_root_and_suffix(comp)
            components_by_root[root].append(comp)
            
        flows = {comp: [] for comp in all_semis}
        stock = {comp: self.data.initial_semi_stock_scaled.get(comp, 0) for comp in all_semis}
        
        for shift in self.shifts:
            matured = {}
            for comp in all_semis:
                matured[comp] = (
                    solver.Value(self.semi_prep[(comp, shift.index - 2)]) if shift.index >= 2 else 0
                )
                matured[comp] += self._semi_prep_carry_maturing_scaled(comp, shift.index)
                stock[comp] += matured[comp]
                
            for root, comps in sorted(components_by_root.items()):
                used_r = 0
                for product in self.products:
                    q_M = self.data.component_qty_scaled.get((product, root + "M", "Yarımamul"), 0)
                    q_M1 = self.data.component_qty_scaled.get((product, root + "M1", "Yarımamul"), 0)
                    q_M2 = self.data.component_qty_scaled.get((product, root + "M2", "Yarımamul"), 0)
                    bom_semi = q_M + max(q_M1, q_M2)
                    if bom_semi <= 0:
                        continue
                    for (p, _f, t), net_var in self.net.items():
                        if p == product and t == shift.index:
                            used_r += bom_semi * solver.Value(net_var)
                            
                has_M = (root + "M") in all_semis
                has_M1 = (root + "M1") in all_semis
                has_M2 = (root + "M2") in all_semis
                
                total_M = stock.get(root + "M", 0) if has_M else 0
                total_M1 = stock.get(root + "M1", 0) if has_M1 else 0
                total_M2 = stock.get(root + "M2", 0) if has_M2 else 0
                
                # Tüketim, kısıttaki havuzlama (available = total_M + min(M1,M2)) ile aynı
                # sırada dağıtılır: önce M1+M2 çifti (yalnız ikisi de tanımlıysa), sonra
                # doğrudan M. Tek başına tanımlı M1 veya M2 KULLANILAMAZ (eşi yok), bu yüzden
                # tüketilmez ve stoku sabit kalır.
                remaining = used_r
                used_paired = 0
                if has_M1 and has_M2:
                    used_paired = min(remaining, min(total_M1, total_M2))
                    remaining -= used_paired
                used_M = min(remaining, total_M)
                remaining -= used_M

                for comp in comps:
                    root_c, suffix = get_semi_root_and_suffix(comp)
                    start_stock = stock[comp]
                    if suffix == "M":
                        used_comp = used_M
                    elif suffix in ("M1", "M2") and has_M1 and has_M2:
                        used_comp = used_paired
                    else:
                        used_comp = 0

                    stock[comp] = max(0, start_stock - used_comp)
                    prep = solver.Value(self.semi_prep[(comp, shift.index)])
                    flows[comp].append({
                        "Tarih": shift.date.isoformat(),
                        "Vardiya": shift.shift_no,
                        "Vardiya Sıra No": shift.index + 1,
                        "Yarımamul Kodu": comp,
                        "Vardiya Başı Stok": round(scaled_to_float(start_stock), 3),
                        "Kullanılan Miktar": round(scaled_to_float(used_comp), 3),
                        "Hazırlık Başlatılan Miktar": round(scaled_to_float(prep), 3),
                        "Vardiya Sonu Stok": round(scaled_to_float(stock[comp]), 3),
                        "İlgili Üretim ID'leri": "Yok",
                    })
        return flows

    def _warning_rows(self, solver: cp_model.CpSolver, order_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        warning_id = 1
        horizon_days = len(self.shifts) // 3 if self.shifts else 0
        horizon_end = self.shifts[-1].date.isoformat() if self.shifts else ""

        # Termini ufkun dışında olan siparişler ufkun içine çekilerek erkenden üretilir; bu
        # normal ve istenen davranıştır, ayrıca bayraklanmaz. Plan sonunda açık kalan siparişler
        # her zaman loglanır; "plan ufkuna sığmadı" ifadesi yalnızca termin ufkun dışındaysa kullanılır.
        for order in order_rows:
            open_qty = int(order["Açık Miktar"])
            beyond = bool(self.shifts) and order["Termin Tarihi"] > horizon_end
            if open_qty > 0:
                if beyond:
                    message = (
                        f'{order["Sipariş ID"]} siparişinde {open_qty} adet açık kaldı '
                        f"({horizon_days} günlük plan ufkuna sığmadı; termin {order['Termin Tarihi']}, "
                        f"ufuk sonu {horizon_end})."
                    )
                    action = (
                        "Plan ufkunu --max-days ile genişletin; kapasite, malzeme ve yarımamul "
                        "darboğazlarını da kontrol edin."
                    )
                else:
                    message = (
                        f'{order["Sipariş ID"]} siparişinde {open_qty} adet açık kaldı; '
                        "termin plan ufku içinde, kapasite/malzeme/yarımamul/MOQ kısıtları kontrol edilmeli."
                    )
                    action = "Kapasite, malzeme, yarımamul ve MOQ darboğazlarını kontrol edin."

                rows.append(
                    {
                        "Uyarı ID": f"UYR{warning_id:06d}",
                        "Tarih": order["Termin Tarihi"],
                        "Vardiya": "",
                        "Fırın Adı": "",
                        "Model/Ürün": f'{order["Model Kodu"]} / {order["Bitmiş Ürün Kodu"]}',
                        "Bileşen": "",
                        "İş Emri": "",
                        "Neden Kodu": "OPEN_DEMAND",
                        "Mesaj": message,
                        "Önerilen Aksiyon": action,
                    }
                )
                warning_id += 1

            late_qty = int(order.get("Geç Karşılanan", 0))
            if late_qty > 0 and open_qty == 0:
                rows.append(
                    {
                        "Uyarı ID": f"UYR{warning_id:06d}",
                        "Tarih": order["Termin Tarihi"],
                        "Vardiya": "",
                        "Fırın Adı": "",
                        "Model/Ürün": f'{order["Model Kodu"]} / {order["Bitmiş Ürün Kodu"]}',
                        "Bileşen": "",
                        "İş Emri": "",
                        "Neden Kodu": "LATE_CAPACITY",
                        "Mesaj": (
                            f'{order["Sipariş ID"]} siparişinde {late_qty} adet termininden sonra karşılandı; '
                            "sipariş kapandı ancak termin kaçtı."
                        ),
                        "Önerilen Aksiyon": (
                            "Kapasite, malzeme, yarımamul ve MOQ darboğazlarını kontrol edin; "
                            "aynı ürün/model için sonraki termin önceliklerini gözden geçirin."
                        ),
                    }
                )
                warning_id += 1
        for shift in self.shifts:
            deficit = solver.Value(self.sag_open_deficit[shift.index]) if shift.index in self.sag_open_deficit else 0
            if deficit > 0:
                rows.append(
                    {
                        "Uyarı ID": f"UYR{warning_id:06d}",
                        "Tarih": shift.date.isoformat(),
                        "Vardiya": shift.shift_no,
                        "Fırın Adı": "SAG",
                        "Model/Ürün": "",
                        "Bileşen": "",
                        "İş Emri": "",
                        "Neden Kodu": "SAG_OPENING_DEFICIT",
                        "Mesaj": f"SAG açılış hedefi {deficit} fırın kadar düşürüldü.",
                        "Önerilen Aksiyon": "Dummy-only açılış, malzeme veya talep yetersizliği kontrol edilmeli.",
                    }
                )
                warning_id += 1
        for day_index, var in self.sag_daily_deficit.items():
            deficit = solver.Value(var)
            if deficit <= 0:
                continue
            day = next(shift.date for shift in self.shifts if shift.day_index == day_index)
            rows.append(
                {
                    "Uyarı ID": f"UYR{warning_id:06d}",
                    "Tarih": day.isoformat(),
                    "Vardiya": "Günlük",
                    "Fırın Adı": "SAG",
                    "Model/Ürün": "",
                    "Bileşen": "",
                    "İş Emri": "",
                    "Neden Kodu": "SAG_OPENING_DEFICIT",
                    "Mesaj": f"Günlük SAG açılış hedefi {deficit} fırın-vardiya kadar düşürüldü.",
                    "Önerilen Aksiyon": "Uzak plan SAG açılış hedefi ve talep/malzeme durumu kontrol edilmeli.",
                }
            )
            warning_id += 1
            
        for shift in self.shifts:
            t = shift.index
            if t > 0 and solver.Value(self.pres_change[t]) == 1:
                pres_models = self._compatible_models_for_furnace(PRES_FURNACE)
                current_model = next(
                    (m for m in pres_models if solver.Value(self.active_pres[(m, t)]) == 1),
                    "",
                )
                previous_model = self._previous_pres_model(solver, t, pres_models)
                if previous_model and current_model:
                    prod_prev = sum(
                        solver.Value(var)
                        for (prod, furn, s), var in self.gross.items()
                        if furn == PRES_FURNACE and s == t and self.product_model[prod] == previous_model
                    )
                    prod_curr = sum(
                        solver.Value(var)
                        for (prod, furn, s), var in self.gross.items()
                        if furn == PRES_FURNACE and s == t and self.product_model[prod] == current_model
                    )
                    msg = f"LSF-12 model geçişi ({previous_model} -> {current_model}) gerçekleştirildi ve 350 brüt kapasite paylaştırıldı: {previous_model} = {prod_prev}, {current_model} = {prod_curr}"
                    rows.append(
                        {
                            "Uyarı ID": f"UYR{warning_id:06d}",
                            "Tarih": shift.date.isoformat(),
                            "Vardiya": shift.shift_no,
                            "Fırın Adı": PRES_FURNACE,
                            "Model/Ürün": f"{previous_model} -> {current_model}",
                            "Bileşen": "",
                            "İş Emri": "",
                            "Neden Kodu": "LSF12_MODEL_TRANSITION",
                            "Mesaj": msg,
                            "Önerilen Aksiyon": "Geçiş kapasite paylaşımını teyit edin.",
                        }
                    )
                    warning_id += 1
        return rows

    def _decision_rows(self, solver: cp_model.CpSolver, warning_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for idx, warning in enumerate(warning_rows, start=1):
            rows.append(
                {
                    "Karar ID": f"KAR{idx:06d}",
                    "Karar Tipi": "Gevşeme/Rapor",
                    "Kaynak Kısıt": warning.get("Neden Kodu", ""),
                    "Tarih": warning.get("Tarih", ""),
                    "Vardiya": warning.get("Vardiya", ""),
                    "Fırın": warning.get("Fırın Adı", ""),
                    "Model/Ürün": warning.get("Model/Ürün", ""),
                    "Sipariş": "",
                    "Neden Kodu": warning.get("Neden Kodu", ""),
                    "Karar Özeti": warning.get("Mesaj", ""),
                    "Etkilenen Miktar": "",
                    "Etki": "Plan çözülebilir tutuldu veya açık miktar raporlandı.",
                    "Önerilen Aksiyon": warning.get("Önerilen Aksiyon", ""),
                    "İlgili Tablo/Satır": "Vardiya_Uyarilari",
                    "Context": "",
                }
            )
        if not rows:
            rows.append(
                {
                    "Karar ID": "KAR000001",
                    "Karar Tipi": "Bilgi",
                    "Kaynak Kısıt": "MODEL",
                    "Tarih": "",
                    "Vardiya": "",
                    "Fırın": "",
                    "Model/Ürün": "",
                    "Sipariş": "",
                    "Neden Kodu": "OK",
                    "Karar Özeti": "Precheck geçti ve CP-SAT modeli uygulanabilir plan üretti.",
                    "Etkilenen Miktar": "",
                    "Etki": "Plan çıktı tablolarına yazıldı.",
                    "Önerilen Aksiyon": "Planlama özetini ve saha iş emirlerini kontrol edin.",
                    "İlgili Tablo/Satır": "Planlama_Ozet",
                    "Context": "",
                }
            )
        return rows

    def _bottleneck_rows(self, solver: cp_model.CpSolver, order_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for order in order_rows:
            if int(order["Açık Miktar"]) > 0:
                rows.append(
                    {
                        "Kategori": "Talep",
                        "Neden Kodu": "OPEN_DEMAND",
                        "Gerekli Miktar": order["Sipariş Miktarı"],
                        "Mevcut/Karşılanan": int(order["Zamanında Karşılanan"]) + int(order["Geç Karşılanan"]),
                        "Eksik Miktar": order["Açık Miktar"],
                        "Kaynak": "Sipariş",
                        "İlgili Sipariş": order["Sipariş ID"],
                        "Ürün/Model/Fırın/Bileşen": f'{order["Bitmiş Ürün Kodu"]}/{order["Model Kodu"]}',
                        "Önerilen Aksiyon": "Kapasite, stok, malzeme ve yarımamul akışını kontrol edin.",
                    }
                )
        for shift_index, var in self.sag_open_deficit.items():
            deficit = solver.Value(var)
            if deficit:
                shift = self.shifts[shift_index]
                rows.append(
                    {
                        "Kategori": "Kapasite",
                        "Neden Kodu": "SAG_OPENING_DEFICIT",
                        "Gerekli Miktar": self.data.near_sag_opening.get(shift_index, 0),
                        "Mevcut/Karşılanan": self.data.near_sag_opening.get(shift_index, 0) - deficit,
                        "Eksik Miktar": deficit,
                        "Kaynak": "near_sag_opening",
                        "İlgili Sipariş": "",
                        "Ürün/Model/Fırın/Bileşen": f"{shift.date.isoformat()} V{shift.shift_no}",
                        "Önerilen Aksiyon": "Açılış hedefi, talep ve malzeme uygunluğunu beraber kontrol edin.",
                    }
                )
        return rows

    def _reason_rows(self, solver: cp_model.CpSolver, order_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for order in order_rows:
            if order["Neden Kodu"] != "OK":
                rows.append(
                    {
                        "Kategori": "Sipariş",
                        "Tarih/Vardiya": order["Termin Tarihi"],
                        "Ürün/Model/Sipariş/Bileşen/Fırın": f'{order["Bitmiş Ürün Kodu"]}/{order["Model Kodu"]}/{order["Sipariş ID"]}',
                        "Neden Kodu": order["Neden Kodu"],
                        "Miktar": order["Açık Miktar"],
                        "Mesaj": "Sipariş termininde tamamen kapanmadı.",
                        "Context": "",
                    }
                )
        if not rows:
            rows.append(
                {
                    "Kategori": "Plan",
                    "Tarih/Vardiya": "",
                    "Ürün/Model/Sipariş/Bileşen/Fırın": "",
                    "Neden Kodu": "OK",
                    "Miktar": 0,
                    "Mesaj": "Açık/geciken sipariş nedeni yok.",
                    "Context": "",
                }
            )
        return rows

    def _carry_out_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        final_shift = self.shifts[-1].index
        campaign_net = self._campaign_net_by_furnace_model_value(solver)
        rows.extend(self._carry_out_model_state_rows(solver, campaign_net))
        for product in self.products:
            stock = solver.Value(self.fg_stock[(product, final_shift)])
            if stock:
                rows.append(
                    {
                        "Kayıt Tipi": "Bitmiş Ürün Stok",
                        "Kod": product,
                        "Fırın": "",
                        "Kaynak Model": "",
                        "Hedef Model": "",
                        "Kalan Lead Time/Tur": "",
                        "Miktar": stock,
                        "Bağlı Kalıp Sayısı": "",
                        "Carry-Out Kampanya Neti": "",
                        "Açıklama": "Son vardiya kullanılabilir bitmiş ürün stoku.",
                    }
                )
        for component in self._material_components():
            stock_scaled = self._material_final_stock_scaled_value(solver, component)
            if stock_scaled:
                rows.append(
                    {
                        "Kayıt Tipi": "Malzeme Stok",
                        "Kod": component,
                        "Fırın": "",
                        "Kaynak Model": "",
                        "Hedef Model": "",
                        "Kalan Lead Time/Tur": "",
                        "Miktar": round(scaled_to_float(stock_scaled), 3),
                        "Bağlı Kalıp Sayısı": "",
                        "Carry-Out Kampanya Neti": "",
                        "Açıklama": "Son vardiya sonrası sonraki plana devreden satın alınan malzeme stoku.",
                    }
                )
        for component in self._all_semi_components():
            stock_scaled = self._semi_final_stock_scaled_value(solver, component)
            if stock_scaled:
                rows.append(
                    {
                        "Kayıt Tipi": "Yarımamul Stok",
                        "Kod": component,
                        "Fırın": "",
                        "Kaynak Model": "",
                        "Hedef Model": "",
                        "Kalan Lead Time/Tur": "",
                        "Miktar": round(scaled_to_float(stock_scaled), 3),
                        "Bağlı Kalıp Sayısı": "",
                        "Carry-Out Kampanya Neti": "",
                        "Açıklama": "Son vardiya sonrası kullanılabilir ve sonraki plana devreden yarımamul stoku.",
                    }
                )
        for component in self._all_semi_components():
            for shift in self.shifts[-2:]:
                prep = solver.Value(self.semi_prep[(component, shift.index)])
                if prep:
                    remaining = max(0, shift.index + 2 - final_shift)
                    rows.append(
                        {
                            "Kayıt Tipi": "Yarımamul Hazırlık",
                            "Kod": component,
                            "Fırın": "",
                            "Kaynak Model": "",
                            "Hedef Model": "",
                            "Kalan Lead Time/Tur": remaining,
                            "Miktar": round(scaled_to_float(prep), 3),
                            "Bağlı Kalıp Sayısı": "",
                            "Carry-Out Kampanya Neti": "",
                            "Açıklama": "Plan ufku sonunda henüz olgunlaşmamış yarımamul hazırlığı.",
                        }
                    )
        for (component, remaining), qty_scaled in sorted(self.data.initial_semi_prep_carry_scaled.items()):
            next_remaining = remaining - len(self.shifts)
            if next_remaining > 0 and qty_scaled > 0:
                rows.append(
                    {
                        "Kayıt Tipi": "Yarımamul Hazırlık",
                        "Kod": component,
                        "Fırın": "",
                        "Kaynak Model": "",
                        "Hedef Model": "",
                        "Kalan Lead Time/Tur": next_remaining,
                        "Miktar": round(scaled_to_float(qty_scaled), 3),
                        "Bağlı Kalıp Sayısı": "",
                        "Carry-Out Kampanya Neti": "",
                        "Açıklama": "Önceki plandan devralınıp hala olgunlaşmamış yarımamul hazırlığı.",
                    }
                )
        for furnace in self.data.sag_furnaces:
            compatible_models = self._compatible_models_for_furnace(furnace)
            M0 = compatible_models + ["Yok"]
            transitions = [(a, b) for a in M0 for b in M0 if a != b]
            for source, target in transitions:
                val = solver.Value(self.setup_carry[(furnace, source, target, final_shift)])
                if val > 0:
                    rows.append(
                        {
                            "Kayıt Tipi": "Setup Carry",
                            "Kod": f"{source}->{target}",
                            "Fırın": furnace,
                            "Kaynak Model": source,
                            "Hedef Model": target,
                            "Kalan Lead Time/Tur": int(val),
                            "Miktar": int(val),
                            "Bağlı Kalıp Sayısı": "",
                            "Carry-Out Kampanya Neti": "",
                            "Açıklama": "Plan sonunda tamamlanmamış operasyon anahtarlı SAG setup carry.",
                        }
                    )
        return rows

    def _carry_out_model_state_rows(
        self,
        solver: cp_model.CpSolver,
        campaign_net: dict[tuple[str, str], int],
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []

        if PRES_FURNACE in self.data.furnaces:
            pres_model = self._final_pres_model(solver)
            if pres_model:
                pres_net = campaign_net.get((PRES_FURNACE, pres_model), 0)
                rows.append(self._carry_out_model_state_row(PRES_FURNACE, pres_model, 0, pres_net))

        for furnace in sorted(self.data.sag_furnaces):
            for model, bound_molds in self._carry_out_sag_model_states(solver, furnace):
                net = campaign_net.get((furnace, model), 0)
                if net > 0 or bound_molds > 0:
                    rows.append(self._carry_out_model_state_row(furnace, model, bound_molds, net))

        return rows

    def _carry_out_model_state_row(
        self,
        furnace: str,
        model: str,
        bound_molds: int,
        campaign_net: int,
    ) -> dict[str, Any]:
        return {
            "Kayıt Tipi": "Fırın Model Durumu",
            "Kod": model,
            "Fırın": furnace,
            "Kaynak Model": "",
            "Hedef Model": model,
            "Kalan Lead Time/Tur": "",
            "Miktar": campaign_net,
            "Bağlı Kalıp Sayısı": bound_molds,
            "Carry-Out Kampanya Neti": campaign_net,
            "Açıklama": "Sonraki rolling plan initial_furnace_model_state satırı olarak kullanılabilir.",
        }

    def _final_pres_model(self, solver: cp_model.CpSolver) -> str | None:
        if not self.shifts:
            return None
        final_shift = self.shifts[-1].index
        for model in self._compatible_models_for_furnace(PRES_FURNACE):
            active = self.active_pres.get((model, final_shift))
            if active is not None and solver.Value(active) == 1:
                return model
        return self._initial_pres_model()

    def _carry_out_sag_model_states(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
    ) -> list[tuple[str, int]]:
        if not self.shifts:
            return []

        final_shift = self.shifts[-1].index
        compatible_models = self._compatible_models_for_furnace(furnace)
        bound_states: list[tuple[str, int]] = []
        for model in compatible_models:
            bound = self.bound_sag.get((furnace, model, final_shift))
            if bound is None or solver.Value(bound) == 0:
                continue
            molds = self.model_molds_sag.get((furnace, model, final_shift))
            bound_states.append((model, solver.Value(molds) if molds is not None else 0))
        return bound_states

    def _campaign_net_by_furnace_model_value(
        self,
        solver: cp_model.CpSolver,
    ) -> dict[tuple[str, str], int]:
        campaign_net: defaultdict[tuple[str, str], int] = defaultdict(int)
        # Plan sonunda fırına bağlı kalan her model için kampanya anahtarı garanti edilir:
        # net üretim 0 olsa bile carry-out model durumu satırı ile kampanya tablosu
        # birebir tutarlı olur (her bağlı model bir açık kampanyaya karşılık gelir).
        if self.shifts:
            final_shift = self.shifts[-1].index
            for furnace in self.data.sag_furnaces:
                for model, _bound_molds in self._carry_out_sag_model_states(solver, furnace):
                    campaign_net[(furnace, model)] = solver.Value(
                        self.campaign_net_sag[(furnace, model, final_shift)]
                    )
            if PRES_FURNACE in self.data.furnaces:
                pres_model = self._final_pres_model(solver)
                if pres_model:
                    campaign_net[(PRES_FURNACE, pres_model)] = solver.Value(
                        self.campaign_net_pres[(pres_model, final_shift)]
                    )
        return dict(campaign_net)

    def _material_final_stock_scaled_value(
        self,
        solver: cp_model.CpSolver,
        component: str,
    ) -> int:
        final_shift = self.shifts[-1].index
        incoming = sum(
            qty
            for (arrival_component, arrival_shift), qty in self.data.material_arrivals_scaled.items()
            if arrival_component == component and arrival_shift <= final_shift
        )
        used = sum(
            self._component_used_scaled(solver, component, "Malzeme", shift.index)
            for shift in self.shifts
        )
        return max(0, self.data.initial_material_stock_scaled.get(component, 0) + incoming - used)

    def _semi_final_stock_scaled_value(
        self,
        solver: cp_model.CpSolver,
        component: str,
    ) -> int:
        flows = self._simulate_semi_flow(solver)
        if component in flows:
            last_flow = flows[component][-1]
            return int(round(last_flow["Vardiya Sonu Stok"] * SCALE))
        return 0

    def _sag_setup_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        setup_id = 1
        for furnace in self.data.sag_furnaces:
            compatible_models = self._compatible_models_for_furnace(furnace)
            M0 = compatible_models + ["Yok"]
            transitions = [(a, b) for a in M0 for b in M0 if a != b]
            
            for shift in self.shifts:
                is_open = (
                    solver.Value(self.open_sag[(furnace, shift.index)])
                    if (furnace, shift.index) in self.open_sag
                    else 0
                )
                shift_production_gross = sum(
                    solver.Value(var)
                    for (_product, f, t), var in self.gross.items()
                    if f == furnace and t == shift.index
                )
                
                for source, target in transitions:
                    prev_c = solver.Value(self._previous_setup_carry(furnace, source, target, shift.index))
                    carry_turns = solver.Value(self.carry_setup_turns[(furnace, source, target, shift.index)])
                    started = solver.Value(self.setup_start[(furnace, source, target, shift.index)])
                    new_turns = solver.Value(self.new_setup_turns[(furnace, source, target, shift.index)])
                    end_c = solver.Value(self.setup_carry[(furnace, source, target, shift.index)])
                    
                    if prev_c <= 0 and started <= 0 and carry_turns <= 0 and new_turns <= 0:
                        continue
                        
                    completed = carry_turns + new_turns
                    
                    rows.append(
                        {
                            "Setup ID": f"STP{setup_id:06d}",
                            "Tarih": shift.date.isoformat(),
                            "Vardiya": shift.shift_no,
                            "Vardiya Sıra No": shift.index + 1,
                            "Fırın Adı": furnace,
                            "Kaynak Model Kodu": source,
                            "Hedef Model Kodu": target,
                            "Vardiya Başı Setup Carry Turu": int(prev_c),
                            "Yeni Setup İhtiyaç Turu": int(started),
                            "Tamamlanan Setup Turu": int(completed),
                            "Vardiya Sonu Setup Carry Turu": int(end_c),
                            "Setup Tamamlandı mı?": "Evet" if end_c == 0 else "Hayır",
                            "Setup Only mi?": "Evet" if completed > 0 and shift_production_gross == 0 else "Hayır",
                            "Sökülen Kalıp Sayısı": int(completed) if source != "Yok" else 0,
                            "Bağlanan Kalıp Sayısı": int(completed) if target != "Yok" else 0,
                            "Setup Öncesi Ürün Kodları": "Yok",
                            "Setup Öncesi Üretim ID'leri": "Yok",
                            "Setup Öncesi Brüt Üretim": 0,
                            "Setup Öncesi Net Üretim": 0,
                            "Setup Sonrası Ürün Kodları": self._product_codes_for_model_shift(
                                solver, furnace, target if target != "Yok" else source, shift.index
                            )
                            or "Yok",
                            "Setup Sonrası Üretim ID'leri": self._production_ids_for_furnace_model_shift(
                                solver, furnace, target if target != "Yok" else source, shift.index
                            )
                            or "Yok",
                            "Setup Sonrası Brüt Üretim": shift_production_gross if completed else 0,
                            "Setup Sonrası Net Üretim": sum(
                                solver.Value(var)
                                for (_product, f, t), var in self.net.items()
                                if f == furnace and t == shift.index
                            )
                            if completed
                            else 0,
                            "Eski Model Üretim Turu": 0,
                            "Yeni Model Üretim Turu": max(0, self.data.sag_turns.get(furnace, 0) - completed)
                            if completed and shift_production_gross
                            else 0,
                            "Mecburi Maket Sayısı": self.data.mandatory_dummy.get(target, 0) if target != "Yok" else 0,
                            "Opsiyonel Maket Sayısı": self.data.sag_wagons.get(furnace, 0) if is_open and shift_production_gross == 0 else 0,
                            "Kullanılan Vagon": self.data.sag_wagons.get(furnace, 0) if is_open else 0,
                        }
                    )
                    setup_id += 1
        return rows

    def _lsf12_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        pres_models = self._compatible_models_for_furnace(PRES_FURNACE)
        for shift in self.shifts:
            current_model = next(
                (
                    model
                    for model in pres_models
                    if solver.Value(self.active_pres[(model, shift.index)]) == 1
                ),
                "",
            )
            previous_model = self._previous_pres_model(solver, shift.index, pres_models)
            direct_non_v710 = (
                previous_model
                and current_model
                and previous_model != current_model
                and previous_model != "V710"
                and current_model != "V710"
            )
            if current_model == "V710":
                v710_campaign_var = self.campaign_net_pres.get(("V710", shift.index))
                v710_campaign_net = solver.Value(v710_campaign_var) if v710_campaign_var is not None else 0
            elif previous_model == "V710":
                if shift.index == 0:
                    v710_campaign_net = self.data.initial_campaign_net.get((PRES_FURNACE, "V710"), 0)
                else:
                    v710_campaign_var = self.campaign_net_pres.get(("V710", shift.index - 1))
                    v710_campaign_net = (
                        solver.Value(v710_campaign_var) if v710_campaign_var is not None else 0
                    )
            else:
                v710_campaign_net = 0
            previous_model_campaign_net = 0
            if previous_model:
                if previous_model == current_model:
                    previous_campaign_var = self.campaign_net_pres.get((previous_model, shift.index))
                    previous_model_campaign_net = (
                        solver.Value(previous_campaign_var)
                        if previous_campaign_var is not None
                        else 0
                    )
                elif shift.index == 0:
                    previous_model_campaign_net = self.data.initial_campaign_net.get(
                        (PRES_FURNACE, previous_model),
                        0,
                    )
                else:
                    previous_campaign_var = self.campaign_net_pres.get(
                        (previous_model, shift.index - 1)
                    )
                    previous_model_campaign_net = (
                        solver.Value(previous_campaign_var)
                        if previous_campaign_var is not None
                        else 0
                    )
            v710_except_val = solver.Value(self.v710_exception[shift.index])
            proven_orders = []
            if v710_except_val == 1:
                for (order_id, t), var in self.v710_exception_order.items():
                    if t == shift.index and solver.Value(var) == 1:
                        proven_orders.append(order_id)
            v710_except_str = ", ".join(proven_orders) if proven_orders else ("Evet" if v710_except_val == 1 else "Hayır")

            rows.append(
                {
                    "Tarih": shift.date.isoformat(),
                    "Vardiya": shift.shift_no,
                    "Vardiya Sıra No": shift.index + 1,
                    "Önceki Model": previous_model,
                    "Mevcut Model": current_model,
                    "Pres Model Değişimi": "Evet" if solver.Value(self.pres_change[shift.index]) else "Hayır",
                    "Doğrudan V710 Dışı Geçiş": "Evet" if direct_non_v710 else "Hayır",
                    "Önceki Model Çıkış Öncesi Kampanya Neti": previous_model_campaign_net,
                    "Önceki Model Pres MOQ Sağlandı mı?": "Evet"
                    if previous_model_campaign_net >= PRES_MOQ or previous_model == current_model
                    else "Hayır",
                    "Kapasite": self._pres_capacity_at(solver, shift.index),
                    "Kullanılan Brüt": sum(
                        solver.Value(var)
                        for (product, furnace, t), var in self.gross.items()
                        if furnace == PRES_FURNACE and t == shift.index
                    ),
                    "Pres Slack": solver.Value(self.pres_slack[shift.index]),
                    "V710 Kampanya Neti": v710_campaign_net,
                    "V710 MOQ Sağlandı mı?": "Evet" if v710_campaign_net >= PRES_MOQ else "Hayır",
                    "Pres MOQ": PRES_MOQ,
                    "V710 İstisnası": v710_except_str,
                }
            )
        return rows

    def _product_codes_for_model_shift(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
        model: str,
        shift_index: int,
    ) -> str:
        product_codes, _production_ids = self._production_refs_for_furnace_model_shift(
            solver, furnace, model, shift_index
        )
        return product_codes

    def _production_ids_for_furnace_model_shift(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
        model: str,
        shift_index: int,
    ) -> str:
        _product_codes, production_ids = self._production_refs_for_furnace_model_shift(
            solver, furnace, model, shift_index
        )
        return production_ids

    def _production_refs_for_furnace_model_shift(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
        model: str,
        shift_index: int,
    ) -> tuple[str, str]:
        product_codes: list[str] = []
        production_ids: list[str] = []
        production_id = 1
        for shift in self.shifts:
            for current_furnace in self.furnaces:
                for product in self.products:
                    key = (product, current_furnace, shift.index)
                    if key not in self.gross:
                        continue
                    gross = solver.Value(self.gross[key])
                    net = solver.Value(self.net[key])
                    if gross <= 0 and net <= 0:
                        continue
                    if (
                        current_furnace == furnace
                        and shift.index == shift_index
                        and self.product_model[product] == model
                    ):
                        product_codes.append(product)
                        production_ids.append(f"URT{production_id:06d}")
                    production_id += 1
        return ", ".join(product_codes), ", ".join(production_ids)

    def _campaign_rows(
        self,
        solver: cp_model.CpSolver,
        production_rows: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        _ = production_rows
        campaign_net = self._campaign_net_by_furnace_model_value(solver)
        rows = []
        for idx, ((furnace, model), net) in enumerate(sorted(campaign_net.items()), start=1):
            initial = self.data.initial_campaign_net.get((furnace, model), 0)
            furnace_type = self.data.furnaces[furnace].furnace_type
            moq = PRES_MOQ if furnace_type == "Pres" else self.data.sag_moq.get(model, 0)
            rows.append(
                {
                    "Kampanya ID": f"KMP{idx:06d}",
                    "Fırın Adı": furnace,
                    "Model Kodu": model,
                    "Başlangıç Vardiyası": 1,
                    "Bitiş Vardiyası": "",
                    "Plan Sonunda Açık mı?": "Evet",
                    "Devreden Başlangıç Kampanya Neti": initial,
                    "Plan İçi Kampanya Neti": max(0, net - initial),
                    "MOQ": moq,
                    "MOQ Sağlandı mı?": "Evet" if net >= moq else "Hayır",
                    "Carry-Out Neti": net,
                }
            )
        return rows

    def _field_order_rows(
        self,
        production_rows: list[dict[str, Any]],
        furnace_rows: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for idx, prod in enumerate(production_rows, start=1):
            rows.append(
                {
                    "İş Emri No": f"ISE{idx:06d}",
                    "Tarih": prod["Tarih"],
                    "Vardiya": prod["Vardiya"],
                    "Fırın": prod["Fırın Adı"],
                    "Model Kodu": prod["Model Kodu"],
                    "Model Tanımı": prod["Model Tanımı"],
                    "Ürün Kodu": prod["Bitmiş Ürün Kodu"],
                    "Kalıp": prod["SAG Kalıp Sayısı"],
                    "Mecburi Maket": self.data.mandatory_dummy.get(prod["Model Kodu"], 0)
                    if prod["Fırın Tipi"] == "SAG"
                    else 0,
                    "Opsiyonel Maket": "",
                    "Toplam Maket": "",
                    "Tur": prod["SAG Üretim Tur Sayısı"],
                    "Hedef Brüt Üretim": prod["Brüt Üretim Adedi"],
                    "Hedef Net Üretim": prod["Net Üretim Adedi"],
                    "Malzeme/Yarımamul Durumu": "Model kısıtları içinde uygun",
                    "Kritik Uyarı": "",
                    "Aksiyon": (
                        f'{prod["Fırın Adı"]} fırınında {prod["Model Kodu"]} modeliyle '
                        f'{prod["Bitmiş Ürün Kodu"]} üret.'
                    ),
                    "İlgili Üretim ID": prod["Üretim ID"],
                }
            )
        return rows

    def _furnace_status_rows(self, furnace_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows = []
        for idx, row in enumerate(furnace_rows, start=1):
            if row["Fırın Durumu"] == "Kapalı" and row["Toplam Brüt Üretim"] == 0:
                continue
            rows.append(
                {
                    "Durum ID": f"FRN{idx:06d}",
                    "Tarih": row["Tarih"],
                    "Vardiya": row["Vardiya"],
                    "Fırın": row["Fırın Adı"],
                    "Vardiya Durumu": row["Fırın Durumu"],
                    "Ana İş": row["Ana İş Tipi"],
                    "Hedef Net Üretim": row["Toplam Net Üretim"],
                    "Kalıp": row["SAG Üretim Kalıbı Sayısı"],
                    "Mecburi Maket": row["SAG Mecburi Maket Sayısı"],
                    "Opsiyonel Maket": row["SAG Opsiyonel Maket Sayısı"],
                    "Toplam Maket": row["SAG Mecburi Maket Sayısı"] + row["SAG Opsiyonel Maket Sayısı"],
                    "Tur": row["SAG Üretim Turu"],
                    "Malzeme/Yarımamul Durumu": "Uygun",
                    "Kritik Uyarı Sayısı": 0,
                    "En Kritik Uyarı": "",
                    "İlk Aksiyon": "Üretim satırlarını takip et" if row["Toplam Brüt Üretim"] else "Fırını kapalı tut",
                    "İlgili Saha İş Emri": row["İlgili Üretim ID'leri"],
                }
            )
        return rows

    def _gantt_rows(
        self,
        production_rows: list[dict[str, Any]],
        furnace_rows: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        production_by_furnace_shift: defaultdict[tuple[str, int], list[dict[str, Any]]] = defaultdict(list)
        for row in production_rows:
            production_by_furnace_shift[(row["Fırın Adı"], row["Vardiya Sıra No"])].append(row)

        status_by_furnace_shift = {
            (row["Fırın Adı"], row["Vardiya Sıra No"]): row
            for row in furnace_rows
        }
        rows: list[dict[str, Any]] = []
        for furnace in self.furnaces:
            info = self.data.furnaces[furnace]
            row: dict[str, Any] = {"Fırın Adı": furnace, "Fırın Tipi": info.furnace_type}
            for shift in self.shifts:
                label = f"{shift.date.isoformat()} V{shift.shift_no}"
                status = status_by_furnace_shift.get((furnace, shift.index + 1), {})
                production = production_by_furnace_shift.get((furnace, shift.index + 1), [])
                if status.get("Fırın Durumu") == "Kapalı":
                    row[label] = "Kapalı"
                    continue
                if not production:
                    row[label] = f'{status.get("Ana İş Tipi", "Açık")} | Net 0'
                    continue
                models = "/".join(sorted({item["Model Kodu"] for item in production}))
                products = "/".join(sorted({item["Bitmiş Ürün Kodu"] for item in production}))
                net = sum(int(item["Net Üretim Adedi"]) for item in production)
                gross = sum(int(item["Brüt Üretim Adedi"]) for item in production)
                row[label] = f'{status.get("Ana İş Tipi", "Üretim")} | {models} | {products} | Brüt {gross} / Net {net}'
            rows.append(row)
        return rows

    def _change_instruction_rows(self, solver: cp_model.CpSolver) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        instruction_id = 1
        pres_models = self._compatible_models_for_furnace(PRES_FURNACE)
        for shift in self.shifts:
            if shift.index not in self.pres_change or not solver.Value(self.pres_change[shift.index]):
                continue
            previous = self._previous_pres_model(solver, shift.index, pres_models) or "Yok"
            current = next(
                (
                    model
                    for model in pres_models
                    if solver.Value(self.active_pres[(model, shift.index)]) == 1
                ),
                "Yok",
            )
            rows.append(
                {
                    "Talimat ID": f"KDT{instruction_id:06d}",
                    "Tarih": shift.date.isoformat(),
                    "Vardiya": shift.shift_no,
                    "Vardiya Sıra No": shift.index + 1,
                    "Fırın Adı": PRES_FURNACE,
                    "Kaynak Model": previous,
                    "Hedef Model": current,
                    "Setup Kaybı": PRES_CHANGE_CAPACITY_LOSS,
                    "Devreden/Tamamlanan Setup": "Pres model değişimi aynı vardiyada tamamlanır",
                    "Eski/Yeni Üretim Turları": "Pres kapasite paylaşımı Uretim sheet'inde brüt/net satırlarla görünür",
                    "Talimat": f"{PRES_FURNACE} üzerinde {previous} modelinden {current} modeline geç.",
                    "Uyarı": "Doğrudan V710 dışı geçiş ve V710 MOQ kapısı solver kısıtı olarak uygulanır.",
                }
            )
            instruction_id += 1

        for (furnace, source, target), carry in self.data.initial_setup_carry.items():
            completed = sum(
                solver.Value(self.carry_setup_turns[(furnace, source, target, shift.index)])
                for shift in self.shifts
                if (furnace, source, target, shift.index) in self.carry_setup_turns
            )
            remaining = carry - completed
            rows.append(
                {
                    "Talimat ID": f"KDT{instruction_id:06d}",
                    "Tarih": self.shifts[0].date.isoformat(),
                    "Vardiya": 1,
                    "Vardiya Sıra No": 1,
                    "Fırın Adı": furnace,
                    "Kaynak Model": source,
                    "Hedef Model": target,
                    "Setup Kaybı": carry,
                    "Devreden/Tamamlanan Setup": f"{carry} tur devreden, {completed} tur tamamlanan, {remaining} tur kalan",
                    "Eski/Yeni Üretim Turları": "",
                    "Talimat": f"{furnace} fırınında devreden {source}->{target} setup carry işini takip et.",
                    "Uyarı": "Setup carry, üretimden önce vardiya tur kapasitesini tüketir.",
                }
            )
            instruction_id += 1
        return rows

    def _plan_summary_table(
        self,
        solver: cp_model.CpSolver,
        status_name: str,
        objective: float,
        elapsed: float,
    ) -> pd.DataFrame:
        total_gross = sum(solver.Value(var) for var in self.gross.values())
        total_net = sum(solver.Value(var) for var in self.net.values())
        total_initial = sum(order.initial_allocated for order in self.data.orders)
        total_ship = total_initial + sum(solver.Value(var) for var in self.ship.values())
        total_demand = sum(order.quantity for order in self.data.orders)
        total_open = max(0, total_demand - total_ship)
        timely_oem = 0
        timely_oyc = 0
        for order in self.data.orders:
            produced_timely = 0
            if order.open_quantity > 0:
                produced_timely = sum(
                    solver.Value(self.ship[(order.order_id, shift.index)])
                    for shift in self.shifts
                    if (order.order_id, shift.index) in self.ship and shift.index <= order.due_shift
                )
            qty = order.initial_allocated + produced_timely
            if order.order_type == "OEM":
                timely_oem += qty
            else:
                timely_oyc += qty
        rows = [
            ("Çalıştırma Durumu", status_name),
            ("Stage 1 OEM Durumu", self.stage_summary.get("stage1_oem_status", "")),
            ("Stage 2 OYC Durumu", self.stage_summary.get("stage2_oyc_status", "")),
            ("Stage 3 Operasyon Durumu", self.stage_summary.get("stage3_operational_status", "")),
            (
                "Öncelik Optimum Kanıtı",
                "Evet"
                if self.stage_summary.get("stage1_oem_status") == "OPTIMAL"
                and self.stage_summary.get("stage2_oyc_status") == "OPTIMAL"
                else "Hayır",
            ),
            ("Plan Başlangıcı", self.shifts[0].date.isoformat()),
            ("Plan Bitişi", self.shifts[-1].date.isoformat()),
            ("Plan Vardiya Sayısı", len(self.shifts)),
            ("Solver Objective", round(objective, 2)),
            ("Solver Süresi (sn)", round(elapsed, 3)),
            ("Toplam Brüt Üretim", total_gross),
            ("Toplam Net Üretim", total_net),
            ("Toplam Talep", total_demand),
            ("Toplam Karşılanan", total_ship),
            ("Açık Miktar", total_open),
            ("Zamanında OEM Karşılama", timely_oem),
            ("Zamanında OYC Karşılama", timely_oyc),
            ("SAG Açılış Eksikliği", sum(solver.Value(var) for var in self.sag_open_deficit.values())),
            ("SAG Günlük Açılış Eksikliği", sum(solver.Value(var) for var in self.sag_daily_deficit.values())),
            ("LSF-12 Slack", sum(solver.Value(var) for var in self.pres_slack.values())),
            ("Azami Stok Aşımı", sum(solver.Value(var) for var in self.final_stock_excess.values())),
            ("30 Güne Sığmayan Sipariş Sayısı", self._unfit_order_count(solver)),
        ]
        return pd.DataFrame(rows, columns=["Metrik", "Değer"])

    def _unfit_order_count(self, solver: cp_model.CpSolver) -> int:
        # Plan ufkuna (max-days) sığmayan, yani plan sonunda hâlâ açık kalan sipariş sayısı.
        count = 0
        for order in self.data.orders:
            shipped = order.initial_allocated + sum(
                solver.Value(self.ship[(order.order_id, shift.index)])
                for shift in self.shifts
                if (order.order_id, shift.index) in self.ship
            )
            if shipped < order.quantity:
                count += 1
        return count

    def _component_consumption_terms(
        self,
        component: str,
        component_type: str,
        through_shift: int,
    ) -> list[cp_model.LinearExpr]:
        terms: list[cp_model.LinearExpr] = []
        for (product, comp, comp_type), qty_scaled in self.data.component_qty_scaled.items():
            if comp != component or comp_type != component_type:
                continue
            for (p, _f, t), net_var in self.net.items():
                if p == product and t <= through_shift:
                    terms.append(qty_scaled * net_var)
        return terms

    def _semi_prep_carry_available_scaled(self, component: str, shift_index: int) -> int:
        return sum(
            qty
            for (carry_component, remaining), qty in self.data.initial_semi_prep_carry_scaled.items()
            if carry_component == component and shift_index >= self._semi_prep_carry_maturity_index(remaining)
        )

    def _semi_prep_carry_maturing_scaled(self, component: str, shift_index: int) -> int:
        return sum(
            qty
            for (carry_component, remaining), qty in self.data.initial_semi_prep_carry_scaled.items()
            if carry_component == component and shift_index == self._semi_prep_carry_maturity_index(remaining)
        )

    @staticmethod
    def _semi_prep_carry_maturity_index(remaining: int) -> int:
        return max(0, remaining - 1)

    def _root_consumption_terms(self, root: str, through_shift: int) -> list[cp_model.LinearExpr]:
        terms: list[cp_model.LinearExpr] = []
        for product in self.products:
            q_M = self.data.component_qty_scaled.get((product, root + "M", "Yarımamul"), 0)
            q_M1 = self.data.component_qty_scaled.get((product, root + "M1", "Yarımamul"), 0)
            q_M2 = self.data.component_qty_scaled.get((product, root + "M2", "Yarımamul"), 0)
            bom_semi = q_M + max(q_M1, q_M2)
            if bom_semi <= 0:
                continue
            for (p, _f, t), net_var in self.net.items():
                if p == product and t <= through_shift:
                    terms.append(bom_semi * net_var)
        return terms

    def _component_used_scaled(
        self,
        solver: cp_model.CpSolver,
        component: str,
        component_type: str,
        shift_index: int,
    ) -> int:
        total = 0
        for (product, comp, comp_type), qty_scaled in self.data.component_qty_scaled.items():
            if comp != component or comp_type != component_type:
                continue
            for (p, _f, t), net_var in self.net.items():
                if p == product and t == shift_index:
                    total += qty_scaled * solver.Value(net_var)
        return total

    def _material_components(self) -> list[str]:
        return sorted(
            {
                component
                for (_product, component, component_type), _qty in self.data.component_qty_scaled.items()
                if component_type == "Malzeme"
            }
        )

    def _semi_components(self) -> list[str]:
        return sorted(
            {
                component
                for (_product, component, component_type), _qty in self.data.component_qty_scaled.items()
                if component_type == "Yarımamul"
            }
        )

    def _all_semi_components(self) -> list[str]:
        # BOM'da geçen yarımamuller + yalnız başlangıç stokunda bulunan yarımamuller.
        # Havuzlama (M + min(M1,M2)) için bir kök, BOM'da olmayan ama stokta bulunan bir
        # varyanta (örn. M1/M2 kullanan ürünler varken stokta duran M) sahip olabilir.
        # semi_prep değişkenleri bu birleşim üzerinden kurulmazsa _add_component_constraints
        # içinde semi_prep erişimi KeyError ile çöker.
        components = set(self._semi_components())
        components.update(self.data.initial_semi_stock_scaled.keys())
        components.update(component for component, _remaining in self.data.initial_semi_prep_carry_scaled)
        return sorted(components)

    def _compatible_models_for_furnace(self, furnace: str) -> list[str]:
        return sorted(
            {
                self.product_model[product]
                for f, product in self.data.compatibility
                if f == furnace and product in self.product_model
            }
        )

    def _sag_pres_parallel_allowed(self, product: str, shift_index: int) -> bool:
        if (PRES_FURNACE, product) not in self.data.compatibility:
            return False
        sag_furnaces = [
            furnace
            for furnace in self.data.sag_furnaces
            if (furnace, product) in self.data.compatibility
        ]
        if not sag_furnaces:
            return False

        product_orders = [
            order for order in self.orders if order.product == product and order.open_quantity > 0
        ]
        if not product_orders:
            return False

        if any(order.urgent for order in product_orders):
            return True

        # Paralel üretim kapısı ürün bazlı bir yeterlilik kararıdır: "SAG fırınlar tek
        # başına bu ürünün termin penceresi talebini karşılayabilir mi?" Kapasite, plan
        # başından (0) en yakın termine kadar olan SAG net üretim üst sınırıyla ölçülür.
        # Pencere başlangıcı olarak shift_index kullanılırsa termin sonrası vardiyalarda
        # pencere boşalıp kapı yanlışlıkla açılır ve gereksiz/aşırı stok paralel üretimi
        # mümkün olur; bu yüzden başlangıç sabit 0 alınır. Acil siparişler yukarıda
        # urgent bayrağıyla zaten paralel üretime açıktır.
        nearest_due_shift = min(order.due_shift for order in product_orders)
        due_window_demand = sum(
            order.open_quantity for order in product_orders if order.due_shift <= nearest_due_shift
        )
        initial_available = self.data.initial_fg_stock.get(product, 0)
        required_after_initial = max(0, due_window_demand - initial_available)
        if required_after_initial <= 0:
            return False

        sag_only_capacity = self._sag_only_net_capacity_upper_bound(
            product,
            0,
            nearest_due_shift,
            sag_furnaces,
        )
        return sag_only_capacity < required_after_initial

    def _sag_only_net_capacity_upper_bound(
        self,
        product: str,
        start_shift_index: int,
        end_shift_index: int,
        sag_furnaces: list[str],
    ) -> int:
        if end_shift_index < start_shift_index:
            return 0
        total = 0
        for shift in self.shifts:
            if shift.index < start_shift_index or shift.index > end_shift_index:
                continue
            best_shift_net = 0
            for furnace in sag_furnaces:
                yield_scaled = self.data.compatibility.get((furnace, product), 0)
                if yield_scaled <= 0:
                    continue
                gross_cap = max(
                    0,
                    self.data.sag_capacity.get(furnace, 0) - self.data.sag_wagons.get(furnace, 0),
                )
                best_shift_net = max(best_shift_net, floor(gross_cap * yield_scaled / SCALE))
            total += best_shift_net
        return total

    def _sag_previous_bound_expr(
        self,
        furnace: str,
        model: str,
        shift_index: int,
    ) -> cp_model.LinearExpr | int:
        if shift_index <= 0:
            return 1 if self.data.initial_furnace_models.get((furnace, model), 0) > 0 else 0
        return self.bound_sag.get((furnace, model, shift_index - 1), 0)

    def _sag_previous_molds_expr(
        self,
        furnace: str,
        model: str,
        shift_index: int,
    ) -> cp_model.LinearExpr | int:
        if shift_index <= 0:
            return self.data.initial_furnace_models.get((furnace, model), 0)
        return self.model_molds_sag.get((furnace, model, shift_index - 1), 0)

    def _sag_new_setup_start_at(self, furnace: str, shift_index: int) -> cp_model.LinearExpr | int:
        terms = [
            var
            for (setup_furnace, _model, setup_shift), var in self.sag_new_setup_start.items()
            if setup_furnace == furnace and setup_shift == shift_index
        ]
        return sum(terms) if terms else 0

    def _sag_new_setup_start_at_value(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
        shift_index: int,
    ) -> int:
        return sum(
            solver.Value(var)
            for (setup_furnace, _model, setup_shift), var in self.sag_new_setup_start.items()
            if setup_furnace == furnace and setup_shift == shift_index
        )

    def _initial_setup_carry_total_for_furnace(self, furnace: str) -> int:
        return sum(
            carry_turns
            for (carry_furnace, _source, _target), carry_turns in self.data.initial_setup_carry.items()
            if carry_furnace == furnace and carry_turns > 0
        )

    def _initial_setup_carry_turns_at(
        self,
        furnace: str,
        shift_index: int,
    ) -> cp_model.LinearExpr | int:
        terms = [
            var
            for (carry_furnace, _source, _target, carry_shift), var in self.initial_setup_carry_turns.items()
            if carry_furnace == furnace and carry_shift == shift_index
        ]
        return sum(terms) if terms else 0

    def _initial_setup_carry_turns_until(
        self,
        furnace: str,
        shift_index: int,
    ) -> cp_model.LinearExpr | int:
        terms = [
            var
            for (carry_furnace, _source, _target, carry_shift), var in self.initial_setup_carry_turns.items()
            if carry_furnace == furnace and carry_shift <= shift_index
        ]
        return sum(terms) if terms else 0

    def _initial_setup_carry_turns_at_value(
        self,
        solver: cp_model.CpSolver,
        furnace: str,
        shift_index: int,
    ) -> int:
        return sum(
            solver.Value(var)
            for (carry_furnace, _source, _target, carry_shift), var in self.initial_setup_carry_turns.items()
            if carry_furnace == furnace and carry_shift == shift_index
        )

    def _pres_model_net_until(self, model: str, max_shift_index: int) -> cp_model.LinearExpr | int:
        if max_shift_index < 0:
            return 0
        terms = [
            net_var
            for (product, furnace, shift_index), net_var in self.net.items()
            if furnace == PRES_FURNACE
            and shift_index <= max_shift_index
            and self.product_model[product] == model
        ]
        return sum(terms) if terms else 0

    def _campaign_net_upper_bound(self, furnace: str, model: str) -> int:
        initial = self.data.initial_campaign_net.get((furnace, model), 0)
        produced_ub = 0
        for (candidate_furnace, product), yield_scaled in self.data.compatibility.items():
            if candidate_furnace != furnace or self.product_model.get(product) != model:
                continue
            cap = self._furnace_gross_cap(furnace)
            produced_ub += len(self.shifts) * floor(cap * yield_scaled / SCALE)
        return max(1, initial + produced_ub)

    def _furnace_gross_cap(self, furnace: str) -> int:
        if furnace == PRES_FURNACE:
            return PRES_CAPACITY
        return self.data.sag_capacity.get(furnace, 0)

    def _product_stock_upper_bound(self, product: str) -> int:
        initial = self.data.initial_fg_stock.get(product, 0)
        produced_ub = 0
        for (furnace, p), yield_scaled in self.data.compatibility.items():
            if p != product:
                continue
            cap = self._furnace_gross_cap(furnace)
            produced_ub += len(self.shifts) * floor(cap * yield_scaled / SCALE)
        return max(1, initial + produced_ub)

    def _semi_prep_upper_bound(self, component: str) -> int:
        total = 0
        for (product, comp, component_type), qty_scaled in self.data.component_qty_scaled.items():
            if comp != component or component_type != "Yarımamul":
                continue
            total += self._product_stock_upper_bound(product) * qty_scaled
        return max(SCALE, total)

    def _initial_pres_model(self) -> str | None:
        for (furnace, model), _molds in self.data.initial_furnace_models.items():
            if furnace == PRES_FURNACE:
                return model
        return None

    def _previous_pres_model(
        self,
        solver: cp_model.CpSolver,
        shift_index: int,
        pres_models: list[str],
    ) -> str:
        if shift_index == 0:
            return self._initial_pres_model() or ""
        previous = shift_index - 1
        return next(
            (
                model
                for model in pres_models
                if solver.Value(self.active_pres[(model, previous)]) == 1
            ),
            "",
        )

    def _pres_capacity_at(self, solver: cp_model.CpSolver, shift_index: int) -> int:
        return PRES_CAPACITY - PRES_CHANGE_CAPACITY_LOSS * solver.Value(self.pres_change[shift_index])

    def _order_by_id(self, order_id: str) -> OrderInfo:
        return next(order for order in self.data.orders if order.order_id == order_id)


def _ship_label(row: dict[str, Any] | None) -> str:
    if not row:
        return "Yok"
    return f'{row["Tarih"]} V{row["Vardiya"]}'


def _infeasible_tables(status_name: str) -> dict[str, pd.DataFrame]:
    infeasible_rows = [
        {
            "Kategori": "Solver",
            "Tarih/Vardiya": "",
            "Ürün/Model/Sipariş/Bileşen/Fırın": "",
            "Neden Kodu": "CP_SAT_INFEASIBLE",
            "Miktar": "",
            "Mesaj": f"Solver status: {status_name}",
            "Context": "",
        }
    ]
    return {
        "Planlama_Ozet": pd.DataFrame(
            [
                ("Çalıştırma Durumu", status_name),
                ("Mesaj", "CP-SAT modeli uygulanabilir çözüm bulamadı."),
            ],
            columns=["Metrik", "Değer"],
        ),
        "Neden_Kodlari": pd.DataFrame(infeasible_rows),
        "Precheck_Hatalari": pd.DataFrame(columns=PRECHECK_COLUMNS),
        "Precheck_Infeasible": pd.DataFrame(infeasible_rows, columns=INFEASIBLE_COLUMNS),
    }
