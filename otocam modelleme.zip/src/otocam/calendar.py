from __future__ import annotations

from datetime import date, timedelta

from .schemas import Shift


def build_calendar(plan_start: date, days: int) -> tuple[Shift, ...]:
    shifts: list[Shift] = []
    idx = 0
    for day_idx in range(days):
        current = plan_start + timedelta(days=day_idx)
        for shift_no in (1, 2, 3):
            shifts.append(Shift(index=idx, day_index=day_idx, date=current, shift_no=shift_no, pres_available=1))
            idx += 1
    return tuple(shifts)


def due_shift_index(due_date: date, shifts: tuple[Shift, ...]) -> int:
    candidates = [shift.index for shift in shifts if shift.date <= due_date]
    if not candidates:
        return 0
    return max(candidates)

