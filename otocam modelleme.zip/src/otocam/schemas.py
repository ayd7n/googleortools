from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class TableSpec:
    sheet: str
    columns: tuple[str, ...]
    required: bool = True


@dataclass(frozen=True)
class PrecheckIssue:
    sheet: str
    row: int | None
    column: str | None
    rule: str
    message: str
    severity: str = "ERROR"
    value: Any = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "Seviye": self.severity,
            "Tablo": self.sheet,
            "Satır": self.row if self.row is not None else "",
            "Kolon": self.column or "",
            "Kural": self.rule,
            "Gerçek Değer": "" if self.value is None else self.value,
            "Mesaj": self.message,
        }


@dataclass(frozen=True)
class WorkbookData:
    path: Path
    sheets: dict[str, pd.DataFrame]
    missing_sheets: tuple[str, ...] = ()
    pending_semi_prep_scaled: dict[tuple[str, int], int] = field(default_factory=dict)


@dataclass(frozen=True)
class Shift:
    index: int
    day_index: int
    date: date
    shift_no: int
    pres_available: int = 1

    @property
    def label(self) -> str:
        return f"{self.date.isoformat()} / {self.shift_no}. Vardiya"


@dataclass(frozen=True)
class PlanOptions:
    plan_start: date
    max_days: int = 30
    solver_time_limit: float = 30.0
    workers: int = 8
    log_solver: bool = False


@dataclass(frozen=True)
class ProductInfo:
    product: str
    model: str
    model_name: str
    max_stock: int


@dataclass(frozen=True)
class FurnaceInfo:
    furnace: str
    furnace_type: str


@dataclass(frozen=True)
class OrderInfo:
    order_id: str
    product: str
    model: str
    due_date: date
    due_shift: int
    order_type: str
    quantity: int
    initial_allocated: int
    open_quantity: int
    urgent: bool = False


@dataclass(frozen=True)
class PreparedData:
    shifts: tuple[Shift, ...]
    products: dict[str, ProductInfo]
    furnaces: dict[str, FurnaceInfo]
    orders: tuple[OrderInfo, ...]
    bom: pd.DataFrame
    stock: pd.DataFrame
    compatibility: dict[tuple[str, str], int]
    component_qty_scaled: dict[tuple[str, str, str], int]
    initial_fg_stock: dict[str, int]
    initial_material_stock_scaled: dict[str, int]
    initial_semi_stock_scaled: dict[str, int]
    initial_semi_prep_carry_scaled: dict[tuple[str, int], int]
    material_arrivals_scaled: dict[tuple[str, int], int]
    sag_capacity: dict[str, int]
    sag_turns: dict[str, int]
    sag_wagons: dict[str, int]
    sag_model_limit: dict[str, int]
    sag_mold_capacity: dict[str, int]
    mandatory_dummy: dict[str, int]
    sag_moq: dict[str, int]
    near_sag_opening: dict[int, int]
    far_sag_opening: dict[int, int]
    initial_furnace_models: dict[tuple[str, str], int]
    initial_campaign_net: dict[tuple[str, str], int]
    initial_setup_carry: dict[tuple[str, str, str], int]
    initial_campaign_moq_exempt: dict[tuple[str, str], bool]

    @property
    def sag_furnaces(self) -> list[str]:
        return [f for f, info in self.furnaces.items() if info.furnace_type == "SAG"]

    @property
    def pres_furnaces(self) -> list[str]:
        return [f for f, info in self.furnaces.items() if info.furnace_type == "Pres"]

    @property
    def models(self) -> list[str]:
        return sorted({p.model for p in self.products.values()})


@dataclass
class PlanResult:
    status: str
    objective: float | None
    shifts: tuple[Shift, ...]
    tables: dict[str, pd.DataFrame] = field(default_factory=dict)
    warnings: list[dict[str, Any]] = field(default_factory=list)
    solver_summary: dict[str, Any] = field(default_factory=dict)

