from __future__ import annotations

from collections import Counter, defaultdict

from math import ceil

from .schemas import PlanOptions, PrecheckIssue, Shift, WorkbookData
from .specs import (
    PRES_CAPACITY,
    PRES_CHANGE_CAPACITY_LOSS,
    PRES_FURNACE,
    SCALE,
    SHEET_SPEC_BY_NAME,
)
from .utils import clean_code, parse_date, parse_float, parse_int

# Yarımamul hazırlığı başlatıldığı vardiyadan 2 vardiya sonra kullanılabilir olur
# (planner: prep_shift.index + 2 <= shift.index). Bu yüzden planın ilk 2 vardiyasında
# press yalnız BAŞLANGIÇ yarımamul stoğuyla beslenebilir.
PRES_SEMI_PREP_DELAY = 2


def validate_workbook(
    workbook: WorkbookData,
    options: PlanOptions,
    shifts: tuple[Shift, ...],
) -> list[PrecheckIssue]:
    issues: list[PrecheckIssue] = []

    for sheet in workbook.missing_sheets:
        issues.append(
            PrecheckIssue(
                sheet=sheet,
                row=None,
                column=None,
                rule="REQUIRED_SHEET",
                message=f"Zorunlu worksheet eksik: {sheet}",
            )
        )

    for sheet, df in workbook.sheets.items():
        spec = SHEET_SPEC_BY_NAME[sheet]
        missing_cols = [col for col in spec.columns if col not in df.columns]
        for col in missing_cols:
            issues.append(
                PrecheckIssue(
                    sheet=sheet,
                    row=None,
                    column=col,
                    rule="REQUIRED_COLUMN",
                    message=f"Zorunlu kolon eksik: {col}",
                )
            )

    if issues:
        return issues

    products_df = workbook.sheets["products"]
    furnaces_df = workbook.sheets["furnaces"]
    orders_df = workbook.sheets["orders"]
    bom_df = workbook.sheets["bom"]
    stock_df = workbook.sheets["stock"]
    yield_df = workbook.sheets["furnace_product_yield"]
    sag_furnace_capacity_df = workbook.sheets["sag_furnace_capacity"]
    sag_mold_capacity_df = workbook.sheets["sag_model_mold_capacity"]
    sag_moq_df = workbook.sheets["sag_moq"]
    mandatory_dummy_df = workbook.sheets["mandatory_dummy_models"]
    near_opening_df = workbook.sheets["near_sag_opening"]
    far_opening_df = workbook.sheets["far_sag_opening"]
    initial_state_df = workbook.sheets["initial_furnace_model_state"]
    setup_carry_df = workbook.sheets["initial_furnace_setup_carry"]
    material_arrivals_df = workbook.sheets["material_arrivals"]

    product_rows: dict[str, int] = {}
    product_models: dict[str, str] = {}
    model_products: defaultdict[str, set[str]] = defaultdict(set)

    seen_products: Counter[str] = Counter()
    for idx, row in products_df.iterrows():
        excel_row = idx + 2
        product = clean_code(row["Bitmiş Ürün Kodu"])
        model = clean_code(row["Model Kodu"])
        model_name = clean_code(row["Model Tanımı"])
        max_stock = parse_int(row["Azami Stok Miktarı"])
        if not product:
            issues.append(_issue("products", excel_row, "Bitmiş Ürün Kodu", "NON_EMPTY", "Ürün kodu boş olamaz"))
            continue
        seen_products[product] += 1
        product_rows[product] = excel_row
        product_models[product] = model
        model_products[model].add(product)
        if not model:
            issues.append(_issue("products", excel_row, "Model Kodu", "NON_EMPTY", "Model kodu boş olamaz", model))
        if not model_name:
            issues.append(
                _issue("products", excel_row, "Model Tanımı", "NON_EMPTY", "Model tanımı boş olamaz", model_name)
            )
        if max_stock is None or max_stock < 0:
            issues.append(
                _issue(
                    "products",
                    excel_row,
                    "Azami Stok Miktarı",
                    "NON_NEGATIVE_INTEGER",
                    "Azami stok miktarı negatif olmayan tamsayı olmalıdır",
                    row["Azami Stok Miktarı"],
                )
            )
    for product, count in seen_products.items():
        if count > 1:
            issues.append(
                _issue(
                    "products",
                    product_rows.get(product),
                    "Bitmiş Ürün Kodu",
                    "UNIQUE_PRODUCT",
                    f"Ürün master içinde tekrar eden ürün var: {product}",
                    product,
                )
            )

    furnace_types: dict[str, str] = {}
    seen_furnaces: Counter[str] = Counter()
    for idx, row in furnaces_df.iterrows():
        excel_row = idx + 2
        furnace = clean_code(row["Fırın Adı"])
        furnace_type = clean_code(row["Fırın Tipi"])
        if not furnace:
            issues.append(_issue("furnaces", excel_row, "Fırın Adı", "NON_EMPTY", "Fırın adı boş olamaz"))
            continue
        seen_furnaces[furnace] += 1
        furnace_types[furnace] = furnace_type
        if furnace_type not in {"SAG", "Pres"}:
            issues.append(
                _issue(
                    "furnaces",
                    excel_row,
                    "Fırın Tipi",
                    "ENUM",
                    "Fırın Tipi yalnız SAG veya Pres olabilir",
                    furnace_type,
                )
            )
    for furnace, count in seen_furnaces.items():
        if count > 1:
            issues.append(
                _issue(
                    "furnaces",
                    None,
                    "Fırın Adı",
                    "UNIQUE_FURNACE",
                    f"Tekrarlı fırın satırı var: {furnace}",
                    furnace,
                )
            )
    pres_furnaces = [f for f, t in furnace_types.items() if t == "Pres"]
    if pres_furnaces != [PRES_FURNACE]:
        issues.append(
            _issue(
                "furnaces",
                None,
                "Fırın Tipi",
                "SINGLE_LSF12_PRES",
                "Pres tarafı tam olarak tek satır olmalı ve fırın adı LSF-12 olmalıdır",
                ", ".join(pres_furnaces) or "Yok",
            )
        )

    for idx, row in orders_df.iterrows():
        excel_row = idx + 2
        product = clean_code(row["Bitmiş Ürün Kodu"])
        qty = parse_int(row["Sipariş Miktarı"])
        order_type = clean_code(row["Sipariş Türü"]).upper()
        due = parse_date(row["Termin Tarihi"])
        if product and product not in product_models:
            issues.append(
                _issue(
                    "orders",
                    excel_row,
                    "Bitmiş Ürün Kodu",
                    "KNOWN_PRODUCT",
                    f"Siparişteki ürün products tablosunda yok: {product}",
                    product,
                )
            )
        if qty is None or qty < 0:
            issues.append(
                _issue(
                    "orders",
                    excel_row,
                    "Sipariş Miktarı",
                    "NON_NEGATIVE_INTEGER",
                    "Sipariş miktarı negatif olmayan tamsayı olmalıdır",
                    row["Sipariş Miktarı"],
                )
            )
        if order_type not in {"OEM", "OYC"}:
            issues.append(
                _issue("orders", excel_row, "Sipariş Türü", "ENUM", "Sipariş Türü OEM veya OYC olmalıdır", order_type)
            )
        if due is None:
            issues.append(
                _issue("orders", excel_row, "Termin Tarihi", "DATE", "Termin tarihi geçerli tarih olmalıdır", row["Termin Tarihi"])
            )

    bom_products: defaultdict[str, set[str]] = defaultdict(set)
    bom_components: dict[str, str] = {}
    for idx, row in bom_df.iterrows():
        excel_row = idx + 2
        product = clean_code(row["Bitmiş Ürün Kodu"])
        component = clean_code(row["Bileşen Malzeme Kodu"])
        component_type = clean_code(row["Bileşen Malzeme Türü"])
        qty = parse_float(row["Bileşen Miktarı"])
        if product and product not in product_models:
            issues.append(
                _issue(
                    "bom",
                    excel_row,
                    "Bitmiş Ürün Kodu",
                    "KNOWN_PRODUCT",
                    f"BOM ürün kodu products tablosunda yok: {product}",
                    product,
                )
            )
        if not component:
            issues.append(_issue("bom", excel_row, "Bileşen Malzeme Kodu", "NON_EMPTY", "Bileşen kodu boş olamaz"))
        if component_type not in {"Malzeme", "Yarımamul"}:
            issues.append(
                _issue(
                    "bom",
                    excel_row,
                    "Bileşen Malzeme Türü",
                    "ENUM",
                    "Bileşen türü Malzeme veya Yarımamul olmalıdır",
                    component_type,
                )
            )
        if qty is None or qty <= 0:
            issues.append(
                _issue(
                    "bom",
                    excel_row,
                    "Bileşen Miktarı",
                    "POSITIVE_NUMBER",
                    "Bileşen miktarı pozitif sayı olmalıdır",
                    row["Bileşen Miktarı"],
                )
            )
        if product and component and component_type in {"Malzeme", "Yarımamul"}:
            bom_products[product].add(component_type)
            if component in bom_components and bom_components[component] != component_type:
                issues.append(
                    _issue(
                        "bom",
                        excel_row,
                        "Bileşen Malzeme Türü",
                        "CONSISTENT_COMPONENT_TYPE",
                        f"Aynı bileşen iki farklı türle kullanılmış: {component}",
                        component_type,
                    )
                )
            bom_components[component] = component_type

    referenced_products = set(product_models)
    referenced_products.update(clean_code(v) for v in orders_df["Bitmiş Ürün Kodu"])
    referenced_products.update(clean_code(v) for v in yield_df["Bitmiş Ürün Kodu"])
    for product in sorted(p for p in referenced_products if p):
        if product in product_models and "Yarımamul" not in bom_products.get(product, set()):
            issues.append(
                _issue(
                    "bom",
                    product_rows.get(product),
                    "Bileşen Malzeme Türü",
                    "BOM_REQUIRES_SEMI",
                    f"Her bitmiş ürün için en az bir Yarımamul BOM satırı zorunludur: {product}",
                    product,
                )
            )

    stock_records: set[tuple[str, str]] = set()
    for idx, row in stock_df.iterrows():
        excel_row = idx + 2
        code = clean_code(row["Kod"])
        stock_type = clean_code(row["Stok Türü"])
        qty = parse_float(row["Stok Miktarı"])
        if stock_type not in {"Bitmiş Ürün", "Malzeme", "Yarımamul"}:
            issues.append(
                _issue("stock", excel_row, "Stok Türü", "ENUM", "Stok Türü geçersiz", stock_type)
            )
        if qty is None or qty < 0:
            issues.append(
                _issue("stock", excel_row, "Stok Miktarı", "NON_NEGATIVE_NUMBER", "Stok miktarı negatif olamaz", row["Stok Miktarı"])
            )
        if stock_type == "Bitmiş Ürün" and code and code not in product_models:
            issues.append(
                _issue(
                    "stock",
                    excel_row,
                    "Kod",
                    "KNOWN_PRODUCT",
                    f"Bitmiş ürün stok kodu products tablosunda yok: {code}",
                    code,
                )
            )
        if code and stock_type:
            key = (code, stock_type)
            if key in stock_records:
                issues.append(
                    _issue(
                        "stock",
                        excel_row,
                        "Kod",
                        "UNIQUE_STOCK_CODE_TYPE",
                        f"Stok kodu ve türü tekrarlı: {code} / {stock_type}",
                        code,
                    )
                )
            stock_records.add(key)
    for component, component_type in bom_components.items():
        if (component, component_type) not in stock_records:
            issues.append(
                _issue(
                    "stock",
                    None,
                    "Kod",
                    "BOM_COMPONENT_STOCK_RECORD",
                    f"BOM bileşeni stok tablosunda aynı türle bulunmalıdır: {component} / {component_type}",
                    component,
                )
            )

    compatible_models_by_furnace: defaultdict[str, set[str]] = defaultdict(set)
    compatible_models_by_furnace_type: defaultdict[str, set[str]] = defaultdict(set)
    compatible_furnaces_by_product: defaultdict[str, set[str]] = defaultdict(set)
    yield_pairs: set[tuple[str, str]] = set()
    for idx, row in yield_df.iterrows():
        excel_row = idx + 2
        furnace = clean_code(row["Fırın Adı"])
        product = clean_code(row["Bitmiş Ürün Kodu"])
        yield_value = parse_float(row["Randıman"])
        if furnace and furnace not in furnace_types:
            issues.append(_issue("furnace_product_yield", excel_row, "Fırın Adı", "KNOWN_FURNACE", "Bilinmeyen fırın", furnace))
        if product and product not in product_models:
            issues.append(
                _issue("furnace_product_yield", excel_row, "Bitmiş Ürün Kodu", "KNOWN_PRODUCT", "Bilinmeyen ürün", product)
            )
        if yield_value is None or yield_value <= 0 or yield_value > 1:
            issues.append(
                _issue(
                    "furnace_product_yield",
                    excel_row,
                    "Randıman",
                    "YIELD_RANGE",
                    "Randıman 0 ile 1 arasında olmalıdır",
                    row["Randıman"],
                )
            )
        pair = (furnace, product)
        if pair in yield_pairs:
            issues.append(
                _issue(
                    "furnace_product_yield",
                    excel_row,
                    "Fırın Adı",
                    "UNIQUE_FURNACE_PRODUCT",
                    f"Fırın-ürün randıman satırı tekrarlı: {furnace} / {product}",
                    f"{furnace}/{product}",
                )
            )
        yield_pairs.add(pair)
        if furnace in furnace_types and product in product_models:
            furnace_type = furnace_types[furnace]
            model = product_models[product]
            compatible_models_by_furnace[furnace].add(model)
            compatible_models_by_furnace_type[furnace_type].add(model)
            compatible_furnaces_by_product[product].add(furnace)
            if model == "V710" and furnace != PRES_FURNACE:
                issues.append(
                    _issue(
                        "furnace_product_yield",
                        excel_row,
                        "Fırın Adı",
                        "V710_ONLY_LSF12",
                        "V710 modeli yalnız LSF-12 üzerinde üretilebilir",
                        furnace,
                    )
                )
    for product in sorted(product_models):
        if not compatible_furnaces_by_product.get(product):
            issues.append(
                _issue(
                    "furnace_product_yield",
                    product_rows.get(product),
                    "Bitmiş Ürün Kodu",
                    "PRODUCT_HAS_COMPATIBLE_FURNACE",
                    f"Her ürün en az bir fırın randıman satırına sahip olmalıdır: {product}",
                    product,
                )
            )

    sag_furnaces = {f for f, t in furnace_types.items() if t == "SAG"}
    sag_capacity_furnaces: set[str] = set()
    for idx, row in sag_furnace_capacity_df.iterrows():
        excel_row = idx + 2
        furnace = clean_code(row["Fırın Adı"])
        turns = parse_int(row["Vardiyadaki Tur Sayısı"])
        wagons = parse_int(row["Vagon Sayısı"])
        model_limit = parse_int(row["Vardiyadaki Çalışabileceği Farklı Model Sayısı"])
        if furnace in sag_capacity_furnaces:
            issues.append(
                _issue(
                    "sag_furnace_capacity",
                    excel_row,
                    "Fırın Adı",
                    "UNIQUE_SAG_FURNACE_CAPACITY",
                    f"SAG fırın kapasite satırı tekil olmalıdır: {furnace}",
                    furnace,
                )
            )
        sag_capacity_furnaces.add(furnace)
        if furnace not in sag_furnaces:
            issues.append(
                _issue(
                    "sag_furnace_capacity",
                    excel_row,
                    "Fırın Adı",
                    "SAG_FURNACE_ONLY",
                    "SAG fırın kapasite tablosunda yalnız SAG fırınlar bulunmalıdır",
                    furnace,
                )
            )
        for col, value in (
            ("Vardiyadaki Tur Sayısı", turns),
            ("Vagon Sayısı", wagons),
            ("Vardiyadaki Çalışabileceği Farklı Model Sayısı", model_limit),
        ):
            if value is None or value <= 0:
                issues.append(
                    _issue("sag_furnace_capacity", excel_row, col, "POSITIVE_INTEGER", f"{col} pozitif tamsayı olmalıdır", row[col])
                )
    for furnace in sorted(sag_furnaces - sag_capacity_furnaces):
        issues.append(
            _issue(
                "sag_furnace_capacity",
                None,
                "Fırın Adı",
                "SAG_CAPACITY_REQUIRED",
                f"SAG fırın kapasite satırı eksik: {furnace}",
                furnace,
            )
        )

    known_models = {model for model in product_models.values() if model}
    pres_only_models = compatible_models_by_furnace_type["Pres"] - compatible_models_by_furnace_type["SAG"]
    sag_mold_models: set[str] = set()
    seen_sag_mold_models: set[str] = set()
    for idx, row in sag_mold_capacity_df.iterrows():
        excel_row = idx + 2
        model = clean_code(row["Model Kodu"])
        mold_count = parse_int(row["Kalıp Sayısı"])
        if model in seen_sag_mold_models:
            issues.append(
                _issue(
                    "sag_model_mold_capacity",
                    excel_row,
                    "Model Kodu",
                    "UNIQUE_SAG_MOLD_MODEL",
                    f"SAG kalıp kapasitesi model bazında tekil olmalıdır: {model}",
                    model,
                )
            )
        seen_sag_mold_models.add(model)
        sag_mold_models.add(model)
        if model not in known_models:
            issues.append(
                _issue("sag_model_mold_capacity", excel_row, "Model Kodu", "KNOWN_MODEL", "Bilinmeyen model", model)
            )
        if model == "V710" or model in pres_only_models:
            issues.append(
                _issue(
                    "sag_model_mold_capacity",
                    excel_row,
                    "Model Kodu",
                    "SAG_MOLD_MODEL_SAG_ONLY",
                    "SAG kalıp kapasitesi tablosunda yalnız SAG modelleri bulunmalıdır",
                    model,
                )
            )
        if mold_count is None or mold_count < 0:
            issues.append(
                _issue(
                    "sag_model_mold_capacity",
                    excel_row,
                    "Kalıp Sayısı",
                    "NON_NEGATIVE_INTEGER",
                    "Kalıp sayısı negatif olmayan tamsayı olmalıdır",
                    row["Kalıp Sayısı"],
                )
            )

    sag_models = compatible_models_by_furnace_type["SAG"]
    for model in sorted(sag_models - sag_mold_models):
        issues.append(
            _issue(
                "sag_model_mold_capacity",
                None,
                "Model Kodu",
                "SAG_MODEL_MOLD_CAPACITY_REQUIRED",
                f"SAG üzerinde üretilebilir model için kalıp kapasitesi eksik: {model}",
                model,
            )
        )

    sag_moq_models: set[str] = set()
    seen_sag_moq_models: set[str] = set()
    for idx, row in sag_moq_df.iterrows():
        excel_row = idx + 2
        model = clean_code(row["Model Kodu"])
        moq = parse_int(row["MOQ Miktarı"])
        if model in seen_sag_moq_models:
            issues.append(
                _issue(
                    "sag_moq",
                    excel_row,
                    "Model Kodu",
                    "UNIQUE_SAG_MOQ_MODEL",
                    f"SAG MOQ satırı model bazında tekil olmalıdır: {model}",
                    model,
                )
            )
        seen_sag_moq_models.add(model)
        sag_moq_models.add(model)
        if model not in known_models:
            issues.append(_issue("sag_moq", excel_row, "Model Kodu", "KNOWN_MODEL", "Bilinmeyen model", model))
        if moq is None or moq < 0:
            issues.append(
                _issue("sag_moq", excel_row, "MOQ Miktarı", "NON_NEGATIVE_INTEGER", "MOQ negatif olmayan tamsayı olmalıdır", row["MOQ Miktarı"])
            )
    for model in sorted(sag_models - sag_moq_models):
        issues.append(
            _issue(
                "sag_moq",
                None,
                "Model Kodu",
                "SAG_MOQ_REQUIRED",
                f"SAG üzerinde üretilebilir model için sag_moq satırı eksik: {model}",
                model,
            )
        )
    for model in sorted(sag_moq_models & pres_only_models):
        issues.append(
            _issue(
                "sag_moq",
                None,
                "Model Kodu",
                "PRES_ONLY_MODEL_NOT_IN_SAG_MOQ",
                f"Sadece Pres/LSF-12 modelinin sag_moq satırı olmamalıdır: {model}",
                model,
            )
        )

    seen_mandatory_dummy_models: set[str] = set()
    for idx, row in mandatory_dummy_df.iterrows():
        excel_row = idx + 2
        model = clean_code(row["Model"])
        dummy = parse_int(row["Mecburi Maket Adeti"])
        if model in seen_mandatory_dummy_models:
            issues.append(
                _issue(
                    "mandatory_dummy_models",
                    excel_row,
                    "Model",
                    "UNIQUE_MANDATORY_DUMMY_MODEL",
                    f"Mecburi maket satırı model bazında tekil olmalıdır: {model}",
                    model,
                )
            )
        seen_mandatory_dummy_models.add(model)
        if model and model not in known_models:
            issues.append(_issue("mandatory_dummy_models", excel_row, "Model", "KNOWN_MODEL", "Bilinmeyen model", model))
        if model == "V710" or model in pres_only_models:
            issues.append(
                _issue(
                    "mandatory_dummy_models",
                    excel_row,
                    "Model",
                    "SAG_MODEL_ONLY",
                    "Mecburi maket tablosunda yalnız SAG modelleri bulunmalıdır",
                    model,
                )
            )
        if dummy is None or dummy < 0:
            issues.append(
                _issue(
                    "mandatory_dummy_models",
                    excel_row,
                    "Mecburi Maket Adeti",
                    "NON_NEGATIVE_INTEGER",
                    "Mecburi maket adedi negatif olmayan tamsayı olmalıdır",
                    row["Mecburi Maket Adeti"],
                )
            )

    material_codes = {component for component, component_type in bom_components.items() if component_type == "Malzeme"}
    for idx, row in material_arrivals_df.iterrows():
        excel_row = idx + 2
        material = clean_code(row["Malzeme"])
        arrival_date = parse_date(row["Beklenen Teslimat Tarihi"])
        qty = parse_float(row["Miktar"])
        if material and material not in material_codes:
            issues.append(
                _issue(
                    "material_arrivals",
                    excel_row,
                    "Malzeme",
                    "KNOWN_PURCHASED_MATERIAL",
                    "Yoldaki teslimat yalnız BOM Malzeme kodları için yazılabilir",
                    material,
                )
            )
        if arrival_date is None:
            issues.append(
                _issue(
                    "material_arrivals",
                    excel_row,
                    "Beklenen Teslimat Tarihi",
                    "DATE",
                    "Beklenen teslimat tarihi geçerli tarih olmalıdır",
                    row["Beklenen Teslimat Tarihi"],
                )
            )
        if qty is None or qty <= 0:
            issues.append(
                _issue("material_arrivals", excel_row, "Miktar", "POSITIVE_NUMBER", "Teslimat miktarı pozitif olmalıdır", row["Miktar"])
            )

    _validate_opening_tables(
        issues=issues,
        near_opening_df=near_opening_df,
        far_opening_df=far_opening_df,
        shifts=shifts,
        sag_furnace_count=len(sag_furnaces),
    )

    sag_model_limit_by_furnace = {
        clean_code(row["Fırın Adı"]): parse_int(row["Vardiyadaki Çalışabileceği Farklı Model Sayısı"]) or 0
        for _, row in sag_furnace_capacity_df.iterrows()
    }
    sag_wagon_by_furnace = {
        clean_code(row["Fırın Adı"]): parse_int(row["Vagon Sayısı"]) or 0
        for _, row in sag_furnace_capacity_df.iterrows()
    }
    sag_mold_cap_by_model = {
        clean_code(row["Model Kodu"]): parse_int(row["Kalıp Sayısı"]) or 0
        for _, row in sag_mold_capacity_df.iterrows()
    }
    mandatory_by_model = {
        clean_code(row["Model"]): parse_int(row["Mecburi Maket Adeti"]) or 0
        for _, row in mandatory_dummy_df.iterrows()
    }
    initial_model_on_sag: dict[str, str] = {}
    initial_sag_rows_by_furnace: defaultdict[str, list[tuple[str, int]]] = defaultdict(list)
    pres_initial_rows = 0
    for idx, row in initial_state_df.iterrows():
        excel_row = idx + 2
        furnace = clean_code(row["Fırın Adı"])
        model = clean_code(row["Model Kodu"])
        molds = parse_int(row["Bağlı Kalıp Sayısı"])
        campaign = parse_int(row["Başlangıç Kampanya Net Üretim Miktarı"])
        if furnace and furnace not in furnace_types:
            issues.append(_issue("initial_furnace_model_state", excel_row, "Fırın Adı", "KNOWN_FURNACE", "Bilinmeyen fırın", furnace))
        if model and model not in known_models:
            issues.append(_issue("initial_furnace_model_state", excel_row, "Model Kodu", "KNOWN_MODEL", "Bilinmeyen model", model))
        if furnace_types.get(furnace) == "SAG":
            if model == "V710":
                issues.append(
                    _issue(
                        "initial_furnace_model_state",
                        excel_row,
                        "Model Kodu",
                        "V710_ONLY_LSF12",
                        "V710 modeli başlangıçta SAG fırına bağlı olamaz",
                        model,
                    )
                )
            if model and model not in compatible_models_by_furnace.get(furnace, set()):
                issues.append(
                    _issue(
                        "initial_furnace_model_state",
                        excel_row,
                        "Model Kodu",
                        "INITIAL_MODEL_COMPATIBLE_WITH_FURNACE",
                        "Başlangıçta bağlı SAG modelinin aynı fırında üretilebilir randıman satırı olmalıdır",
                        f"{furnace}/{model}",
                    )
                )
            if model in initial_model_on_sag and initial_model_on_sag[model] != furnace:
                issues.append(
                    _issue(
                        "initial_furnace_model_state",
                        excel_row,
                        "Model Kodu",
                        "SAG_INITIAL_MODEL_SINGLE_FURNACE",
                        "Aynı model başlangıçta iki farklı SAG fırına bağlı olamaz",
                        model,
                    )
                )
            initial_model_on_sag[model] = furnace
            if molds is not None:
                initial_sag_rows_by_furnace[furnace].append((model, max(0, molds)))
        if furnace == PRES_FURNACE:
            pres_initial_rows += 1
        if molds is None or molds < 0:
            issues.append(
                _issue(
                    "initial_furnace_model_state",
                    excel_row,
                    "Bağlı Kalıp Sayısı",
                    "NON_NEGATIVE_INTEGER",
                    "Bağlı kalıp sayısı negatif olmayan tamsayı olmalıdır",
                    row["Bağlı Kalıp Sayısı"],
                )
            )
        if campaign is None or campaign < 0:
            issues.append(
                _issue(
                    "initial_furnace_model_state",
                    excel_row,
                    "Başlangıç Kampanya Net Üretim Miktarı",
                    "NON_NEGATIVE_INTEGER",
                    "Başlangıç kampanya neti negatif olmayan tamsayı olmalıdır",
                    row["Başlangıç Kampanya Net Üretim Miktarı"],
                )
            )
        if molds is not None and model in sag_mold_models:
            cap_rows = sag_mold_capacity_df[
                sag_mold_capacity_df["Model Kodu"].map(clean_code) == model
            ]
            if not cap_rows.empty:
                cap = parse_int(cap_rows.iloc[0]["Kalıp Sayısı"])
                if cap is not None and furnace_types.get(furnace) == "SAG" and molds > cap:
                    issues.append(
                        _issue(
                            "initial_furnace_model_state",
                            excel_row,
                            "Bağlı Kalıp Sayısı",
                            "MOLD_CAPACITY",
                            f"Başlangıç bağlı kalıp sayısı model kapasitesini aşıyor: {model}",
                            molds,
                        )
                    )
    if pres_initial_rows > 1:
        issues.append(
            _issue(
                "initial_furnace_model_state",
                None,
                "Fırın Adı",
                "SINGLE_PRES_INITIAL_MODEL",
                "LSF-12 başlangıçta en fazla bir modele bağlı olabilir",
                pres_initial_rows,
            )
        )

    for furnace, rows in initial_sag_rows_by_furnace.items():
        model_limit = sag_model_limit_by_furnace.get(furnace, 0)
        positive_rows = [(model, molds) for model, molds in rows if molds > 0]
        if model_limit and len(positive_rows) > model_limit:
            issues.append(
                _issue(
                    "initial_furnace_model_state",
                    None,
                    "Model Kodu",
                    "INITIAL_MODEL_COUNT_WITHIN_FURNACE_LIMIT",
                    f"Başlangıçta bağlı SAG model sayısı fırın model limitini aşıyor: {furnace}",
                    len(positive_rows),
                )
            )
        used_wagons = sum(molds + mandatory_by_model.get(model, 0) for model, molds in positive_rows)
        wagon_cap = sag_wagon_by_furnace.get(furnace, 0)
        if wagon_cap and used_wagons > wagon_cap:
            issues.append(
                _issue(
                    "initial_furnace_model_state",
                    None,
                    "Bağlı Kalıp Sayısı",
                    "INITIAL_MOLDS_AND_DUMMY_FIT_WAGON",
                    f"Başlangıç kalıpları ve mecburi maketler fırın vagon kapasitesine sığmıyor: {furnace}",
                    used_wagons,
                )
            )
        for model, molds in positive_rows:
            mold_cap = sag_mold_cap_by_model.get(model, 0)
            if mold_cap and molds > mold_cap:
                issues.append(
                    _issue(
                        "initial_furnace_model_state",
                        None,
                        "Bağlı Kalıp Sayısı",
                        "INITIAL_MODEL_MOLD_CAPACITY",
                        f"Başlangıç bağlı kalıp sayısı model kalıp kapasitesini aşıyor: {model}",
                        molds,
                    )
                )

    setup_keys: set[tuple[str, str, str]] = set()
    for idx, row in setup_carry_df.iterrows():
        excel_row = idx + 2
        furnace = clean_code(row["Fırın Adı"])
        source = clean_code(row["Kaynak Model Kodu"])
        target = clean_code(row["Hedef Model Kodu"])
        carry = parse_int(row["Kalan Setup Carry Turu"])
        if furnace not in sag_furnaces:
            issues.append(
                _issue(
                    "initial_furnace_setup_carry",
                    excel_row,
                    "Fırın Adı",
                    "SAG_ONLY",
                    "Setup carry yalnız SAG fırınları için yazılabilir",
                    furnace,
                )
            )
        for col, model in (("Kaynak Model Kodu", source), ("Hedef Model Kodu", target)):
            if model and model != "Yok" and model not in known_models:
                issues.append(
                    _issue("initial_furnace_setup_carry", excel_row, col, "KNOWN_MODEL_OR_YOK", "Model kodu bilinmeli veya Yok olmalıdır", model)
                )
            if (
                furnace in sag_furnaces
                and model
                and model != "Yok"
                and model in known_models
                and model not in compatible_models_by_furnace.get(furnace, set())
            ):
                issues.append(
                    _issue(
                        "initial_furnace_setup_carry",
                        excel_row,
                        col,
                        "SETUP_CARRY_MODEL_COMPATIBLE_WITH_FURNACE",
                        "Setup carry kaynak/hedef modeli ilgili SAG fırında üretilebilir olmalıdır",
                        f"{furnace}/{model}",
                    )
                )
        if source == "Yok" and target == "Yok":
            issues.append(
                _issue(
                    "initial_furnace_setup_carry",
                    excel_row,
                    "Kaynak Model Kodu",
                    "NOT_BOTH_YOK",
                    "Kaynak ve hedef model birlikte Yok olamaz",
                    "Yok/Yok",
                )
            )
        if source and target and source != "Yok" and source == target:
            issues.append(
                _issue(
                    "initial_furnace_setup_carry",
                    excel_row,
                    "Hedef Model Kodu",
                    "SOURCE_TARGET_DIFFER",
                    "Kaynak ve hedef model aynı olamaz",
                    source,
                )
            )
        if carry is None or carry < 0:
            issues.append(
                _issue(
                    "initial_furnace_setup_carry",
                    excel_row,
                    "Kalan Setup Carry Turu",
                    "NON_NEGATIVE_INTEGER",
                    "Kalan setup carry turu negatif olmayan tamsayı olmalıdır",
                    row["Kalan Setup Carry Turu"],
                )
            )
        key = (furnace, source, target)
        if key in setup_keys:
            issues.append(
                _issue(
                    "initial_furnace_setup_carry",
                    excel_row,
                    "Fırın Adı",
                    "UNIQUE_SETUP_CARRY_KEY",
                    f"Setup carry anahtarı tekrarlı: {furnace}/{source}/{target}",
                    f"{furnace}/{source}/{target}",
                )
            )
        setup_keys.add(key)

    _validate_pres_full_capacity_feed(
        issues=issues,
        yield_df=yield_df,
        bom_df=bom_df,
        stock_df=stock_df,
        initial_state_df=initial_state_df,
        product_models=product_models,
        shifts=shifts,
        pending_semi_prep_scaled=workbook.pending_semi_prep_scaled,
    )

    return issues


def _validate_pres_full_capacity_feed(
    issues: list[PrecheckIssue],
    yield_df,
    bom_df,
    stock_df,
    initial_state_df,
    product_models: dict[str, str],
    shifts: tuple[Shift, ...],
    pending_semi_prep_scaled: dict[tuple[str, int], int] | None = None,
) -> None:
    """Press (LSF-12) açık her vardiyada TAM kapasite (PRES_CAPACITY, model değişiminde
    PRES_CHANGE_CAPACITY_LOSS düşülür) üretir; kısmi/boşta üretime izin yoktur. Yarımamul
    hazırlığı 2 vardiya gecikmeyle olgunlaştığından, planın ilk 2 vardiyasında press yalnız
    BAŞLANGIÇ yarımamul stoğuyla beslenir. Başlangıç press modelinin yarımamulü bu pencerede
    tam kapasiteyi besleyemiyorsa plan çözümsüz kalır; bunu çözümden ÖNCE net hata olarak ver."""
    if not shifts:
        return

    # Press ürünleri ve randımanları
    pres_yield: dict[str, float] = {}
    for _, row in yield_df.iterrows():
        if clean_code(row["Fırın Adı"]) != PRES_FURNACE:
            continue
        product = clean_code(row["Bitmiş Ürün Kodu"])
        y = parse_float(row["Randıman"])
        if product and y and y > 0:
            pres_yield[product] = y
    if not pres_yield:
        return

    # Başlangıç press modeli (yoksa kontrol edilemez; press shift 0'da model seçer)
    initial_pres_model = ""
    for _, row in initial_state_df.iterrows():
        if clean_code(row["Fırın Adı"]) == PRES_FURNACE:
            initial_pres_model = clean_code(row["Model Kodu"])
            break
    if not initial_pres_model:
        return

    # Başlangıç press modelinin press ürünleri
    model_products = [
        product
        for product in pres_yield
        if product_models.get(product) == initial_pres_model
    ]
    if not model_products:
        return

    # Ürün -> yarımamul bileşen miktarları (BOM)
    semi_qty_by_product: dict[str, dict[str, float]] = {p: {} for p in model_products}
    for _, row in bom_df.iterrows():
        product = clean_code(row["Bitmiş Ürün Kodu"])
        if product not in semi_qty_by_product:
            continue
        if clean_code(row["Bileşen Malzeme Türü"]) != "Yarımamul":
            continue
        component = clean_code(row["Bileşen Malzeme Kodu"])
        qty = parse_float(row["Bileşen Miktarı"])
        if component and qty and qty > 0:
            semi_qty_by_product[product][component] = qty

    # Başlangıç yarımamul stoğu
    semi_stock: dict[str, float] = {}
    for _, row in stock_df.iterrows():
        if clean_code(row["Stok Türü"]) != "Yarımamul":
            continue
        code = clean_code(row["Kod"])
        qty = parse_float(row["Stok Miktarı"])
        if code:
            semi_stock[code] = (qty or 0.0)

    window = min(PRES_SEMI_PREP_DELAY, len(shifts))

    # Carry-out ile devreden, önceki plandan kalan ve pencere içinde olgunlaşan yarımamul
    # hazırlığı da bu pencerede kullanılabilir (planner ile aynı olgunlaşma kuralı:
    # remaining=r -> max(0, r-1). vardiyasında olgunlaşır). Ölçekli geldiği için SCALE'e bölünür.
    if pending_semi_prep_scaled:
        for (component, remaining), qty_scaled in pending_semi_prep_scaled.items():
            maturity_index = max(0, (remaining or 0) - 1)
            if maturity_index < window and component and qty_scaled > 0:
                semi_stock[component] = semi_stock.get(component, 0.0) + qty_scaled / SCALE

    # Press, tam kapasiteyi karşılamak için bu modelin EN AZ BİR ürününü üretebilmeli.
    # Ürün p, pencere boyunca beslenebiliyorsa (tüm yarımamul bileşenleri için başlangıç
    # stoğu yetiyorsa) model beslenebilir. Hiçbir ürün beslenemiyorsa hata ver.
    def product_feedable(product: str) -> tuple[bool, list[str]]:
        net_per_shift = PRES_CAPACITY * pres_yield[product]
        needed_net = ceil(net_per_shift * window)
        shortages: list[str] = []
        comps = semi_qty_by_product.get(product, {})
        if not comps:
            return False, []
        for component, qty in comps.items():
            need = ceil(needed_net * qty)
            have = semi_stock.get(component, 0.0)
            if have < need:
                shortages.append(f"{component}: gerek {need}, mevcut {int(have)}")
        return (len(shortages) == 0), shortages

    feedable = False
    all_shortages: list[str] = []
    for product in model_products:
        ok, shortages = product_feedable(product)
        if ok:
            feedable = True
            break
        all_shortages.extend(shortages)

    if not feedable:
        detail = "; ".join(dict.fromkeys(all_shortages))
        issues.append(
            _issue(
                "stock",
                None,
                "Stok Miktarı",
                "PRES_FULL_CAPACITY_SEMI_FEED",
                (
                    f"Press ({PRES_FURNACE}) açık her vardiyada tam kapasite "
                    f"({PRES_CAPACITY}; model değişiminde {PRES_CAPACITY - PRES_CHANGE_CAPACITY_LOSS}) "
                    f"üretir. Başlangıç press modeli '{initial_pres_model}' için ilk {window} vardiyada "
                    f"(yarımamul hazırlığı {PRES_SEMI_PREP_DELAY} vardiya sonra olgunlaşır) yeterli "
                    f"başlangıç yarımamul stoğu yok. Eksik: {detail}. "
                    f"Başlangıç yarımamul stoğunu artırın veya teslimat planını öne çekin."
                ),
                detail,
            )
        )


def _validate_opening_tables(
    issues: list[PrecheckIssue],
    near_opening_df,
    far_opening_df,
    shifts: tuple[Shift, ...],
    sag_furnace_count: int,
) -> None:
    near_dates: set = set()
    far_dates: set = set()

    for idx, row in near_opening_df.iterrows():
        excel_row = idx + 2
        current = parse_date(row["Tarih"])
        if current is None:
            issues.append(_issue("near_sag_opening", excel_row, "Tarih", "DATE", "Tarih geçerli olmalıdır", row["Tarih"]))
            continue
        if current in near_dates:
            issues.append(
                _issue(
                    "near_sag_opening",
                    excel_row,
                    "Tarih",
                    "UNIQUE_OPENING_DATE",
                    f"near_sag_opening içinde tarih tekil olmalıdır: {current.isoformat()}",
                    current.isoformat(),
                )
            )
        near_dates.add(current)
        for col in (
            "1. Vardiyada Açılacak SAG Fırın Sayısı",
            "2. Vardiyada Açılacak SAG Fırın Sayısı",
            "3. Vardiyada Açılacak SAG Fırın Sayısı",
        ):
            value = parse_int(row[col])
            if value is None or value < 0 or value > sag_furnace_count:
                issues.append(
                    _issue(
                        "near_sag_opening",
                        excel_row,
                        col,
                        "SAG_OPENING_RANGE",
                        f"Açılacak SAG fırın sayısı 0..{sag_furnace_count} aralığında tamsayı olmalıdır",
                        row[col],
                    )
                )

    for idx, row in far_opening_df.iterrows():
        excel_row = idx + 2
        current = parse_date(row["Tarih"])
        value = parse_int(row["3 Vardiya Toplamında Açılacak SAG Fırın Sayısı"])
        if current is None:
            issues.append(_issue("far_sag_opening", excel_row, "Tarih", "DATE", "Tarih geçerli olmalıdır", row["Tarih"]))
            continue
        if current in far_dates:
            issues.append(
                _issue(
                    "far_sag_opening",
                    excel_row,
                    "Tarih",
                    "UNIQUE_OPENING_DATE",
                    f"far_sag_opening içinde tarih tekil olmalıdır: {current.isoformat()}",
                    current.isoformat(),
                )
            )
        far_dates.add(current)
        max_daily = sag_furnace_count * 3
        if value is None or value < 0 or value > max_daily:
            issues.append(
                _issue(
                    "far_sag_opening",
                    excel_row,
                    "3 Vardiya Toplamında Açılacak SAG Fırın Sayısı",
                    "SAG_DAILY_OPENING_RANGE",
                    f"Günlük toplam SAG açılışı 0..{max_daily} aralığında tamsayı olmalıdır",
                    row["3 Vardiya Toplamında Açılacak SAG Fırın Sayısı"],
                )
            )

    overlap = near_dates & far_dates
    for current in sorted(overlap):
        issues.append(
            _issue(
                "near_sag_opening",
                None,
                "Tarih",
                "OPENING_DATE_EXCLUSIVE",
                f"Aynı tarih near_sag_opening ve far_sag_opening içinde birlikte bulunamaz: {current.isoformat()}",
                current.isoformat(),
            )
        )

    calendar_dates = {shift.date for shift in shifts}
    for current in sorted(calendar_dates):
        if current not in near_dates and current not in far_dates:
            issues.append(
                _issue(
                    "near_sag_opening",
                    None,
                    "Tarih",
                    "OPENING_DATE_COVERAGE",
                    f"Plan ufkundaki her tarih near veya far SAG açılış tablosunda bulunmalıdır: {current.isoformat()}",
                    current.isoformat(),
                )
            )


def _issue(
    sheet: str,
    row: int | None,
    column: str | None,
    rule: str,
    message: str,
    value=None,
) -> PrecheckIssue:
    return PrecheckIssue(sheet=sheet, row=row, column=column, rule=rule, message=message, value=value)
