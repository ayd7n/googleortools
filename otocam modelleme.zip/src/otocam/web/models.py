from __future__ import annotations

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Order(db.Model):
    __tablename__ = "orders"
    id = db.Column(db.Integer, primary_key=True)
    product_code = db.Column(db.String(100), nullable=False)
    due_date = db.Column(db.String(20), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    order_type = db.Column(db.String(50), nullable=False)


class BOM(db.Model):
    __tablename__ = "bom"
    id = db.Column(db.Integer, primary_key=True)
    product_code = db.Column(db.String(100), nullable=False)
    component_code = db.Column(db.String(100), nullable=False)
    component_type = db.Column(db.String(50), nullable=False)
    quantity = db.Column(db.Float, nullable=False)


class Stock(db.Model):
    __tablename__ = "stock"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(100), nullable=False)
    stock_type = db.Column(db.String(50), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)


class Furnace(db.Model):
    __tablename__ = "furnaces"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    furnace_type = db.Column(db.String(50), nullable=False)


class Product(db.Model):
    __tablename__ = "products"
    id = db.Column(db.Integer, primary_key=True)
    product_code = db.Column(db.String(100), nullable=False)
    model_code = db.Column(db.String(100), nullable=False)
    model_name = db.Column(db.String(200), nullable=False)
    max_stock = db.Column(db.Integer, nullable=False)


class SAGModelMoldCapacity(db.Model):
    __tablename__ = "sag_model_mold_capacity"
    id = db.Column(db.Integer, primary_key=True)
    model_code = db.Column(db.String(100), nullable=False)
    mold_count = db.Column(db.Integer, nullable=False)


class SAGFurnaceCapacity(db.Model):
    __tablename__ = "sag_furnace_capacity"
    id = db.Column(db.Integer, primary_key=True)
    furnace_name = db.Column(db.String(50), nullable=False)
    turn_count = db.Column(db.Integer, nullable=False)
    wagon_count = db.Column(db.Integer, nullable=False)
    model_limit = db.Column(db.Integer, nullable=False)


class FurnaceProductYield(db.Model):
    __tablename__ = "furnace_product_yield"
    id = db.Column(db.Integer, primary_key=True)
    furnace_name = db.Column(db.String(50), nullable=False)
    product_code = db.Column(db.String(100), nullable=False)
    yield_rate = db.Column(db.Float, nullable=False)


class SAGMOQ(db.Model):
    __tablename__ = "sag_moq"
    id = db.Column(db.Integer, primary_key=True)
    model_code = db.Column(db.String(100), nullable=False)
    moq = db.Column(db.Integer, nullable=False)


class MaterialArrival(db.Model):
    __tablename__ = "material_arrivals"
    id = db.Column(db.Integer, primary_key=True)
    material_code = db.Column(db.String(100), nullable=False)
    expected_date = db.Column(db.String(20), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)


class MandatoryDummyModel(db.Model):
    __tablename__ = "mandatory_dummy_models"
    id = db.Column(db.Integer, primary_key=True)
    model_code = db.Column(db.String(100), nullable=False)
    dummy_count = db.Column(db.Integer, nullable=False)


class NearSAGOpening(db.Model):
    __tablename__ = "near_sag_opening"
    id = db.Column(db.Integer, primary_key=True)
    date_str = db.Column(db.String(20), nullable=False)
    shift_1_count = db.Column(db.Integer, nullable=False)
    shift_2_count = db.Column(db.Integer, nullable=False)
    shift_3_count = db.Column(db.Integer, nullable=False)


class FarSAGOpening(db.Model):
    __tablename__ = "far_sag_opening"
    id = db.Column(db.Integer, primary_key=True)
    date_str = db.Column(db.String(20), nullable=False)
    total_count = db.Column(db.Integer, nullable=False)


class InitialFurnaceModelState(db.Model):
    __tablename__ = "initial_furnace_model_state"
    id = db.Column(db.Integer, primary_key=True)
    furnace_name = db.Column(db.String(50), nullable=False)
    model_code = db.Column(db.String(100), nullable=False)
    mold_count = db.Column(db.Integer, nullable=False)
    initial_net_production = db.Column(db.Integer, nullable=False)


class InitialFurnaceSetupCarry(db.Model):
    __tablename__ = "initial_furnace_setup_carry"
    id = db.Column(db.Integer, primary_key=True)
    furnace_name = db.Column(db.String(50), nullable=False)
    source_model = db.Column(db.String(100), nullable=False)
    target_model = db.Column(db.String(100), nullable=False)
    remaining_turns = db.Column(db.Integer, nullable=False)
