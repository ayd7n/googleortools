from __future__ import annotations

from datetime import date, datetime
import pandas as pd
from openpyxl import load_workbook
from .models import (
    db, Order, BOM, Stock, Furnace, Product, SAGModelMoldCapacity,
    SAGFurnaceCapacity, FurnaceProductYield, SAGMOQ, MaterialArrival,
    MandatoryDummyModel, NearSAGOpening, FarSAGOpening, InitialFurnaceModelState,
    InitialFurnaceSetupCarry
)

# Map sheet names to SQLAlchemy models and columns
# Format: { sheet_name: { "model": Model, "columns": { excel_col: db_attr } } }
TABLE_MAPPING = {
    "orders": {
        "model": Order,
        "columns": {
            "Bitmiş Ürün Kodu": "product_code",
            "Termin Tarihi": "due_date",
            "Sipariş Miktarı": "quantity",
            "Sipariş Türü": "order_type",
        },
    },
    "bom": {
        "model": BOM,
        "columns": {
            "Bitmiş Ürün Kodu": "product_code",
            "Bileşen Malzeme Kodu": "component_code",
            "Bileşen Malzeme Türü": "component_type",
            "Bileşen Miktarı": "quantity",
        },
    },
    "stock": {
        "model": Stock,
        "columns": {
            "Kod": "code",
            "Stok Türü": "stock_type",
            "Stok Miktarı": "quantity",
        },
    },
    "furnaces": {
        "model": Furnace,
        "columns": {
            "Fırın Adı": "name",
            "Fırın Tipi": "furnace_type",
        },
    },
    "products": {
        "model": Product,
        "columns": {
            "Bitmiş Ürün Kodu": "product_code",
            "Model Kodu": "model_code",
            "Model Tanımı": "model_name",
            "Azami Stok Miktarı": "max_stock",
        },
    },
    "sag_model_mold_capacity": {
        "model": SAGModelMoldCapacity,
        "columns": {
            "Model Kodu": "model_code",
            "Kalıp Sayısı": "mold_count",
        },
    },
    "sag_furnace_capacity": {
        "model": SAGFurnaceCapacity,
        "columns": {
            "Fırın Adı": "furnace_name",
            "Vardiyadaki Tur Sayısı": "turn_count",
            "Vagon Sayısı": "wagon_count",
            "Vardiyadaki Çalışabileceği Farklı Model Sayısı": "model_limit",
        },
    },
    "furnace_product_yield": {
        "model": FurnaceProductYield,
        "columns": {
            "Fırın Adı": "furnace_name",
            "Bitmiş Ürün Kodu": "product_code",
            "Randıman": "yield_rate",
        },
    },
    "sag_moq": {
        "model": SAGMOQ,
        "columns": {
            "Model Kodu": "model_code",
            "MOQ Miktarı": "moq",
        },
    },
    "material_arrivals": {
        "model": MaterialArrival,
        "columns": {
            "Malzeme": "material_code",
            "Beklenen Teslimat Tarihi": "expected_date",
            "Miktar": "quantity",
        },
    },
    "mandatory_dummy_models": {
        "model": MandatoryDummyModel,
        "columns": {
            "Model": "model_code",
            "Mecburi Maket Adeti": "dummy_count",
        },
    },
    "near_sag_opening": {
        "model": NearSAGOpening,
        "columns": {
            "Tarih": "date_str",
            "1. Vardiyada Açılacak SAG Fırın Sayısı": "shift_1_count",
            "2. Vardiyada Açılacak SAG Fırın Sayısı": "shift_2_count",
            "3. Vardiyada Açılacak SAG Fırın Sayısı": "shift_3_count",
        },
    },
    "far_sag_opening": {
        "model": FarSAGOpening,
        "columns": {
            "Tarih": "date_str",
            "3 Vardiya Toplamında Açılacak SAG Fırın Sayısı": "total_count",
        },
    },
    "initial_furnace_model_state": {
        "model": InitialFurnaceModelState,
        "columns": {
            "Fırın Adı": "furnace_name",
            "Model Kodu": "model_code",
            "Bağlı Kalıp Sayısı": "mold_count",
            "Başlangıç Kampanya Net Üretim Miktarı": "initial_net_production",
        },
    },
    "initial_furnace_setup_carry": {
        "model": InitialFurnaceSetupCarry,
        "columns": {
            "Fırın Adı": "furnace_name",
            "Kaynak Model Kodu": "source_model",
            "Hedef Model Kodu": "target_model",
            "Kalan Setup Carry Turu": "remaining_turns",
        },
    },
}


def clean_date_value(val) -> str:
    """Format date values to YYYY-MM-DD format strings."""
    if pd.isna(val) or val is None:
        return ""
    if isinstance(val, (datetime, date)):
        return val.strftime("%Y-%m-%d")
    if isinstance(val, str):
        # Clean potential timestamp suffixes
        clean_str = val.split(" ")[0].strip()
        try:
            # Check if it parses as ISO date
            return date.fromisoformat(clean_str).isoformat()
        except ValueError:
            return clean_str
    return str(val)


def import_excel_to_db(excel_path: str) -> None:
    """Clear database input tables and load data from Excel sheets."""
    xls = pd.ExcelFile(excel_path)
    for sheet_name, config in TABLE_MAPPING.items():
        if sheet_name not in xls.sheet_names:
            continue

        # Clear existing table data
        model_cls = config["model"]
        db.session.query(model_cls).delete()

        # Read sheet and map columns
        df = pd.read_excel(xls, sheet_name=sheet_name)
        
        # Columns in Excel that match our mapping keys
        expected_cols = list(config["columns"].keys())
        
        # Filter dataframe to only have the columns we expect
        # and fill missing ones with appropriate defaults
        for col in expected_cols:
            if col not in df.columns:
                df[col] = None

        df = df[expected_cols]

        for _, row in df.iterrows():
            params = {}
            for excel_col, db_attr in config["columns"].items():
                val = row[excel_col]
                # Clean dates for specific date columns
                if excel_col in ["Termin Tarihi", "Beklenen Teslimat Tarihi", "Tarih"]:
                    val = clean_date_value(val)
                elif pd.isna(val):
                    val = None
                params[db_attr] = val

            item = model_cls(**params)
            db.session.add(item)

    db.session.commit()


def export_db_to_excel(excel_path: str) -> None:
    """Read data from database input tables and save to Excel file with original headers."""
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        for sheet_name, config in TABLE_MAPPING.items():
            model_cls = config["model"]
            query = db.session.query(model_cls).all()
            
            # Reconstruct list of dicts
            rows = []
            for item in query:
                row_dict = {}
                for excel_col, db_attr in config["columns"].items():
                    val = getattr(item, db_attr)
                    row_dict[excel_col] = val
                rows.append(row_dict)

            # Export to sheet
            df = pd.DataFrame(rows, columns=list(config["columns"].keys()))
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Format workbook auto width
            ws = writer.sheets[sheet_name]
            ws.freeze_panes = "A2"
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                col_letter = col[0].column_letter
                ws.column_dimensions[col_letter].width = max(10, min(max_len + 2, 42))
