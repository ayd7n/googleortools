from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from .calendar import build_calendar
from .carry import apply_carry_out
from .io import read_input_workbook
from .output import write_plan_result, write_precheck_errors
from .planner import solve_plan
from .preprocess import estimate_planning_days, prepare_data
from .sample_data import SYNTHETIC_SCENARIOS, create_sample_workbook
from .schemas import PlanOptions
from .selftest import run_self_test
from .validation import validate_workbook


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    plan_start = args.plan_start or date.today()

    if args.self_test:
        try:
            scenarios = _parse_scenarios(args.self_test_scenarios)
        except argparse.ArgumentTypeError as exc:
            parser.error(str(exc))
        result = run_self_test(
            args.self_test,
            plan_start=plan_start,
            scenarios=scenarios,
            max_days=args.max_days,
            time_limit=args.time_limit,
            workers=args.workers,
        )
        status = "BAŞARILI" if result.passed else "HATALI"
        print(f"Self-test durumu: {status}. Rapor: {result.report_path}")
        return 0 if result.passed else 1

    if args.make_sample:
        path = create_sample_workbook(args.make_sample, plan_start, scenario=args.scenario)
        print(f"Örnek girdi workbook oluşturuldu: {path}")
        return 0

    if not args.input:
        parser.error("--input zorunludur. Örnek dosya için --make-sample kullanın.")
    output = Path(args.output or "cikti_plan.xlsx").resolve()

    workbook = read_input_workbook(args.input)
    if args.carry_out:
        workbook = apply_carry_out(workbook, args.carry_out)
    days = estimate_planning_days(workbook, plan_start, args.max_days)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(
        plan_start=plan_start,
        max_days=args.max_days,
        solver_time_limit=args.time_limit,
        workers=args.workers,
        log_solver=args.log_solver,
    )

    issues = validate_workbook(workbook, options, shifts)
    if issues:
        written = write_precheck_errors(output, issues)
        print(f"Precheck hataları bulundu ({len(issues)}). Çıktı: {written}")
        return 2

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)
    written = write_plan_result(output, result)
    print(f"Plan durumu: {result.status}. Çıktı: {written}")
    return 0 if result.status in {"OPTIMAL", "FEASIBLE"} else 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_plan.py",
        description="Otocam Excel girdisini okuyup CP-SAT uretim planı Excel çıktısı üretir.",
    )
    parser.add_argument("--input", help="Girdi Excel workbook yolu")
    parser.add_argument("--output", help="Çıktı Excel workbook yolu")
    parser.add_argument("--carry-out", help="Önceki plan çıktısındaki Carry_Out sheet'ini başlangıç durumuna uygula")
    parser.add_argument("--make-sample", help="Örnek girdi workbook üretilecek yol")
    parser.add_argument(
        "--scenario",
        choices=SYNTHETIC_SCENARIOS,
        default="base",
        help="--make-sample için sentetik veri senaryosu",
    )
    parser.add_argument("--self-test", help="Sentetik kabul testleri için çıktı klasörü")
    parser.add_argument(
        "--self-test-scenarios",
        default=",".join(SYNTHETIC_SCENARIOS),
        help="Virgülle ayrılmış self-test senaryoları",
    )
    parser.add_argument("--plan-start", type=_parse_date, help="Plan başlangıç tarihi (YYYY-MM-DD). Varsayılan: bugün")
    parser.add_argument("--max-days", type=int, default=30, help="Plan ufku üst sınırı (gün)")
    parser.add_argument("--time-limit", type=float, default=30.0, help="Solver süre limiti (saniye)")
    parser.add_argument("--workers", type=int, default=8, help="Solver paralel worker sayısı")
    parser.add_argument("--log-solver", action="store_true", help="OR-Tools solver loglarını yazdır")
    return parser


def _parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Tarih YYYY-MM-DD formatında olmalıdır") from exc


def _parse_scenarios(value: str) -> tuple[str, ...]:
    scenarios = tuple(part.strip() for part in value.split(",") if part.strip())
    unknown = [scenario for scenario in scenarios if scenario not in SYNTHETIC_SCENARIOS]
    if unknown:
        allowed = ", ".join(SYNTHETIC_SCENARIOS)
        raise argparse.ArgumentTypeError(
            f"Bilinmeyen self-test senaryosu: {', '.join(unknown)}. Geçerli değerler: {allowed}"
        )
    return scenarios
