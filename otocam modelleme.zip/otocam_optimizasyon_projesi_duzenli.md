# Otocam Optimizasyon Projesi

Bu doküman, otomotiv cam üretimi yapan bir firmadaki üretim hattı çizelgeleme problemini daha düzenli bir yapıda tarif eder. Amaç, problemi matematiksel modelleme yaklaşımıyla ele almak ve Python diliyle çözülebilecek hale getirmektir.

---

## 1. Belge Bilgileri

| Alan | Değer |
|---|---|
| Doküman Başlığı | Otocam Optimizasyon Projesi |
| Kapsam | Otomotiv cam üretim hattı çizelgeleme problemi |
| Yaklaşım | Matematiksel modelleme, Python script ve Google OR-Tools CP-SAT ile çözüm |
| Kodlama Dili | Python |
| Optimizasyon Çözücüsü | Google OR-Tools CP-SAT |

### 1.1. Netleşen Kararlar

- Bu doküman, uygulanacak sistemin matematiksel model ve veri sözleşmesini netleştirir.
- Uygulama kapsamı Python tabanlı komut satırı uygulamasıdır: uygulama girdi Excel workbook'unu okur, precheck ve optimizasyonu çalıştırır, çıktı Excel workbook'u üretir. Kullanıcı için giriş noktası `run_plan.py` olabilir; ancak kod tek ve çok uzun bir Python dosyasına yığılmamalıdır. Excel okuma, veri doğrulama, veri hazırlama, CP-SAT model kurma, çözüm okuma ve çıktı Excel yazma işleri ayrı Python modüllerine bölünmelidir. Web arayüzü, veritabanı ve canlı kullanıcı ekranları bu aşamada kapsam dışıdır.
- Kodlama dili `Python`, optimizasyon çözücüsü `Google OR-Tools CP-SAT` olarak sabitlenmiştir.
- Girdi verisi tek bir Excel workbook içinden alınır; her gerekli tablo ayrı worksheet olarak bulunur.
- İlk plan koşusunda `initial_furnace_model_state` Excel girdisinden manuel başlangıç fırın-model durumu, `initial_furnace_setup_carry` girdisinden ise operasyon kimlikli başlangıç setup carry kayıtları okunur. Sonraki rolling plan koşularında önceki planın `carry_out` paketi bu başlangıç durumunun ana kaynağıdır.
- Performans ve doğrulama hedefi, siparişlerin tamamı karşılanana kadar otomatik genişleyen kanonik plan ufkudur.
- SAG açma eşitlikleri, LSF-12 tam kapasite kullanımı ve kampanya MOQ eşiği sert kısıttır; model sökümünde açık/gecikmiş sipariş kapatma davranışı ise operasyonel slakla cezalandırılan tercih olarak modellenir. Malzeme darboğazları ve kapasite-dummy çelişkilerinden kaynaklanan çözümsüzlükleri (infeasibility/deadlock) önlemek için sisteme otomatik gevşeme (slack/muafiyet) mekanizmaları eklenmiştir.
- SAG/LSF-12 paralel üretim kapısı muhafazakar çalışır: SAG-only yeterlilik açıkça kanıtlanamıyorsa paralel üretim izni açılır.
- Kampanya/MOQ takibi basit sayaç mantığıyla kurulur. SAG fırınlarda her fırın-model kampanyasında net üretim birikir; model sökülmek istendiğinde sayaç `sag_moq` tablosundaki ilgili SAG MOQ değerinin altındaysa söküm yasaktır. LSF-12 Pres fırında `sag_moq` tablosu kullanılmaz; kampanya MOQ değeri modelden bağımsız sabit `3000` net üründür.
- SAG model sökümü açık sipariş durumuna duyarlıdır: aynı modelde söküm vardiyasına kadar vadesi gelmiş/gecikmiş talep veya ileri vadeli açık sipariş kalıyorsa modelde kalmak operasyonel amaçta güçlü biçimde tercih edilir. Model daha yüksek öncelikli talep, kapasite veya malzeme/yarımamul çakışması nedeniyle yine de sökülürse açık/gecikmiş sipariş slakı oluşur ve raporlanır; bu tercih fizibiliteyi kilitleyen sert talep-kapama kısıtı değildir.

---

## 2. Örnek Üretim Planı: LSF 4

Bu bölümdeki LSF 4 üretim planı, gerçek model girdisi değil; üretim planı yapısını ve vardiya-fırın-kalıp-adet ilişkisini göstermek için kullanılan örnek plandır.

### 2.1. Örnek Form Bilgileri

| Alan | Değer |
|---|---|
| Örnek Üretim Planı | LSF 4 |
| Örnek Plan Tarihi | 10.11.2025 |
| Form Kodu | TOFGNL 29 |
| Düzenleme Tarihi | 30/09/2005 |
| Rev No | 0 |
| Rev Tarihi | 0 |
| Toplam | 26 Kalıp |

### 2.2. Örnek Üretim Planı Tablosu

| VRD. | Mamul No | Mamul Tanımı | Sipariş No | Kalıp | Adet |
|---|---|---|---|---:|---:|
| 10/2 | 20REW04760200M | Chevy Express 2019 Ön Cam | 100000583752 | 6 | 48 |
| 10/2 | 200TS04120104M | V363 IAC 3 Alçak Tip LDWLi Isıtmalı Ön Cam // Sağ Üretimi | 100000577113 | 5 | 40 |
| 10/2 | 20REW06500100M | Jeep Avenger LHD Öncam Deicer Baskılı | 100000584735 | 6 | 48 |
| 10/2 | 200TS04150103M | V363 ICA 3 Yüksek Tip LDWLi Isıtmalı Ön Cam | 100000582477 | 7 | 56 |
| 10/3 | 20REW04760200M | Chevy Express 2019 Ön Cam | 100000583752 | 6 | 48 |
| 10/3 | 200TS04120104M | V363 IAC 3 Alçak Tip LDWLi Isıtmalı Ön Cam // Sağ Üretimi | 100000577113 | 5 | 40 |
| 10/3 | 20REW06500100M | Jeep Avenger LHD Öncam Deicer Baskılı | 100000584735 | 6 | 48 |
| 10/3 | 20ARW00890100M | V363 Yü. Tip Isıtmasız Ayna Plktsız Ön Cam // AR Üretimi İçindir | 100000585784 | 7 | 56 |
| 11/1 | 20REW04760200M | Chevy Express 2019 Ön Cam | 100000584737 | 6 | 48 |
| 11/1 | 200TS04120104M | V363 IAC 3 Alçak Tip LDWLi Isıtmalı Ön Cam // Sağ Üretimi | 100000577113 | 5 | 40 |
| 11/1 | 20REW06500100M | Jeep Avenger LHD Öncam Deicer Baskılı | 100000584735 | 6 | 48 |
| 11/1 | 20ARW00890100M | V363 Yü. Tip Isıtmasız Ayna Plktsız Ön Cam // AR Üretimi İçindir | 100000585784 | 7 | 56 |

---

## 3. Proje Tanımı

Bu projede, otomotiv cam üreticisi bir firmanın üretim hattı çizelgeleme problemi ele alınacaktır.

Problem matematiksel modelleme ile kurulacak ve `Python` tabanlı komut satırı uygulaması içinde `Google OR-Tools CP-SAT` çözücüsüyle çözülecektir. `run_plan.py` yalnız çalıştırma giriş noktası olmalı; uzun iş mantığı ayrı modüllerde tutulmalıdır.

---

## 4. Amaç Fonksiyonu ve Öncelikler

1. Amaç fonksiyonu lexicographic sırayla uygulanır: önce OEM siparişleri, sonra OYC siparişleri, en son operasyonel maliyetler optimize edilir.
2. OEM siparişlerinin tamamının karşılanması hedeflenir.
3. OYC siparişlerinin de tamamının karşılanması hedeflenir.
4. Bir fırın bir vardiyada açıldıysa, vardiya boyunca çalışmalıdır.
5. Fırın vardiyanın yalnızca 2 saatinde çalışıp diğer saatlerinde kapalı kalmamalıdır.
6. Gerekirse stok için fazla üretim yapılabilir; fazla stok ve azami stok aşımı operasyonel maliyet olarak değerlendirilir.
7. Bir vardiyada veya günde belirli sayıda fırının çalışacağı belirtilmişse, bu sayı üst sınır veya alt sınır değil sert eşitliktir.

---

## 5. Gerekli Tablolar

Girdi sözleşmesi tek Excel workbook kullanır. Workbook içinde her kullanıcı girdisi ayrı worksheet olmalıdır; worksheet adları teknik iç tablo adlarıyla aynı yazılır: `orders`, `bom`, `stock`, `furnaces`, `products`, `sag_model_mold_capacity`, `sag_furnace_capacity`, `furnace_product_yield`, `sag_moq`, `material_arrivals`, `mandatory_dummy_models`, `near_sag_opening`, `far_sag_opening`, `initial_furnace_model_state` ve `initial_furnace_setup_carry`.

Excel workbook dışındaki veri giriş biçimleri kapsam dışıdır. Veri hazırlığı, aşağıdaki tablo sözleşmesine uymayan eksik worksheet, eksik kolon, hatalı veri tipi veya kritik ana veri eksiklerini precheck hatası olarak raporlar.

`plan_calendar` kullanıcıdan Excel worksheet olarak alınmaz. Sistem plan çalıştırıldığı günü plan başlangıcı kabul eder ve günde 3 vardiya olacak şekilde iç plan takvimini siparişlerin tamamı karşılanana kadar otomatik genişletir. Vardiyalara kronolojik `Sıra No` sistem tarafından atanır. Eğer tüm siparişler veri, malzeme, yarımamul, kapasite, MOQ, V710/LSF-12 veya SAG açılış kısıtları nedeniyle karşılanamıyorsa sistem açık kalan miktarı neden koduyla raporlar.

| No | Tablo Adı | Kolonlar | Açıklama / Kural |
|---:|---|---|---|
| 1 | Sipariş tablosu | Bitmiş Ürün Kodu, Termin Tarihi, Sipariş Miktarı, Sipariş Türü | Sipariş Miktarı planlama anındaki müşteri talebini/açık bakiyeyi ifade eder; bu miktarın tamamı otomatik olarak üretim ihtiyacı sayılmaz. Sistem önce başlangıç bitmiş ürün stokunu aynı ürün içinde OEM siparişlere termin sırasıyla, sonra OYC siparişlere termin sırasıyla ayırır. Başlangıç stoku ile kapanan miktar üretime alınmaz; yalnız stokla kapanmayan kalan açık ihtiyaç üretim planına konu olur. Aynı bitmiş ürün, sipariş türü ve termin tarihindeki satırlar veri hazırlığında toplanır. Sipariş Miktarı `0` olan satırlar optimizasyona alınmaz; negatif miktar veri hatasıdır. Sipariş Türü alanına `OEM` veya `OYC` değerlerinden biri yazılır. Müşteri duruş riski kullanıcı tarafından kolon olarak girilmez; sistem termin, stokla kapanmayan açık miktar, eldeki stok, aynı ürün için OEM öncelik kapısı, aynı sipariş türü içindeki önceki terminli talepler, malzeme uygunluğu ve üretilebilir kapasiteye göre `urgent(o)` risk bayrağını veri hazırlığında türetir. |
| 2 | Ürün ağacı tablosu | Bitmiş Ürün Kodu, Bileşen Malzeme Kodu, Bileşen Malzeme Türü, Bileşen Miktarı | Bileşen Malzeme Türü alanına `Yarımamul` veya `Malzeme` değerlerinden biri yazılabilir. Bir bitmiş ürüne ait malzeme girdisi hiç olmayabilir ya da birden fazla olabilir; fakat her bitmiş ürünün ürün ağacında en az bir `Yarımamul` girdisi bulunması zorunludur. Aynı malzeme birden fazla bitmiş üründe kullanılabilir; aynı şekilde aynı yarımamul de birden fazla bitmiş ürünün ürün ağacında yer alabilir. BOM tüketimi randıman sonrası net üretim miktarına göre hesaplanır. |
| 3 | Stok tablosu | Kod, Stok Türü, Stok Miktarı | Stok Türü alanına `Bitmiş Ürün`, `Yarımamul` veya `Malzeme` değerlerinden biri yazılmalıdır. Ürün ağacında geçen her malzeme ve yarımamul için stok kaydı zorunludur; stok yoksa miktar `0` yazılmalıdır. Bitmiş ürün için stok satırı yoksa başlangıç bitmiş ürün stoku `0` kabul edilir. |
| 4 | Fırınlar tablosu | Fırın Adı, Fırın Tipi | Fırın Tipi alanına `SAG` veya `Pres` değerlerinden biri yazılır. Mevcut sistem sözleşmesinde Pres tarafı tek fırındır ve bu fırın `LSF-12` olarak tanımlanır; Pres kapasite, V710 geçişi ve sabit `3000` net kampanya MOQ kuralı bu fırına bağlıdır. `Pres` tipinde `LSF-12` dışında satır bulunması veya birden fazla Pres satırı yazılması precheck hatasıdır. |
| 5 | Ürün Master tablosu | Bitmiş Ürün Kodu, Model Kodu, Model Tanımı, Azami Stok Miktarı | Her bitmiş ürünün ürün kartını tek yerde tutar. `Model Kodu` ve `Model Tanımı`, ürünün üretim modelini belirtir; `Azami Stok Miktarı`, plan sonu stok değerlendirmesi için ürün bazlı referans sınırdır. Her bitmiş ürün bu tabloda tam olarak bir satırla bulunmalıdır. Aynı bitmiş ürün için tekrarlı satır, eksik model kodu, eksik model tanımı veya negatif azami stok miktarı precheck hatasıdır. Siparişte, ürün ağacında, bitmiş ürün stokunda veya `furnace_product_yield` tablosunda görünen bir bitmiş ürün burada yoksa model kurulmaz. Azami stok sert üretim sınırı değildir; sipariş, MOQ, SAG açma eşitliği veya LSF-12 tam kapasite kullanımı nedeniyle aşılabilir. Aşan miktar raporda gösterilir; ancak sipariş gereği erken üretilmiş ve açık/gelecek siparişe ayrılmış stok azami stok cezasına girmez. |
| 6 | SAG Fırınlar İçin Model Kalıp Kapasitesi tablosu | Model Kodu, Kalıp Sayısı | SAG fırınlarında model bazında kullanılabilecek kalıp sayısını belirtir. LSF-12 Pres fırını için tek kalıp olur, zaten Pres fırına aynı anda tek kalıp bağlanır. |
| 7 | SAG Fırınlar İçin Fırın Kalıp Model Kapasitesi tablosu | Fırın Adı, Vardiyadaki Tur Sayısı, Vagon Sayısı, Vardiyadaki Çalışabileceği Farklı Model Sayısı | Her SAG fırının vardiya bazlı zaman, fiziksel doluluk ve model çeşitliliği kapasitesini belirtir. `Vardiyadaki Tur Sayısı`, fırının o vardiyadaki toplam tur bütçesidir; kalıp değişimi yani setup bu bütçeden tur tüketir ve üretime kalan tur sayısını azaltır. `Vagon Sayısı`, üretim kalıpları, kalıp değişimiyle bağlanan/sökülen kalıplar, mecburi maketler ve opsiyonel maketler toplamının aşamayacağı fiziksel kapasitedir. `Vardiyadaki Çalışabileceği Farklı Model Sayısı`, aynı SAG fırında aynı vardiyada aktif bağlı kalabilecek farklı model sayısını sınırlar; aynı modele ait farklı bitmiş ürünler tek model sayılır. Bu tablo ürün-fırın üretilebilirliğini, randımanı veya model bazlı toplam kalıp adedini tanımlamaz; bunlar sırasıyla `furnace_product_yield` ve `sag_model_mold_capacity` tablolarından gelir. |
| 8 | Fırın Ürün Randıman tablosu | Fırın Adı, Bitmiş Ürün Kodu, Randıman | Hangi bitmiş ürünün hangi fırında üretilebileceğini ve o fırında brüt üretimin kaç net iyi ürüne dönüşeceğini tek tabloda belirtir. Bu tablo beyaz listedir; tabloda satırı olmayan fırın-ürün çifti uyumsuz kabul edilir. Satır varsa `compatible(f,p) = 1` alınır ve aynı satırdaki `Randıman` değeri `yieldScaled(f,p)` parametresine dönüştürülür. Bir bitmiş ürün hem SAG fırında hem de `LSF-12`de üretilebiliyorsa aynı bitmiş ürün için her izinli fırın ayrı satır olarak yazılır. Örneğin bir ürün `LSF04` ve `LSF-12`de üretilebiliyorsa bu ürün için iki satır bulunmalıdır. Bir bitmiş ürün yalnız `LSF-12` ile eşleşiyorsa sadece `LSF-12`de, yalnız belirli SAG fırınlarıyla eşleşiyorsa sadece o SAG fırınlarında üretilebilir. Aynı ürün farklı fırınlarda farklı randımanla çalışabilir; aynı modele bağlı iki farklı bitmiş ürünün aynı fırındaki randımanı da farklı olabilir. Girdi workbook'unda bitmiş ürün kodu içeren tüm tablolardaki ürünler `products` tablosunda ürün kartı olarak ve burada en az bir fırınla eşleşmiş üretilebilir satır olarak bulunmalıdır. `orders`, `bom`, `stock` içinde `Stok Türü = Bitmiş Ürün` veya `products` tablosunda görünen bir bitmiş ürünün burada hiçbir fırınla eşleşmesi yoksa model kurulmadan precheck kritik veri hatası verilir; solver çalıştırılmaz. `Randıman` değeri boş olamaz ve 0 ile 1 arasında olmalıdır. |
| 9 | SAG MOQ tablosu | Model Kodu, MOQ Miktarı | Teknik sheet adı `sag_moq` olmalıdır. Yalnız SAG fırın kampanyaları için model bazlı minimum net üretim miktarını belirtir; kapalı vardiyalar kampanyayı kesmez. Aynı model hem SAG hem LSF-12 üzerinde üretilebiliyorsa bu tablodaki değer yalnız SAG söküm kuralına uygulanır. LSF-12 Pres kampanyaları bu tablodan okunmaz; LSF-12 için kampanya MOQ değeri modelden bağımsız sabit `3000` net üründür. SAG tarafında üretilebilir her model için satır zorunludur; MOQ uygulanmayacaksa `MOQ Miktarı = 0` yazılır. Sadece Pres/LSF-12 üzerinde çalışan modeller bu tabloda yer almamalıdır. |
| 10 | Yoldaki Teslimatlar tablosu | Malzeme, Beklenen Teslimat Tarihi, Miktar | Satın alınmış veya teslimatı kesinleşmiş, ancak plan başlangıcında henüz fiziksel stokta olmayan satın alınan malzemelerin beklenen geliş bilgisini içerir. Bu tablo yalnız ürün ağacında `Bileşen Malzeme Türü = Malzeme` olan kodlar için kullanılır; bitmiş ürün, yarımamul veya model kodu yazılamaz. `Beklenen Teslimat Tarihi` ilgili tarihin ilk vardiyasından itibaren kullanılabilir kabul edilir. Aynı malzeme-tarih satırları veri hazırlığında toplanır. Malzeme kodu stok tablosunda `Stok Türü = Malzeme` olarak bulunmalı, miktar pozitif olmalıdır; bilinmeyen kod veya negatif miktar precheck hatasıdır. Yarımamul için yoldaki teslimat kullanılmaz; yarımamul stoku yetmiyorsa sistem 2 vardiyalık hazırlama kuralını kullanır. |
| 11 | Mecburi Maket Eklenecek Modeller tablosu | Model, Mecburi Maket Adeti | SAG modelleri için üretim kalıbı dışında zorunlu olarak fırında yer tutması gereken maket/vagon adedini belirtir. Mecburi maket üretim değildir; brüt/net üretim, sipariş karşılama, stok girişi, ürün ağacı tüketimi veya MOQ sayacına miktar eklemez. Model ilgili SAG fırın-vardiyada aktif yükleme düzenine giriyorsa mecburi maket vagon kapasitesinden düşülür ve aynı fırın-vardiyada model başına bir kez sayılır; ürün sayısı, kullanılan kalıp sayısı veya tur sayısıyla çarpılmaz. Model için satır yoksa mecburi maket adedi `0` kabul edilir. `V710` veya sadece Pres/`LSF-12` üzerinde çalışan modeller bu tabloda yer alamaz. Tekrarlı model satırı veya negatif maket adedi precheck hatasıdır. |
| 12 | Yakın Plan Vardiya Fırın Sayısı tablosu | Tarih, 1. Vardiyada Açılacak SAG Fırın Sayısı, 2. Vardiyada Açılacak SAG Fırın Sayısı, 3. Vardiyada Açılacak SAG Fırın Sayısı | Yakın dönem için vardiya bazında açılacak SAG fırın sayısını belirtir ve sert eşitlik olarak uygulanır. Kullanıcı hangi SAG fırınların açılacağını seçmez; yalnız açılacak fırın adedini verir. Örneğin bir vardiyada `3` yazıyorsa, açık olacak en uygun 3 SAG fırını sipariş, stok, malzeme, model bağlılığı, kalıp/setup durumu ve kapasiteye göre optimizasyon seçer. LSF-12 bu sayıya dahil edilmez. Plan ufkundaki her tarih ya bu tabloda ya da `far_sag_opening` tablosunda bulunmalıdır; aynı tarih iki tabloda da varsa veya ikisinde de yoksa precheck hatasıdır. |
| 13 | Uzak Plan Toplam Fırın Sayısı tablosu | Tarih, 3 Vardiya Toplamında Açılacak SAG Fırın Sayısı | Uzak dönem için günlük toplam açılacak SAG fırın sayısını belirtir ve sert eşitlik olarak uygulanır. LSF-12 bu sayıya dahil edilmez. Plan ufkundaki her tarih ya bu tabloda ya da `near_sag_opening` tablosunda bulunmalıdır; aynı tarih iki tabloda da varsa veya ikisinde de yoksa precheck hatasıdır. |
| 14 | Plan Takvimi | Tarih, Vardiya No, Sıra No, LSF-12 Kullanılabilir Mi | Kullanıcı girdisi değildir; sistem tarafından plan çalıştırıldığı günden başlayarak günde 3 vardiya kuralıyla üretilen ve siparişlerin tamamı karşılanana kadar otomatik genişletilen iç tablodur. Matematiksel modelde vardiyaların kronolojik sırasını belirtir. `LSF-12 Kullanılabilir Mi` sistem tarafından varsayılan `1` üretilir; LSF-12 arıza/bakım takvimi bu girdi sözleşmesinin parçası değildir. |
| 15 | Başlangıç Fırın Model Durumu | Fırın Adı, Model Kodu, Bağlı Kalıp Sayısı, Başlangıç Kampanya Net Üretim Miktarı | İlk plan koşusunda Excel workbook içindeki `initial_furnace_model_state` sheet'inden okunur ve plan başlangıcında her fırın-model satırı için bağlılık, bağlı kalıp sayısı ve açık kampanya net sayacını belirtir. Setup carry bu tabloda tutulmaz; operasyon kimlikli olduğu için ayrı `initial_furnace_setup_carry` sheet'inden okunur. Sonraki rolling koşularda önceki planın `carry_out` paketindeki `boundModel`, `boundMolds`, LSF-12 bağlı modeli ve `carryOutCampaignNet` değerleri ana kaynak kabul edilir; Excel sheet'i yalnız ilk koşu veya kullanıcı tarafından bilinçli reset yapılması için kullanılır. Başlangıçta üzerinde model bağlı olmayan fırın için satır yazılmaz; satır yokluğu o fırının plan başlangıcında boş olduğu anlamına gelir. SAG fırınlarda aynı fırın için birden fazla satır olabilir; her satır o fırına bağlı bir modeli ve o modele ait bağlı kalıp/kampanya durumunu temsil eder. Aynı model iki farklı SAG fırında başlangıç bağlı modeli olarak yazılamaz; bu durum precheck hatasıdır. `Başlangıç Kampanya Net Üretim Miktarı` aynı fırın-model açık kampanyasının MOQ sayacı başlangıcıdır; boşsa `0` kabul edilir ve negatif olamaz. Bağlı kalıp sayısı negatif olamaz, modelin toplam kalıp kapasitesini aşamaz ve fırının vagon/mecburi maket kapasitesine sığmalıdır. LSF-12 Pres fırında başlangıç modeli bağlıysa en fazla bir satır bulunabilir; Pres fırında bağlı kalıp kullanılmaz ve `0` yazılabilir. |
| 16 | Başlangıç Fırın Setup Carry tablosu | Fırın Adı, Kaynak Model Kodu, Hedef Model Kodu, Kalan Setup Carry Turu | Teknik sheet adı `initial_furnace_setup_carry` olmalıdır. İlk plan koşusunda SAG fırınları için önceki plandan devreden tamamlanmamış setup işlerini operasyon anahtarıyla belirtir. Her satır bir fırında kalan bir setup iş tipini gösterir: `Kaynak Model Kodu` sökülecek/çıkılan modeli, `Hedef Model Kodu` bağlanacak/girilen modeli, `Kalan Setup Carry Turu` ise bu operasyon anahtarında tamamlanmamış kalıp değişim turu sayısını verir. Saf bağlama veya saf söküm gerekiyorsa karşı taraf `Yok` yazılır; iki taraf birden `Yok` olamaz. Aynı fırında birden fazla carry satırı bulunabilir; ancak aynı fırın-kaynak-hedef anahtarı tekrarlanamaz. Satır yoksa ilgili anahtarlar için carry `0` kabul edilir. Negatif değer, Pres/`LSF-12` satırı, bilinmeyen model, kaynak ve hedefin aynı model olması veya iki tarafın da `Yok` olması precheck hatasıdır. Sonraki rolling koşularda önceki planın `carry_out` paketindeki setup carry kayıtları ana kaynak kabul edilir; Excel sheet'i yalnız ilk koşu veya bilinçli reset için kullanılır. |

---

## 6. Süreç ve İş Kuralları

### 6.1. SAG ve Pres Fırın Çalışma Kuralları

- Fırın tipi `SAG` olan fırınların içinde vagonlar bulunur.
- Her vagona bir kalıp sığar.
- Her SAG fırınının bir vardiyada atacağı tur sayısı bellidir.
- Örnek olarak, fırının 26 vagonu ve vardiyada 8 turu olduğu kabul edilsin.
- Kaynak açıklamada, A ürününün 6 kalıbı bu fırına konulduğunda `6 * 8 = 48` adet ürün üretileceği belirtilmiştir.
- Bir fırının 26 vagonunun olması, o fırına her `t` anında 26 kalıp veya maket sığabileceği anlamına gelir.
- Fırın tipi `Pres` olan fırınlarda vagon yapısı yoktur.
- Bir ürün pres tipli bir fırında çalışabiliyorsa, vagon kısıtı uygulanmaz.
- Pres tipli fırında vardiyada nominal/brüt 700 adet üretim yapılacağı kabul edilir; iyi ürün miktarı randıman sonrası net üretim olarak hesaplanır.
- Pres tipli fırında her `t` anında tek bir model bulunur.
- SAG tipli fırının kalıbı ile Pres tipli fırının kalıbı farklıdır.
- Bir ürün hem SAG hem Pres fırında çalışabiliyorsa, aynı vardiyada iki fırın tipinde paralel üretim yalnız sistemin ilgili sipariş için türettiği `urgent(o) = 1` ise veya ilgili termin kesitinde SAG kapasitesi tek başına ihtiyacı karşılayamıyorsa yapılabilir.
- Bir ürün aynı anda 2 farklı SAG fırında çalışamaz.
- Pres fırında her `t` anında tek bir bağlı model/kalıp bulunur; aynı modele ait farklı bitmiş ürünlere üretim kapasitesi dağıtılabilir.
- Her ürün yalnız `Fırın Ürün Randıman` tablosunda satırı bulunan fırınlarda üretilebilir. Sadece `LSF-12` ile eşleşen ürünler yalnız `LSF-12`de, sadece belirli SAG fırınlarıyla eşleşen ürünler yalnız o SAG fırınlarında çalışır. `V710` bu genel kuralın özel doğrulamasıdır: V710 yalnız Pres fırın `LSF-12` üzerinde üretilebilir; `Fırın Ürün Randıman` veya `Başlangıç Fırın Model Durumu` verilerinde V710'ın SAG fırına bağlanması kritik veri hatasıdır.

### 6.2. Model, Ürün, Kalıp ve Mecburi Maket İlişkisi

- Bir modele ait birden fazla ürün olabilir.
- Siparişler ürün numarasına göre gelir.
- Üretim genellikle model bazında planlanır.
- Bazı modellerde mecburi maket ilavesi vardır.
- Örnek olarak, bir fırının vagon sayısı 30 ise bu fırına en fazla 30 kalıp alınabilir.
- ABC isimli modelin mecburi maket adedi 2 ise, ABC ürününün kalıbı fırına konulduğunda fazladan 2 kalıp yeri maket ile işgal edilmelidir.
- Bu durumda ABC ürününün 1 kalıbı kullanılsa da eldeki tüm kalıpları kullanılsa da, mecburi maket ilavesi varsa fazladan belirtilen sayıda kalıp yeri yani vagon işgal edilmiş olmalıdır.
- SAG fırında bir ürün üretileceğinde, ilgili modelin 6 kalıbı olsa bile bu 6 kalıbın tamamını kullanmak zorunlu değildir.
- İhtiyaç kadar kalıp fırına takılabilir.
- Bu durumda, modelin mecburi maket eklenecek bir model olup olmadığı kontrol edilmelidir.
- Mecburi maket eklenecekse, 1 kalıp da kullanılsa 10 kalıp da kullanılsa, belirtilen minimum maket adedi eklenmelidir.
- Mecburi maket aynı fırın-vardiyada model aktifse bir kez sayılır; aynı modelin birden fazla bitmiş ürünü üretildiği için ürün sayısıyla, kullanılan kalıp sayısıyla veya tur sayısıyla çarpılmaz.
- Mecburi maket üretim değildir; brüt/net üretim, sipariş karşılama, stok girişi, BOM tüketimi veya MOQ sayacına miktar eklemez. Yalnız fiziksel SAG vagon kapasitesini işgal eder.
- Mecburi maket ile opsiyonel maket farklıdır. Mecburi maket model aktifse zorunludur; opsiyonel maket ise açılmış SAG fırında kalan boş vagonu doldurmak için kullanılabilir ve tek başına fırın açma gerekçesi olamaz.
- `Mecburi Maket Eklenecek Modeller` tablosunda satırı olmayan model için mecburi maket adedi `0` kabul edilir. Sadece Pres/LSF-12 üzerinde çalışan modeller ve `V710` bu tabloda yer almamalıdır. Aynı model için birden fazla satır veya negatif maket adedi kritik veri hatasıdır.
- Bir modele ait birden fazla bitmiş ürün olabilir.
- Bu ürünler ortak kalıbı kullanıyorsa aynı model sayılır.
- Kalıp sayısı model bazında değerlendirilir.
- Eldeki kalıp sayısı kadar kalıp her `t` anında en fazla o kadar kullanılabilir.

### 6.3. Ürün Ağacı, Yarımamul, Malzeme ve Yoldaki Teslimatlar

- Üretime başlanırken üretim başlangıcında tüketilecek yarımamul ve satın alınan malzeme hazır olmalıdır. Satın alınan malzeme tüketimi üretim vardiyasında doğrudan stoktan düşülür; bitmiş ürün stok girişi de aynı üretim vardiyasında oluşur.
- Yarımamul sınıflandırmasında `Ürün ağacı tablosu`ndaki `Bileşen Malzeme Türü` alanı açıkça `Malzeme` veya `Yarımamul` yazıyorsa bu değer esas alınır. Tür alanı boş veya belirsizse, bileşen kodu `M` ile bitiyorsa doğrudan kullanılabilir yarımamul kabul edilebilir. `M1` veya `M2` ile biten kodlar tek başına yeterli değildir; aynı kökte karşı parçanın da bulunması gerekir.
- Bir bitmiş ürüne ait malzeme girdisi (Bileşen Malzeme Türü = Malzeme) ürün ağacında hiç olmayabilir ya da birden fazla olabilir. Ancak her bitmiş ürünün ürün ağacında (Bileşen Malzeme Türü = Yarımamul olan) en az bir yarımamul girdisi bulunması zorunludur; yarımamul bulunmayan bitmiş ürünler için veri hatası verilir.
- Aynı malzeme kodu birden fazla bitmiş ürünün ürün ağacında kullanılabilir. Aynı yarımamul kodu veya aynı yarımamul kökü de birden fazla bitmiş ürün tarafından ortak bileşen olarak kullanılabilir; sistem tüketimi ürünlerin net üretim miktarlarına göre toplar.
- Yarımamul olarak sınıflanan bileşenlerde kod sonu `M`, `M1` veya `M2` kullanım biçimini belirler.
- Aynı köke ait `M`, `M1` ve `M2` kodlarının her biri veride bulunabilir veya bulunmayabilir. Kök kod; sondaki `M`, `M1` veya `M2` eki kaldırılarak bulunur.
- Kökün `M` kodu varsa doğrudan kullanılabilir yarımamul stokunu ifade eder.
- Kökün `M1` ve `M2` kodları birlikte varsa, bu iki parça çiftlenerek kullanılabilir yarımamul oluşturur. Çiftlenebilir miktar `min(stok(M1), stok(M2))` değeridir.
- Aynı kökte hem `M` hem de `M1/M2` çifti varsa bunlar aynı yarımamul ihtiyacını karşılayan alternatif kaynaklar olarak havuzlanır: `kullanılabilir yarımamul = stok(M) + min(stok(M1), stok(M2))`.
- `M1` veya `M2` kodlarından yalnız biri ana veride tanımlıysa çift oluşturmaz; bu durumda çift kaynaklı kullanılabilir miktar `0` kabul edilir. Model tanımsız karşı parçayı kendiliğinden oluşturmaz. İki kod da ana veride tanımlıysa fakat birinin stoku eksikse eksik taraf 2 vardiya hazırlık kuralıyla sonradan kullanılabilir hale gelebilir.
- Kodun stok tablosunda hiç bulunmaması ile stok miktarının `0` olması farklıdır. Ürün ağacında geçen malzeme ve yarımamul kodları stok tablosunda mutlaka kayıtlı olmalıdır; stok yoksa miktar `0` yazılır. Kayıt yoksa kritik veri hatasıdır.
- Örnek olarak, aynı kökte `M = 8`, `M1 = 10`, `M2 = 15` varsa, toplam kullanılabilir yarımamul `8 + min(10, 15) = 18` adettir.
- Yarımamul eksikse üretim tamamen imkansız sayılmaz; eksik yarımamul sınırsız hazırlama kapasitesiyle hazırlanabilir kabul edilir ve üretim en erken 2 vardiya sonra planlanır.
- Plan başladığı anda stokta eksik olan tüm yarımamuller için hazırlık aynı anda başlatılabilir kabul edilir. Bu nedenle elde yarımamul yoksa ilgili ürün ilk iki vardiyada üretilemez; üçüncü vardiyadan itibaren eksik yarımamul miktarı, kapasite/malzeme/işçilik limiti olmadan hazırlanmış ve kullanılabilir kabul edilir.
- Yarımamul hazırlama ayrıca malzeme, fırın veya işçilik kapasitesi tüketmez; yalnızca 2 vardiyalık zaman etkisi yaratır.
- Ürün ağacında `Bileşen Malzeme Türü` alanında `Malzeme` yazan bileşenler stoktan karşılanıyorsa, ilgili stok miktarı üretim başlangıcı için yeterli olmalıdır.
- `Yoldaki Teslimatlar Tablosu` yalnız satın alınan malzemeler içindir. Bitmiş ürün, yarımamul, model veya fırın bilgisi bu tabloya yazılmaz. Malzeme kodu ürün ağacı ve stok tablosundaki satın alınan malzeme koduyla birebir aynı olmalıdır; stok tablosunda `Stok Türü = Malzeme` kaydı olmayan teslimat satırı kritik veri hatasıdır.
- Satın alınan malzeme stokta eksikse `Yoldaki Teslimatlar Tablosu` incelenir; teslimat üretim vardiyasına kadar kullanılabilir hale geliyorsa üretim başlatılabilir.
- Beklenen teslimat tarihi ilgili günün ilk vardiyasından itibaren kullanılabilir kabul edilir. Üretim hangi vardiyada başlatılıyorsa satın alınan malzeme tüketimi de aynı vardiyada oluşur. Bu üretim ancak eksik satın alınan tüm malzemeler üretim vardiyasına kadar kullanılabilir hale geliyorsa başlatılabilir.
- Aynı malzeme ve aynı beklenen teslimat tarihi için birden fazla satır varsa miktarlar veri hazırlığında toplanır. Teslimat miktarı `0` olan satırlar dikkate alınmaz; negatif miktar veri hatasıdır.
- Malzeme stokta yoksa ve yoldaki teslimat bilgisi de yoksa ilgili ürün üretilemez; sipariş açık kalır, gecikme/açık miktar cezasına girer ve sonuçta malzeme kaynaklı açık olarak raporlanır.

### 6.4. Sipariş Önceliği, MOQ, Azami Stok ve Randıman

- Nihai amaç siparişleri karşılamaktır.
- Öncelik, Sipariş Türü alanı `OEM` olan siparişlerdedir; bu öncelik lexicographic amaç fonksiyonuyla sert şekilde korunur.
- Kapasite sıkışıklığında `OYC` siparişleri bakiye kalabilir.
- Açılması planlanan fırın açıldıysa ve siparişler karşılandıktan sonra boşluk varsa, `products` tablosundaki `Azami Stok Miktarı` kontrol edilir.
- Azami stok değeri sert üretim sınırı değildir; fazla üretim yapılırsa azami stok aşımı sonuçta raporlanır. Ancak operasyonel ceza yalnız siparişe ayrılmayan, başlangıçtan gelen kaçınılmaz stok olmayan ve kanıtlı carry gerekçesi bulunmayan kısım için uygulanır.
- Fazla üretim yapılacaksa ürün seçimi azami stok referansını dikkate alır; azami stok aşımı sistem içi stok maliyeti içinde istenmeyen durum olarak değerlendirilir.
- Operasyonel fazla stok cezası, plan sonunda kalan stoktan başlangıçta zaten elde olup plan talebiyle eritilemeyen kaçınılmaz kısmın ve siparişe ayrıldığı kanıtlanan stokun düşülmesiyle hesaplanır; amaç plan kararlarının yarattığı gerekçesiz fazla stoku cezalandırmaktır.
- SAG fırında aynı modelin aynı fırında bağlı kaldığı ve plan içinde kapanan kampanya toplamı, en az `sag_moq` tablosundaki model bazlı net üretim değeri kadar olmalıdır; kapalı vardiyalar kampanyayı kesmez. LSF-12 Pres fırında bu tablo kullanılmaz ve kampanya eşiği her model için sabit `3000` net üründür.
- Başlangıçta fırına bağlı olan modelin açık kampanyasında birikmiş üretim MOQ limitinin altındaysa ve bu modele ait ürünler için sistemde hiç açık sipariş kalmadıysa VEYA bu modeli MOQ limitine tamamlayacak kadar bileşen malzeme/yarımamul stoku (başlangıç stoku + bekleyen teslimatlar) bulunmuyorsa, sistem kilitlenmeyi (deadlock) önlemek için bu başlangıç kampanyasına özel olarak söküm esnasında MOQ kısıtını otomatik olarak gevşetir. Bu durum dışındaki normal koşullarda ve plan esnasında yeni başlatılan kampanyalarda MOQ kuralı sert kısıt olarak uygulanmaya devam eder.
- MOQ tamamlanması tek başına söküm sebebi değildir; yalnızca modelin sökülebilmesi için gereken minimum kampanya eşiğinin sağlandığını gösterir. Aynı modelde açık sipariş ve üretilebilir kapasite varsa sistem kampanyayı sürdürmeyi tercih eder; model değişimi ancak diğer kısıtlar, öncelikler veya daha yüksek değerli sipariş ihtiyacı bunu gerektiriyorsa yapılır.
- Bir model fırından sökülürken, o modele ait açık siparişlerin söküm vardiyasına kadar tamamlanmış olması tercih edilir. Eğer açık sipariş kalmasına rağmen model sökülürse operasyonel amaç fonksiyonunda açık sipariş slakı oluşur; bu sayede kapasite ve bileşen uygunluğu varsa modelde kalıp üretime devam etmek, sırf MOQ tamamlandı diye sökmeye göre önceliklidir. Malzeme/yarımamul veya daha yüksek öncelikli sipariş çakışması varsa bu tercih fizibiliteyi kilitlemez.
- Varsayılan planlama modu rolling plandır. Plan sonunda açık kalan kampanyalar zorla kapatılmaz; net üretim miktarı sonraki plana devredilir.
- Sipariş karşılama, stok, malzeme tüketimi ve MOQ hesabında randıman sonrası net üretim miktarı esas alınır.

### 6.5. SAG ve Pres Paralel Üretim Kısıtları

- Bir ürünün hem SAG hem Pres fırın uyumu varsa, ürün aynı vardiyada SAG ve Pres fırında paralel üretilebilir; ancak bunun için sistemin ilgili sipariş için türettiği `urgent(o) = 1` olması veya SAG kapasitesinin tek başına ilgili termin ihtiyacını karşılayamaması gerekir.
- Bu koşul yoksa aynı bitmiş ürün aynı vardiyada SAG ve LSF-12 arasında bölünmez.
- Aynı ürün aynı anda iki farklı SAG fırında üretilemez.
- Aynı model aynı vardiyada iki farklı SAG fırında çalışamaz.
- Aynı modelin farklı bitmiş ürünleri aynı fırın-vardiyada birlikte üretilebilir; kullanılan kalıplar ürün bazında atanır.

### 6.6. LSF-12 Pres Fırın Özel Kuralları

- Sistemde şu anda bir adet Pres fırın vardır.
- Bu fırının adı `LSF-12`dir.
- LSF-12'de kalıp değişimi yarım vardiya, yani 4 saat sürer.
- Kalıp değişimi süresince üretim yapılmaz.
- Bu Pres fırında bir vardiyada nominal/brüt 700 adet ürün üretilir; iyi ürün miktarı randıman sonrası net üretim olarak hesaplanır.
- LSF-12 açık olduğunda tam kapasite (700 brüt / geçiş vardiyasında 350 brüt) çalışması ve boşta (idle) beklememesi hedeflenir. Ancak, fırında aktif olan model ve geçiş alternatifi olan V710 modeli için gerekli bileşen malzeme/yarımamul eksikliği bulunuyorsa, planın çözümsüz (infeasible) kalmasını önlemek için kapasite kuralı otomatik olarak esnetilir. Fırın bu durumlarda kapasite düşürebilir veya tamamen boş (idle) kalabilir. Bu durum "LSF12_MATERIAL_BLOCKED" nedeni olarak raporlanır.
- Bu fırında aynı anda tek bir model üretilebilir; aynı modelin farklı bitmiş ürünleri aynı vardiyada birlikte üretilebilir.
- Bu fırın özelinde kampanya MOQ değeri modelden bağımsız sabit `3000` net üründür; `sag_moq` tablosu LSF-12 için kullanılmaz.
- Bu fırında genellikle sürekli `V710` modeli üretilir.
- `V710` modeli bu dokümanda yalnız LSF-12 Pres modelidir; SAG fırınlarda alternatif V710 üretimi yoktur.
- Örnek olarak, bir üründen 300 adet üretim ihtiyacı varsa ve bu ürünün modeli LSF-12'ye bağlandıysa, MOQ 3000 adet olduğu için model sökülemez.
- Böyle bir durumda, aynı modele ait diğer ürünlerin sipariş miktarlarına bakılarak mecburi üretilecek adetler tamamlanabilir.
- Pres fırında bir model sökülüp başka bir model doğrudan bağlanamaz.
- Araya mutlaka `V710` modeli konulmalıdır.
- `V710` modelinden `presMOQ = 3000` kadar net üretim yapıldıktan sonra diğer kalıp bağlanabilir.
- Başka bir ifadeyle, A kalıbından B kalıbına doğrudan geçiş yoktur; araya mutlaka `V710` girmelidir.
- Bu V710 geçiş kuralı varsayılan olarak serttir. Tercih edilmeyen bir durum olmakla birlikte, sistemin `urgent(o) = 1` olarak işaretlediği ilgili siparişi yetiştirmek için gereken LSF-12 geçişinde gevşetilebilir ve bu istisna raporda açıkça gösterilir.
- Plan V710 kampanyası açık ve MOQ tamamlanmadan biterse, sonraki rolling planda V710 dışı modele geçiş ancak devreden V710 net üretimi ile yeni V710 üretimi toplamı `presMOQ = 3000` değerine ulaştıktan sonra serbesttir.
- LSF-12'de model değişimi yapılan vardiyada yarım vardiya setup olur; kalan 350 adetlik brüt kapasite, sipariş kapatma veya kampanya tamamlama durumuna göre sökülen eski model (setup öncesi) ve yeni bağlanan model (setup sonrası) arasında paylaştırılabilir. Bu kapasite paylaşım durumu çıktı Excel raporlarında (Uretim, Firin_Kullanim, Planlama_Ozet ve Uyarılar) detaylı şekilde loglanır.

### 6.7. Kalıp Değişimi ve Tur Kaybı

- SAG fırınlarda kalıp değişiminde bir turluk kayıp olur.
- Örnek olarak, fırın vardiyada 8 tur atıyorsa bir kalıp değişimi sırasında 1 turluk kayıp oluşur.
- 3 yeni kalıp bağlanacaksa 3 turluk kayıp oluşur.
- Bir kalıbın sökülüp başka kalıbın takılması tek kalıp değişim operasyonu olarak 1 tur kaybı oluşturur. Sadece sökülen veya sadece yeni bağlanan kalıplar da kalıp değişim işi olarak dikkate alınır.
- Kalıp değişim işi vardiyadaki tur sayısını aşamaz; aşan değişim bir sonraki vardiyaya sarkar. Örneğin 8 turluk bir fırında 12 kalıplık değişim gerekiyorsa ilk vardiyada en fazla 8 kalıplık değişim yapılır, kalan değişim sonraki açık SAG vardiyasına taşınır.

---

## 7. SAG Fırın Listesi

Bu liste, Excel workbook içindeki `sag_furnace_capacity` sheet'inden gelir. Her satır yalnız SAG tipli bir fırını temsil eder; LSF-12 Pres fırını bu tabloda yer almaz. Fırın adı `furnaces` tablosunda SAG olarak tanımlı olmalıdır, aksi durumda veri hazırlığı kritik hata vermelidir.

`Vardiyadaki Tur Sayısı`, fırının bir vardiyada kullanabileceği toplam çevrim sayısıdır. Kalıp değişimi yani setup bu tur kapasitesinden düşer; kalan tur üretime ayrılır. `Vagon Sayısı`, aynı vardiyada fırına sığabilecek üretim kalıbı, kalıp değişimiyle bağlanan/sökülen kalıp, mecburi maket ve opsiyonel maket toplamının üst sınırıdır. `Farklı Model Kapasitesi`, aynı fırında aynı vardiyada aktif çalışabilecek farklı model sayısını sınırlar; aynı modelin farklı bitmiş ürünleri bu kapasitede tek model sayılır.

| Fırın Adı | Vardiyadaki Tur Sayısı | Vagon Sayısı | Farklı Model Kapasitesi |
|---|---:|---:|---:|
| LSF04 | 8 | 26 | 4 |
| LSF05 | 8 | 30 | 4 |
| LSF06 | 10 | 26 | 4 |
| LSF07 | 10 | 26 | 3 |
| LSF08 | 8 | 34 | 5 |
| LSF13 | 8 | 20 | 2 |

---

## 8. Matematiksel Modelleme

Bu bölüm, yukarıdaki iş kurallarını `Google OR-Tools CP-SAT` ile uygulanabilecek vardiya bazlı bir matematiksel modele dönüştürür.

Modelde tüm karar değişkenleri tamsayı veya ikili (`0/1`) değişken olarak kurulmalıdır. Randıman gibi oranlı değerler CP-SAT uyumu için ölçekli tamsayı olarak tutulur.

### 8.1. Modelleme Yaklaşımı

- Ana zaman birimi vardiyadır.
- Sistem, plan çalıştırıldığı günü plan başlangıcı kabul eder, günde 3 vardiya için iç `Plan Takvimi` üretir ve her vardiyaya kronolojik `Sıra No` atar.
- Çözüm penceresi, sistem tarafından belirlenen plan başlangıç gününün 1. vardiyasından başlar ve sabit gün sayısıyla sınırlandırılmaz; sistem siparişlerin tamamı karşılanana kadar plan ufkunu otomatik genişletir. Teknik uygulamada sonsuz değişkenli tek bir model kurulmak zorunda değildir; ufuk parça parça veya rolling biçimde genişletilebilir. Genişleyen ufukta üretilebilirlik kalmadığı, veri ufku yetersiz olduğu veya sert kısıtlar nedeniyle siparişlerin kapanamayacağı anlaşılıyorsa açık siparişler neden koduyla raporlanır.
- İlk plan koşusunda `Başlangıç Fırın Model Durumu`, operasyon anahtarlı `Başlangıç Fırın Setup Carry` ve stok kayıtları Excel workbook içinden seçilen pencerenin başlangıç durumu olarak yorumlanır. Sonraki rolling koşularda önceki planın `carry_out` paketi başlangıç fırın-model durumu, setup carry, kampanya sayaçları, stok ve yarımamul hazırlığı için ana kaynak olur.
- Üretim kararı ürün, fırın ve vardiya kırılımında verilir.
- Sipariş, stok ve termin karşılama kaydı bitmiş ürün bazında takip edilir. Başlangıç bitmiş ürün stoku aynı ürün içinde önce OEM siparişlere termin FIFO ile, sonra OYC siparişlere termin FIFO ile atanır; stokla tamamen kapanan siparişler üretim ihtiyacı yaratmaz.
- Kalıp, maket, farklı model kapasitesi ve MOQ kampanyası model bazında uygulanır; randıman fırın-bitmiş ürün bazında uygulanır.
- Aynı modeldeki farklı bitmiş ürünler aynı fırın-vardiyada birlikte üretilebilir.
- Aynı modeldeki farklı bitmiş ürünler farklı model kapasitesinde tek model olarak sayılır.
- Aynı modelin farklı bitmiş ürünleri üretildiğinde kalıplar ürün bazında atanır; her kalıp ilgili vardiyada tek bir bitmiş ürün üretir.
- Aynı model aynı vardiyada yalnızca tek bir SAG fırında çalışabilir.
- Aynı bitmiş ürün, fırın uyumu varsa aynı vardiyada bir SAG fırında ve LSF-12 Pres fırında ancak sistemin ilgili sipariş için türettiği `urgent(o) = 1` ise veya SAG kapasite yetmezliği koşuluyla paralel üretilebilir.
- Açılan SAG fırın üretim veya setup için kullanılıyorsa açık SAG fırın sayısına dahil edilir; LSF-12 açma durumu bu sayımdan ayrı izlenir.
- Açılan SAG fırının vagon kapasitesi üretim kalıbı, kalıp değişimi işi, mecburi maket ve opsiyonel maket toplamıyla tam doldurulur; opsiyonel maket tek başına açık fırın gerekçesi olamaz.
- Her fırın-model için bağlılık durumu ayrıca takip edilir. SAG fırınlarda aynı anda birden fazla model bağlı kalabilir; ancak açık SAG vardiyasında bağlı kalan her model üretim kalıbıyla çalışır, bağlı ama pasif model kalmaz. LSF-12 Pres fırında ise her vardiya sonunda tek model bağlı olabilir.
- Fırın kapalıyken bağlı model kümesi korunur ve model/kalıp değişimi yalnız fırının açık sayıldığı setup/üretim vardiyasında yapılabilir.
- Kampanya, ilgili model fırına bağlandığında başlar; setup nedeniyle net üretim `0` olsa bile kampanya başlangıcı sayılır. Fırın kapalı vardiyalar kampanyayı kesmez. SAG fırınlarda başka modellerin eklenmesi veya sökülmesi, bağlı kalmaya devam eden modelin kampanyasını bitirmez; kampanya yalnız ilgili model fırından söküldüğünde biter. Söküm vardiyasında eski modelin setup öncesi üretimi varsa eski kampanyaya yazılır; sonra kalıp değişimi yapılır; tur kalırsa yeni bağlanan modele üretim yazılır. Eski modele ait gecikmiş veya ileri vadeli açık siparişlerin söküm anına kadar kapanması tercih edilir ve kapanmadan söküm açık sipariş slakıyla cezalandırılır; ancak malzeme/yarımamul, kapasite veya daha yüksek öncelikli üretim çakışmasında bu tercih fizibiliteyi kilitleyen sert şart değildir. Rolling planda plan sonunda açık kampanya sonraki plana devredilir ve MOQ nedeniyle zorla kapatılmaz.
- Azami stok sert kısıt değildir; plan sonunda raporlanır ve operasyonel amaç katmanındaki sabit stok maliyetiyle değerlendirilir.
- Yakın plan verisi olan tarihlerde vardiya bazlı SAG fırın açma eşitliği sert uygulanır.
- Yakın plan verisi olmayan uzak plan tarihlerinde günlük toplam SAG fırın açma eşitliği sert uygulanır.
- Üretim, üretim vardiyasında oluşan `fgReceipt` ile sevk edilebilir stoka hemen girer ve aynı vardiyada `ship[o,t]` için termin hesabında kullanılabilir. Fiziksel sevkiyat sonraki vardiyada yapılabilir; termin kontrolünde ise tarih bazlı siparişler için ilgili günün son vardiyasındaki `fgReceipt` sonrası stok oluşumu zamanında kabul edilir.
- Siparişler parçalı karşılanabilir ve termin tarihinden önce oluşan stok siparişi erken kapatabilir. Aynı bitmiş ürün içinde önce OEM siparişler termin FIFO ile, sonra OYC siparişler termin FIFO ile kapatılır. Aynı bitmiş ürün, sipariş türü ve termin tarihindeki satırlar toplulaştırılır; aynı ürün için açık OEM talebi varken OYC siparişe stok atanmaz.

### 8.2. Kümeler ve İndeksler

| Sembol | Açıklama |
|---|---|
| `T` | Plan ufkundaki sıralı vardiyalar kümesi. |
| `D` | Plan ufkundaki tarihler kümesi. |
| `T(d)` | `d` tarihine ait vardiyalar kümesi. |
| `F` | Tüm fırınlar kümesi. |
| `F_SAG` | Tipi `SAG` olan fırınlar kümesi. |
| `F_PRES` | Tipi `Pres` olan fırınlar kümesi. Bu dokümanda mevcut Pres fırın `LSF-12`dir. |
| `P` | Bitmiş ürünler kümesi. |
| `M` | Modeller kümesi. |
| `M0` | `M ∪ {Yok}` kümesi. `Yok`, setup operasyonlarında saf bağlama veya saf söküm tarafını temsil eden sentineldir; gerçek model değildir. |
| `A_SETUP` | Geçerli setup operasyon anahtarları kümesi: `(a,b) ∈ M0 × M0`, `a != b`, iki taraf birden `Yok` değil. |
| `P(m)` | `m` modeline bağlı bitmiş ürünler kümesi. |
| `O` | Siparişler kümesi. |
| `C` | Malzeme ve yarımamul bileşenleri kümesi. |
| `C_MAT` | Satın alınan malzemeler kümesi. |
| `C_SEMI` | Yarımamuller kümesi. |
| `R` | `M`, `M1` ve `M2` biçimlerinden türetilen yarımamul kök kodları kümesi. |

İndeksler:

- `t ∈ T`: vardiya
- `d ∈ D`: tarih
- `f ∈ F`: fırın
- `p ∈ P`: bitmiş ürün
- `m ∈ M`: model
- `o ∈ O`: sipariş
- `c ∈ C`: bileşen
- `r ∈ R`: yarımamul kök kodu

### 8.3. Parametreler

| Parametre | Açıklama |
|---|---|
| `model(p)` | `products` tablosunda ürün `p` için yazılan model kodu. |
| `compatible(f,p)` | `Fırın Ürün Randıman` tablosunda fırın `f` ve bitmiş ürün `p` için satır varsa `1`, aksi halde `0`. |
| `type(f)` | Fırın tipi: `SAG` veya `Pres`. |
| `turns(f)` | SAG fırın `f` için vardiyadaki tur sayısı. |
| `wagons(f)` | SAG fırın `f` için vagon sayısı. |
| `modelCap(f)` | SAG fırın `f` üzerinde aynı vardiyada çalışabilecek farklı model sayısı. |
| `moldCap(m)` | Model `m` için eldeki toplam kalıp sayısı. |
| `dummy(m)` | Model `m` için mecburi maket adedi. Yoksa `0` alınır. |
| `sagMoq(m)` | Model `m` için yalnız SAG fırın kampanyalarında kullanılan minimum üretim miktarı. `sag_moq` tablosundan okunur. |
| `presMOQ` | LSF-12 için sabit kampanya MOQ miktarı. Değer `3000`. |
| `yieldScaled(f,p)` | `Fırın Ürün Randıman` tablosundaki fırın `f` ve bitmiş ürün `p` satırından gelen ölçekli randıman. Örneğin `%92,5` randıman `9250` yazılır. |
| `SCALE` | Randıman ölçeği. Önerilen değer `10000`. |
| `ubNet[p,f,t]` | Ürün `p`, fırın `f`, vardiya `t` için preprocessing ile hesaplanan net üretim üst sınırı. Reified split ve lineerleştirme bağlarında kullanılır. |
| `bom(p,c)` | 1 adet bitmiş ürün `p` için gereken bileşen `c` miktarı. Aynı bileşen `c` birden fazla bitmiş ürün için pozitif değer alabilir. |
| `bomSemi(p,r)` | 1 adet bitmiş ürün `p` için gereken yarımamul kökü `r` miktarı. Ürün ağacındaki `rM`, `rM1` ve `rM2` yarımamul satırları normalize edilerek türetilir. Aynı yarımamul kökü `r` birden fazla bitmiş ürün tarafından ortak kullanılabilir. |
| `hasPurchasedMaterialBom[p]` | Ürün `p` satın alınan malzeme bileşeni içeriyorsa `1`, yalnız yarımamul veya malzemesiz ise `0`. |
| `initialStock(c)` | Bileşen `c` için başlangıç stoku. |
| `initialFG(p)` | Bitmiş ürün `p` için başlangıç stoku. |
| `arrival(c,t)` | Satın alınan malzeme `c` için `t` vardiyasında kullanılabilir olan yoldaki teslimat miktarı. |
| `demand(o)` | Sipariş `o` miktarı. |
| `product(o)` | Sipariş `o`nun bitmiş ürün kodu. |
| `due(o)` | Sipariş `o` için termin vardiyası. Tarih bazlı termin, ilgili günün son vardiyasına bağlanır. |
| `orderType(o)` | Sipariş tipi: `OEM` veya `OYC`. |
| `maxStock(p)` | `products` tablosunda ürün `p` için yazılan plan sonu azami stok miktarı. Her bitmiş ürün için zorunludur. |
| `reservedDemandForStock(p)` | Plan sonunda ürün `p` için stokta tutulması kanıtlanabilen açık/gelecek sipariş veya onaylı carry ihtiyacı üst sınırı. Azami stok cezasından düşülebilecek sipariş rezervini sınırlar. |
| `nearFurnaceReq(t)` | Yakın plan için vardiya `t`de açılması gereken SAG fırın sayısı. LSF-12 dahil değildir. |
| `farFurnaceReq(d)` | Uzak plan için tarih `d`de üç vardiya toplamında açılması gereken SAG fırın sayısı. LSF-12 dahil değildir. |
| `presAvailable(t)` | LSF-12 vardiya `t`de arıza/bakım nedeniyle kapalı değilse `1`, aksi halde `0`. Boş veri `1` kabul edilir. |
| `sagOnlyFeasibilityProven[p,t]` | Ürün `p` için ilgili termin kesitinde SAG-only planın temel statik/muhafazakar kapasite kontrolleriyle yeterli olduğu kanıtlanıyorsa `1`; kanıtlanamıyorsa paralel üretim kapısı açılır. |
| `urgent(o)` | Sipariş `o` için veri hazırlığında sistem tarafından türetilen zamanında karşılama / müşteri duruş riski bayrağı. Termin, açık miktar, mevcut bitmiş ürün stoku, aynı ürün için OEM öncelik kapısı, aynı sipariş türü içindeki daha erken terminli talepler, malzeme/yarımamul uygunluğu, fırın uyumu, zorunlu SAG açma planı ve termin öncesi üretilebilir kapasite dikkate alınarak hesaplanır; kullanıcı girdisi değildir. |
| `initialBoundModel(f,m)` | Plan başlangıcında fırın `f` üzerinde model `m` bağlıysa `1`, aksi halde `0`. `Başlangıç Fırın Model Durumu` tablosunda satırı bulunan fırın-model çiftlerinden türetilir. Başlangıçta boş olan fırın için satır yazılmaz ve ilgili tüm modeller için `0` alınır. SAG fırınlarda aynı fırın için birden fazla model `1` olabilir; LSF-12 için en fazla bir model `1` olabilir. |
| `initialMolds(f,m)` | Plan başlangıcında SAG fırın `f` üzerinde model `m` için bağlı kalıp sayısı. `Başlangıç Fırın Model Durumu` tablosundaki `Bağlı Kalıp Sayısı` kolonundan alınır. |
| `initialSetupCarry(f,a,b)` | Plan başlangıcında SAG fırın `f` için önceki rolling plandan devreden tamamlanmamış setup işi. `a` kaynak model, `b` hedef modeldir; saf bağlama/söküm için `Yok` sentineli kullanılır. İlk plan koşusunda `initial_furnace_setup_carry` tablosundaki operasyon anahtarlı satırlardan türetilir; satır yoksa `0` kabul edilir. Sonraki rolling koşularda önceki planın `carry_out` paketinden devralınır. |
| `initialCampaignNet(f,m)` | Plan başlangıcında fırın `f` üzerinde bağlı model `m` için önceki plandan devreden kampanya net üretim miktarı. `Başlangıç Fırın Model Durumu` tablosundaki `Başlangıç Kampanya Net Üretim Miktarı` kolonundan alınır; boşsa `0` kabul edilir. |
| `approvedSemiCarryQty(c)` | Yarımamul `c` için sonraki rolling plana devredilmesi kanıtlanan kullanılabilir plan sonu stok üst sınırı. Varsayılan `0`. |
| `presCapacity` | LSF-12 normal vardiya üretim kapasitesi. Değer `700`. |
| `presChangeCapacity` | LSF-12 model değişimi yapılan vardiya üretim kapasitesi. Değer `350`. |
| `V710` | Pres fırında model geçişleri arasında kullanılması gereken ara model. |
| `semiLeadTime` | Yarımamul eksikliği halinde hazırlama süresi. Sabit validasyon değeri `2` vardiyadır; değiştirilebilir ayar değildir. |
| `openOrderPenalty` | Plan sonu açık miktarı bir vardiyalık gecikmeden daha ağır saymak için kullanılan sistem içi amaç sabiti. Varsayılan `|T| + 1`. |
| `BIG_M` | Üst sınır bağlama kısıtlarında kullanılan yeterince büyük sabit. |

Veri hazırlığında şu kurallar uygulanır:

- Girdi kaynağı tek Excel workbook'tur. Her gerekli tablo ayrı worksheet olarak bulunmalı ve sheet adları iç tablo adlarıyla aynı olmalıdır. Eksik worksheet veya eksik kolon precheck hatasıdır.
- `Yoldaki Teslimatlar` aynı tarihin ilk vardiyasında kullanılabilir kabul edilir.
- Aynı tarihte `fgReceipt` olarak stokta kullanılabilir hale gelen üretim, ilgili vardiyada `ship[o,t]` için kullanılabilir; gün bazlı terminlerde gün sonu karşılama açısından zamanında kabul edilir.
- `products` tablosu bitmiş ürün ana kartıdır. `orders`, `bom`, `stock` içinde `Stok Türü = Bitmiş Ürün` veya `furnace_product_yield` tablosunda görünen her bitmiş ürün bu tabloda tam olarak bir satırla bulunmalıdır. Eksik ürün kartı, tekrarlı bitmiş ürün, eksik model kodu, eksik model tanımı veya negatif azami stok miktarı kritik veri hatasıdır.
- `Fırın Ürün Randıman` tablosu beyaz listedir. Tabloda bulunmayan fırın-ürün çifti için `compatible(f,p) = 0` alınır ve değişken oluşturulmaz. Bir ürünün üretilebileceği fırın kümesi yalnız bu tablodaki satırlardan oluşur; ürün tek fırınla eşleşiyorsa sadece o fırında üretilebilir. Ürün hem SAG fırında hem de `LSF-12`de üretilebiliyorsa aynı ürün için her izinli fırın ayrı satır olarak bulunmalıdır. Aynı satırdaki `Randıman` değeri `yieldScaled(f,p)` parametresine dönüştürülür. Girdi workbook'unda bitmiş ürün kodu içeren tüm tablolardaki ürünler için en az bir fırın-ürün-randıman satırı bulunmalıdır. `orders`, `bom`, `stock` içinde `Stok Türü = Bitmiş Ürün` veya `products` tablosunda görünen bir bitmiş ürünün hiç üretilebilir fırın satırı yoksa model kurulmadan precheck kritik veri hatası verilir.
- Ürün ağacında geçen her malzeme ve yarımamul stok tablosunda kayıtlı olmalıdır. Stok yoksa miktar `0` yazılır; kayıt eksikse kritik veri hatasıdır.
- Her bitmiş ürünün ürün ağacında en az bir adet 'Yarımamul' türünde bileşeni bulunmak zorunludur. Malzeme türünde bileşen ise hiç olmayabilir ya da birden fazla olabilir. Aynı malzeme veya yarımamul birden fazla bitmiş üründe kullanılabilir; bu durum tekrarlı ana veri hatası değildir. Bu kuralı ihlal eden bitmiş ürünler için precheck aşamasında kritik veri hatası verilir.
- İlk plan koşusunda başlangıç fırın-model durumu, operasyon anahtarlı başlangıç setup carry, ürün master kayıtları, fırın-ürün-randıman satırları, stok kayıtları, siparişler kapanana kadar genişleyen plan ufkunda gereken SAG açılış verileri ve V710 üretilebilirliği kritik ana veridir. Sonraki rolling koşularda başlangıç fırın-model durumu, setup carry ve kampanya sayaçları önceki `carry_out` paketinden devralınır; carry-out paketi yoksa veya eksikse model çalıştırılmaz ve kullanıcıdan başlangıç verisi tamamlaması istenir.
- `V710` yalnız `LSF-12` Pres fırında üretilebilir. `Fırın Ürün Randıman` tablosunda V710 modeline bağlı bitmiş ürünler için SAG fırın satırı bulunursa veya `Başlangıç Fırın Model Durumu` / `carry_out` kayıtlarında V710 bir SAG fırına bağlı görünürse precheck kritik veri hatası verir.
- `C_SEMI` kümesi önce açık `Bileşen Malzeme Türü = Yarımamul` kayıtlarından türetilir. Tür alanı açıkça `Malzeme` ise kod sonu `M` olsa bile malzeme kabul edilir. Tür boş veya belirsizse `M` son eki doğrudan yarımamul kabul edilebilir; `M1` ve `M2` son ekleri ancak aynı kökte iki karşı parça da ana veride tanımlıysa kullanılabilir yarımamul kaynağı oluşturur.
- Aynı kökün `M`, `M1` ve `M2` kayıtları ayrı ayrı bulunabilir veya bulunmayabilir. Eksik biçim stok hesabında `0` kabul edilir; ancak model tanımsız `M1/M2` karşı parçasını üretmez ve ürün ağacında geçen gerçek yarımamul kodunun stok kaydı bulunmalıdır.
- `M` doğrudan kaynak, `M1/M2` ise çift kaynak olarak değerlendirilir. Aynı kökte ikisi de varsa kullanılabilir yarımamul miktarı `stok(M) + min(stok(M1), stok(M2))` mantığıyla hesaplanır.
- Yarımamul eksikliği malzeme eksikliği gibi bloklayıcı stok hatası değildir; eksik yarımamul sınırsız kapasiteyle hazırlanabilir ve en erken 2 vardiya sonra kullanılabilir kabul edilir.
- Yarımamul hazırlama ayrıca malzeme veya fırın kapasitesi tüketmez; yalnızca 2 vardiyalık zaman etkisi yaratır.
- Satın alınan malzeme stokta yoksa üretim, üretim vardiyasındaki stok dengesine göre değerlendirilir. Yoldaki teslimat eksik satın alınan malzemeleri üretim vardiyasına kadar kullanılabilir yapıyorsa üretim başlatılabilir; bitmiş ürün `fgReceipt` ve satın alınan malzeme tüketimi aynı vardiyada oluşur. Teslimat bu vardiyaya yetişmiyorsa ilgili üretim yapılamaz, siparişler açık kalır ve malzeme kaynaklı neden koduyla raporlanır.
- Yoldaki teslimatlar yalnız satın alınan malzemeler için uygulanır; yarımamul akışında `arrival(c,t)` kullanılmaz.
- `semiLeadTime = 2` sabittir. Bu değer sistem tablosunda görünse bile değiştirilebilir parametre değildir; farklı değer girilirse precheck hatası verilir.
- SAG tarafında üretilebilir her model için `sag_moq` satırı bulunmalıdır. MOQ uygulanmayacaksa `MOQ Miktarı = 0` yazılır; SAG modeli için satır yoksa precheck hatasıdır. Sadece Pres/LSF-12 üzerinde çalışan modelin `sag_moq` tablosunda bulunması precheck hatasıdır; aynı model hem SAG hem LSF-12 üzerinde üretilebiliyorsa `sagMoq(m)` yalnız SAG kampanyasına uygulanır. Azami stok değeri ürün kartının parçasıdır; `products` tablosunda eksik veya negatif azami stok değeri varsa model kurulmaz.
- Randıman fırın-bitmiş ürün bazında tanımlanır ve üretilebilirlik ile aynı `Fırın Ürün Randıman` satırında tutulur. Aynı modele bağlı iki bitmiş ürün aynı fırında farklı randımanlara sahip olabilir; başka ürünün, aynı modeldeki başka ürünün veya başka fırındaki randıman değeri otomatik kopyalanmaz. `Randıman` değeri boşsa veya 0 ile 1 aralığı dışında ise satır geçersizdir.
- Plan ufkundaki her tarih için yakın plan vardiya SAG fırın sayısı veya uzak plan günlük toplam SAG fırın sayısı bulunmalıdır; ikisi de yoksa kritik veri hatasıdır. Aynı tarih için hem yakın plan hem uzak plan satırı varsa bu da kritik veri hatasıdır; veri hazırlığı bu durumda birini diğerine üstün saymaz ve model çalıştırılmaz.
- Sipariş miktarı `0` olan satırlar optimizasyona alınmaz, negatif sipariş miktarı veri hatasıdır. Aynı bitmiş ürün, sipariş türü ve termin tarihindeki pozitif satırlar tek talep satırına toplanır.
- Toplulaştırılmış sipariş miktarı doğrudan üretim emri değildir. Veri hazırlığı ve model akışı önce `initialFG(p)` başlangıç bitmiş ürün stokunu aynı ürün içinde OEM siparişlere termin FIFO ile, ardından OYC siparişlere termin FIFO ile ayırır. Başlangıç stoku ile tamamen kapanan sipariş üretim ihtiyacı yaratmaz; yalnız stokla kapanmayan kalan açık miktar `ship`, `openOrder`, `late` ve üretim kararlarının gerekçesi olarak takip edilir.
- Sipariş tablosunda manuel aciliyet veya müşteri duruş riski kolonu bulunmaz. Veri hazırlığı her sipariş için `urgent(o)` değerini türetir. Aynı ürün içinde önce OEM siparişler termin FIFO ile, sonra OYC siparişler termin FIFO ile stoktan düşülür; kalan açık miktar, termin vardiyasına kadar mevcut bitmiş ürün stoku, kesinleşmiş/carry receipt, uygun malzeme-yarımamul, fırın uyumu, zorunlu SAG açma planı ve muhafazakar üretilebilir kapasite üst sınırıyla karşılaştırılır. Siparişin zamanında karşılanacağı bu kontrolle garanti edilemiyorsa `urgent(o) = 1`, garanti ediliyorsa `urgent(o) = 0` alınır. Kanıt güvenilir kurulamazsa müşteri duruşunu kaçırmamak için `urgent(o) = 1` seçilir ve gerekçe rapora yazılır.
- `Fırın Ürün Randıman` tablosunda aynı fırın-ürün çifti birden fazla kez yazılamaz. Tekrarlı satır, boş randıman veya aralık dışı randıman veri hatasıdır.

### 8.4. Karar Değişkenleri

Aşağıdaki tabloda tipi `Int` olan tüm değişkenler, aksi özellikle belirtilmedikçe `0` alt sınırlı ve veri ön işleme aşamasında hesaplanan sonlu üst sınırlı tamsayı değişkenlerdir. `componentUse`, `cumulativeShip`, `presCapacityAt`, `campaignAccumBeforeEnd`, `campaignAccum`, `previousCarryTotal` ve operasyon anahtarlı `previousSetupCarry` gibi ara büyüklükler de ya aynı domain kurallarıyla yardımcı değişken olarak tanımlanmalı ya da açık doğrusal ifade olarak kurulmalıdır.

| Değişken | Tip | Açıklama |
|---|---|---|
| `open[f,t]` | Bool | Fırın `f`, vardiya `t`de açıksa `1`. |
| `active[f,m,t]` | Bool | Fırın `f`, vardiya `t`de model `m` üretim veya setup için vardiya akışına giriyorsa `1`. |
| `boundModel[f,m,t]` | Bool | Vardiya `t` sonunda fırın `f` üzerinde model `m` bağlıysa `1`. SAG fırınlarda aynı anda birden fazla model bağlı olabilir; LSF-12 Pres fırında tek model bağlı olabilir. Fırın kapalıyken korunur. |
| `modelChange[f,t]` | Bool | Fırın `f` üzerinde vardiya `t`de bağlı model kümesi değişiyorsa `1`. LSF-12 için bu değişken tekil Pres model değişimini temsil eder. |
| `diffModel[f,m,t]` | Bool | Fırın `f` üzerinde model `m` için vardiya sonu bağlılık durumunun önceki vardiyaya göre değişip değişmediğini gösterir. |
| `produce[p,f,t]` | Bool | Ürün `p`, fırın `f`, vardiya `t`de gerçek brüt/net üretim alıyorsa `1`. Tüm turlar setup ile tüketiliyorsa `produce = 0` kalır. |
| `gross[p,f,t]` | Int | Ürün `p` için brüt üretim miktarı. Fire öncesi miktardır. |
| `net[p,f,t]` | Int | Ürün `p` için üretim başlangıcı vardiyasına yazılan randıman sonrası net üretim adayı. Bitmiş ürün stokuna giriş `fgReceipt` ile yapılır. |
| `molds[p,f,t]` | Int | SAG fırın `f` üzerinde ürün `p` için kullanılan kalıp sayısı. LSF-12 Pres fırını için `0` alınır. |
| `modelMolds[f,m,t]` | Int | SAG fırın `f` üzerinde model `m` için kullanılan toplam kalıp sayısı. |
| `setupActive[f,m,t]` | Bool | SAG fırın `f` üzerinde model `m` vardiya `t`de setup/kalıp değişim akışına giriyorsa `1`. |
| `setupOnly[f,t]` | Bool | SAG fırın `f` vardiya `t`de açık olup setup turu kullanıldığı halde gerçek ürün üretim turu yoksa `1`. |
| `boundMolds[f,m,t]` | Int | Vardiya `t` sonunda SAG fırın `f` üzerinde model `m` için bağlı kalan kalıp sayısı. Fırın kapalıyken de korunur. |
| `afterCarryMolds[f,m,t]` | Int | SAG fırın `f` üzerinde vardiya `t`de devreden setup carry tamamlandıktan, fakat aynı vardiyanın yeni setup işi başlamadan önce model `m` için bağlı kalan kalıp sayısı. Eski üretim segmenti bu ara duruma bakar. |
| `afterCarryBoundModel[f,m,t]` | Bool | `afterCarryMolds[f,m,t] > 0` ise `1`. Devreden carry tamamlandıktan sonraki ara bağlı model kümesini gösterir. |
| `optionalDummy[f,t]` | Int | SAG fırın `f` üzerinde vardiya `t`de üretim kalıbı ve mecburi maket dışındaki boş vagonları dolduran toplam opsiyonel maket sayısı. Geçiş vardiyasında eski ve yeni yükleme segmentlerinin toplamıdır. |
| `normalOptionalDummy[f,t]` | Int | Geçiş olmayan veya setup-only SAG vardiyasında tek fiziksel yükleme düzenindeki opsiyonel maket sayısı. |
| `oldSegmentOptionalDummy[f,t]` | Int | SAG geçiş vardiyasında setup öncesi eski model segmentindeki opsiyonel maket sayısı. |
| `newSegmentOptionalDummy[f,t]` | Int | SAG geçiş vardiyasında setup sonrası yeni model segmentindeki opsiyonel maket sayısı. |
| `setupStart[f,a,b,t]` | Int | SAG fırın `f` üzerinde vardiya `t`de başlatılan setup operasyon sayısı. `a` kaynak model, `b` hedef modeldir; saf bağlama/söküm için `Yok` sentineli kullanılır. Bu değişken yeni setup işinin kimliğini taşır ve carry aynı anahtarla devreder. |
| `newMolds[f,m,t]` | Int | SAG fırın `f` üzerinde vardiya `t`de tamamlanan setup operasyonlarıyla model `m` için fiilen yeni bağlanan kalıp sayısı. |
| `removedMolds[f,m,t]` | Int | SAG fırın `f` üzerinde vardiya `t`de tamamlanan setup operasyonlarıyla model `m` için fiilen sökülen kalıp sayısı. |
| `rawSetupLoss[f,t]` | Int | SAG fırın `f` için vardiya `t`de başlatılan yeni kalıp değişim operasyonlarından doğan toplam setup tur ihtiyacı. Bir söküm ve bir bağlama aynı `setupStart[f,a,b,t]` anahtarında eşlenirse tek operasyon sayılır. |
| `setupLoss[f,t]` | Int | SAG fırın `f` için vardiyada gerçekten tamamlanan setup turu. Devreden carry ve yeni setup segmentlerinin toplamıdır, vardiya tur sayısını aşamaz. |
| `newSetupRemaining[f,t]` | Int | SAG fırın `f` için vardiya `t` sonunda aynı vardiyada başlatılan yeni setup işlerinden tamamlanmadan kalan toplam tur sayısı. Operasyon anahtarlı kalan miktarlar `setupCarry[f,a,b,t]` içinde saklanır. |
| `usableTurns[f,t]` | Int | SAG fırın `f` için vardiya `t`de setup sonrası üretime ayrılacak tur sayısı. |
| `productionTurns[f,t]` | Int | SAG fırın `f` için vardiya `t`de gerçek üretime ayrılan toplam tur. Segment modelinde `oldProdTurns + newProdTurns` toplamıdır. |
| `hasProductionTurns[f,t]` | Bool | `productionTurns[f,t] > 0` ise `1`. |
| `hasSetupLoss[f,t]` | Bool | `setupLoss[f,t] > 0` ise `1`. |
| `hasNewSetupStart[f,t]` | Bool | Vardiya `t`de aynı fırında yeni bir operasyon anahtarlı setup işi başlatıldıysa `1`. Bu bayrak `1` ise en az bir yeni setup turu aynı vardiyada tamamlanmalıdır. |
| `newSetupComplete[f,t]` | Bool | SAG geçiş vardiyasında yeni model setup işinin tamamı bitmiş ve yeni model üretimi yazılabilir durumdaysa `1`. |
| `previousCarryCleared[f,t]` | Bool | Vardiya `t` içinde devreden operasyon anahtarlı carry tamamen kapandıysa `1`. Bu bayrak `0` iken eski üretim, yeni setup ve yeni üretim yapılamaz. |
| `presChange[t]` | Bool | LSF-12 üzerinde vardiya `t`de model değişimi varsa `1`. |
| `presCapacityAt[t]` | Int | LSF-12 için vardiya `t`de model değişimi sonrası kullanılabilir brüt kapasite. |
| `ship[o,t]` | Int | Sipariş `o` için vardiya `t`de karşılanan miktar. |
| `cumulativeShip[o,t]` | Int | Sipariş `o` için vardiya `t` sonuna kadar kümülatif karşılanan miktar. |
| `orderClosed[o,t]` | Bool | Sipariş `o`, vardiya `t` sonunda tamamen kapanmışsa `1`. Termin FIFO bağlantısında kullanılır. |
| `allOEMClosed[p,t]` | Bool | Bitmiş ürün `p` için vardiya `t` sonunda tüm OEM siparişleri kapanmışsa `1`. OYC stok atamasını kilitlemek için kullanılır. |
| `late[o,t]` | Int | Sipariş `o` için termin sonrası vardiya `t` sonunda açık kalan miktar. |
| `openOrder[o]` | Int | Plan sonunda sipariş `o` için açık kalan miktar. |
| `fgStock[p,t]` | Int | Vardiya `t` sonundaki bitmiş ürün `p` stoku. |
| `fgReceipt[p,t]` | Int | Ürün `p` için vardiya `t`de stok/termin karşılamada kullanılabilir hale gelen bitmiş ürün miktarı. Üretim `t`de başlatıldıysa stok girişi aynı vardiyada oluşur. |
| `materialUseNow[c,p,f,t]` | Int | Satın alınan malzeme `c` için ürün `p`, fırın `f`, vardiya `t` üretiminden doğan aynı vardiya tüketimi. |
| `compStock[c,t]` | Int | Vardiya `t` sonundaki bileşen `c` stoku. |
| `semiPrep[c,t]` | Int | Yarımamul `c` için vardiya `t`de başlatılan hazırlık miktarı. |
| `semiPrepForUse[c,t]` | Int | Plan içinde olgunlaşıp aynı plan içindeki `componentUse` ihtiyacına gidecek yarımamul hazırlığı. |
| `semiPrepCarryOut[c,t]` | Int | Plan sonunda sonraki rolling plana kalan veya henüz olgunlaşmamış yarımamul hazırlığı. |
| `componentUse[c,t]` | Int | Bileşen `c` için vardiya `t`de tüm bitmiş ürünlerin net üretiminden doğan toplam tüketim miktarı. Ortak kullanılan malzeme veya yarımamul aynı stok havuzundan düşer. |
| `semiRootUse[r,t]` | Int | Yarımamul kökü `r` için vardiya `t`de tüm bitmiş ürün üretimine giden toplam yarımamul ihtiyacı. Aynı kökü kullanan ürünlerin ihtiyaçları burada toplanır. |
| `directSemiUse[r,t]` | Int | Yarımamul kökü `r` için `rM` doğrudan stokundan karşılanan kullanım miktarı. |
| `pairSemiUse[r,t]` | Int | Yarımamul kökü `r` için `rM1` ve `rM2` çiftinden karşılanan kullanım miktarı. |
| `orderReservedFG[p]` | Int | Plan sonunda ürün `p` için açık/gelecek siparişe ayrıldığı kanıtlanan bitmiş ürün stoku. Azami stok cezasından düşülür. |
| `penaltyEligibleFG[p]` | Int | Plan sonunda ürün `p` için siparişe ayrılmış stok ve kaçınılmaz başlangıç stoku düşüldükten sonra ceza hesabına girebilecek stok miktarı. |
| `overMaxStock[p]` | Int | Plan sonunda ürün `p` için azami stok miktarını aşan ve sipariş/başlangıç/carry gerekçesi düşüldükten sonra cezaya giren stok miktarı. |
| `extraStock[p]` | Int | Plan sonunda ürün `p` için kalan stokun, siparişe ayrılmış stok ve kaçınılmaz başlangıç stoku düşüldükten sonra operasyonel fazla stok maliyetine giren kısmı. |
| `pairStock[r,t]` | Int | Yarımamul kökü `r` için `rM1/rM2` çiftinden vardiya `t` sonunda kullanılabilir çift miktarı. |
| `usableSemi[r,t]` | Int | Yarımamul kökü `r` için vardiya `t` sonunda doğrudan `M` stoku ve `M1/M2` çifti toplamından kullanılabilir yarımamul miktarı. |
| `allowSagPresParallel[p,t]` | Bool/Param | Ürün `p` için vardiya `t`de SAG ve LSF-12 paralel üretimine izin veren, preprocessing ile sabitlenen kapı. CP-SAT içinde değişken olarak açılırsa sabit gate değerine eşitlenir. |
| `v710Exception[t]` | Bool | Vardiya `t`de sistem tarafından `urgent(o) = 1` olarak işaretlenen ilgili sipariş için V710 geçiş kuralı istisnası kullanılıyorsa `1`. Raporlanmalıdır. |
| `v710ExceptionOrder[o,t]` | Bool | `v710Exception[t]` değerini gerekçelendiren, sistem tarafından riskli bulunan sipariş `o` için vardiya `t`de istisna kanıtı varsa `1`. |
| `directTransitionNeededForDueDate[o,t]` | Bool/Param | LSF-12'de V710 ara kampanyası zorunlu tutulursa sipariş `o` terminine yetişecek üst sınır oluşmadığını, doğrudan geçişe izin verilirse oluşabildiğini gösteren preprocessing kanıtı. |
| `directTransitionSourceModel(o,t)` | Param | `directTransitionNeededForDueDate[o,t] = 1` ise kanıtın varsaydığı LSF-12 kaynak modeli. Kanıt yoksa boş kalır ve ilgili bayrak `0` sabitlenir. |
| `producesDestinationModelForOrder[o,t]` | Bool | LSF-12 vardiya `t`de sipariş `o` ürününün modelini üretip bu receipt'i siparişe atanabilir hale getirebiliyorsa `1`. |
| `orderCanReceiveFromPresShift[o,t]` | Bool | LSF-12 vardiya `t` üretimi sipariş `o` terminine kadar FIFO/OEM kapılarını bozmayacak şekilde kullanılabiliyorsa `1`. |
| `directNonV710PresChange[t]` | Bool | LSF-12 üzerinde vardiya `t`de V710 dışı bir modelden başka V710 dışı modele doğrudan geçiş varsa `1`. |
| `previousSetupCarry[f,a,b,t]` | Int | SAG fırın `f` için vardiya `t` başına devreden operasyon anahtarlı setup carry miktarı. `a` kaynak model, `b` hedef modeldir. |
| `carrySetupTurns[f,a,b,t]` | Int | SAG geçiş vardiyasında önceki açık vardiyadan devreden `a -> b` setup carry işi için kullanılan tur sayısı. |
| `oldProdTurns[f,t]` | Int | SAG geçiş vardiyasında vardiya başında bağlı eski modelin üretimi için kullanılan tur sayısı. |
| `newSetupTurns[f,a,b,t]` | Int | SAG geçiş vardiyasında aynı vardiyada başlatılan `a -> b` setup işi için kullanılan tur sayısı. |
| `newProdTurns[f,t]` | Int | SAG geçiş vardiyasında setup tamamlandıktan sonra vardiya sonunda bağlı yeni modelin üretimi için kullanılan tur sayısı. |
| `oldSegmentActive[f,t]` | Bool | SAG geçiş vardiyasında vardiya başında bağlı eski model segmenti üretime açıksa `1`. |
| `newSegmentActive[f,t]` | Bool | SAG geçiş vardiyasında vardiya sonunda bağlı yeni model segmenti üretime açıksa `1`. |
| `singleLoadActive[f,t]` | Bool | SAG vardiyasında eski/yeni üretim segmentlerine ayrılmayan tek fiziksel yükleme düzeni kullanılıyorsa `1`; geçişsiz üretim ve setup-only vardiyalarını kapsar. |
| `oldSegmentModelActive[f,m,t]` | Bool | SAG geçiş vardiyasında model `m` eski segmentte fiziksel yükleme düzenine giriyorsa `1`; mecburi maket sayımında kullanılır. |
| `newSegmentModelActive[f,m,t]` | Bool | SAG geçiş vardiyasında model `m` yeni segmentte fiziksel yükleme düzenine giriyorsa `1`; mecburi maket sayımında kullanılır. |
| `sameModelContinuation[f,t]` | Bool | SAG vardiyasında vardiya başı ve vardiya sonu üretim modeli değişmeden aynı kaldıysa `1`; geçişsiz normal üretim segmentini temsil etmek için kullanılır. |
| `oldSegmentMolds[p,f,t]` | Int | SAG geçiş vardiyasında ürün `p` için eski model segmentinde kullanılan üretim kalıbı sayısı. |
| `newSegmentMolds[p,f,t]` | Int | SAG geçiş vardiyasında ürün `p` için yeni model segmentinde kullanılan üretim kalıbı sayısı. Setup tarafındaki `newMolds[f,m,t]` ile karıştırılmamalıdır. |
| `oldGross[p,f,t]` | Int | SAG geçiş vardiyasında eski model segmentinde ürün `p` için brüt üretim. |
| `newGross[p,f,t]` | Int | SAG geçiş vardiyasında yeni model segmentinde ürün `p` için brüt üretim. |
| `oldModelNet[p,f,t]` | Int | SAG geçiş vardiyasında setup öncesinde, vardiya başında bağlı eski modelin vadesi gelmiş/gecikmiş talebine yazılan net üretim miktarı. |
| `newModelNet[p,f,t]` | Int | SAG geçiş vardiyasında kalıp değişimi tamamlandıktan sonra, vardiya sonunda bağlı yeni modelin kampanyasına yazılan net üretim miktarı. |
| `campaignNet[p,f,t]` | Int | Ürün `p` için vardiya `t`de ilgili kampanyaya yazılan net üretim miktarı. Normal vardiyada `net`, geçiş vardiyasında `oldModelNet` veya `newModelNet` üzerinden hesaplanır. |
| `setupCarry[f,a,b,t]` | Int | SAG fırın `f` için vardiya `t` sonunda sonraki açık SAG vardiyasına taşan operasyon anahtarlı tamamlanmamış kalıp değişim tur işi. |
| `campaignAccumBeforeEnd[f,m,t]` | Int | Fırın `f` üzerindeki model `m` için vardiya `t` üretimi eklendikten sonra, varsa aynı vardiyadaki söküm kontrolünden hemen önce oluşan kampanya net üretim sayacı. |
| `campaignAccum[f,m,t]` | Int | Fırın `f` üzerindeki model `m` için vardiya `t` sonunda açık kampanyada biriken net üretim sayacı. Model vardiya sonunda bağlı değilse `0` kalır. |
| `campStart[f,m,t]` | Bool | Fırın `f` üzerinde model `m` kampanyası vardiya `t`de başlıyorsa `1`. |
| `campEnd[f,m,t]` | Bool | Fırın `f` üzerinde model `m` kampanyası vardiya `t`de bitiyorsa `1`. |
| `carryOutCampaignNet[f,m]` | Int | Plan sonunda sonraki plana devreden açık kampanyanın toplam net üretim miktarı. |

### 8.5. Yardımcı Değişkenler ve Bağlantılar

Fırın açık değilse model, ürün ve üretim de aktif olamaz:

```text
active[f,m,t] <= open[f,t]
produce[p,f,t] <= open[f,t]
gross[p,f,t] <= BIG_M * produce[p,f,t]
```

Ürün sadece uyumlu olduğu fırında üretilebilir:

```text
produce[p,f,t] <= compatible(f,p)
gross[p,f,t] <= BIG_M * compatible(f,p)
```

Ürün üretimi, ürünün vardiya içinde erişilebilir olan modelini aktif hale getirir. Söküm vardiyasında eski modelin setup öncesi vadesi gelmiş/gecikmiş talebi tamamlanabileceği için aktiflik yalnız vardiya sonu bağlılık durumuna bağlanmaz:

```text
produce[p,f,t] <= active[f,model(p),t]
active[f,m,t] <= sum(produce[p,f,t] for p in P(m)) + setupActive[f,m,t]     for f in F_SAG
active[LSF-12,m,t] <= sum(produce[p,LSF-12,t] for p in P(m))
active[f,m,t] <= previousBoundModel[f,m,t] + boundModel[f,m,t]
```

Açık SAG vardiyasında vardiya başında veya sonunda bağlı kalan her model, setup öncesi eski üretim ve setup sonrası yeni üretim sırası izin verdiği ölçüde aktif üretim adayıdır; bağlı ama pasif model bırakılmaz. Kapalı vardiyada aktiflik zaten `0` olur ve bağlı model kümesi korunur:

```text
previousBoundModel[f,m,t] <= active[f,m,t] + (1 - open[f,t])     for f in F_SAG
boundModel[f,m,t] <= active[f,m,t] + (1 - open[f,t])             for f in F_SAG
```

Aynı fırında aktif model sayısı fırın tipine göre sınırlandırılır:

```text
sum(active[LSF-12,m,t] for m in M) = open[LSF-12,t]          for f = LSF-12
```

SAG fırınlarda model kapasitesi geçiş vardiyasındaki sıralı eski/yeni görünümüne değil, vardiya sonu bağlı model kümesine uygulanır. Böylece modelCap `1` olan fırında setup öncesi eski model üretimi ve setup sonrası yeni model üretimi aynı vardiyada sıralı görünse bile modelCap ihlali sayılmaz:

```text
sum(boundModel[f,m,t] for m in M) <= modelCap(f)     for f in F_SAG
```

Bağlı model sayısı fırın tipine göre sınırlandırılır. LSF-12 Pres fırında kapalı vardiyalarda da tek bağlı model korunur:

```text
sum(boundModel[LSF-12,m,t] for m in M) = 1
```

Başlangıç durumu, ilk vardiyanın önceki bağlılık durumu olarak kullanılır. `boundModel[f,m,t]` vardiya sonu durumudur; bu nedenle ilk vardiyada fırın açıksa başlangıç modelinden başka modele geçilebilir:

```text
previousBoundModel[f,m,t] =
    initialBoundModel(f,m)       if t = first(T)
    boundModel[f,m,t-1]          otherwise
```

Fırın kapalıyken bağlı model kümesi değiştirilemez. Bağlı model değişimi ancak fırının açık sayıldığı setup/üretim vardiyasında olabilir:

```text
if open[f,t] = 0:
    boundModel[f,m,t] = previousBoundModel[f,m,t]     for all m

diffModel[f,m,t] = abs(boundModel[f,m,t] - previousBoundModel[f,m,t])
modelChange[f,t] = 1 if sum(diffModel[f,m,t] for m in M) >= 1
modelChange[f,t] <= open[f,t]
```

CP-SAT uygulamasında `diffModel` için doğrusal reification kullanılmalıdır. Örneğin `diffModel >= boundModel - previousBoundModel`, `diffModel >= previousBoundModel - boundModel`, `diffModel <= boundModel + previousBoundModel`, `diffModel <= 2 - boundModel - previousBoundModel` bağlantıları kurulup `modelChange` ile toplam fark arasında çift yönlü bağ eklenir.

SAG fırınlarda bağlı kalıp sayısı da fırın kapalıyken korunur. `boundMolds[f,m,t]` de vardiya sonu değeridir; ilk vardiyada önceki değer `initialMolds(f,m)` üzerinden alınır:

```text
previousBoundMolds[f,m,t] =
    initialMolds(f,m)        if t = first(T)
    boundMolds[f,m,t-1]      otherwise

if open[f,t] = 0:
    boundMolds[f,m,t] = previousBoundMolds[f,m,t]     for f in F_SAG, m in M

boundMolds[f,m,t] <= moldCap(m) * boundModel[f,m,t]   for f in F_SAG
boundMolds[f,m,t] >= boundModel[f,m,t]                for f in F_SAG
```

Kapalı fırında bağlı kalan kalıplar da modelin toplam kalıp kapasitesini tüketmeye devam eder. Bu nedenle global kalıp kapasitesi vardiya sonu bağlı kalıplar üzerinden uygulanır:

```text
sum(boundMolds[f,m,t] for f in F_SAG) <= moldCap(m)     for m in M, t in T
```

Vardiya sonunda fırında bağlı kalan kalıplar ve bu modellere ait mecburi maketler aynı fiziksel SAG fırın kapasitesine sığmalıdır. Bu kısıt açık vardiya kadar kapalı vardiyada da geçerlidir; kapalı fırında bağlı kalıplar korunur fakat kapasite üstü bağlı kalıp/maket durumu oluşturulamaz:

```text
sum(boundMolds[f,m,t] for m in M)
+ sum(dummy(m) * boundModel[f,m,t] for m in M)
<= wagons(f)                                      for f in F_SAG, t in T
```

Randıman CP-SAT içinde ölçekli tamsayı olarak uygulanır:

```text
SCALE * net[p,f,t] <= yieldScaled(f,p) * gross[p,f,t]
SCALE * (net[p,f,t] + 1) >= yieldScaled(f,p) * gross[p,f,t] + 1
```

Bu iki eşitsizlik, `net[p,f,t] = floor(gross[p,f,t] * yield / SCALE)` davranışını verir.

Geçiş olmayan vardiyalarda bu formül doğrudan `gross/net` çiftine uygulanır. SAG geçiş vardiyalarında ise randıman eski ve yeni segmentlerde ayrı uygulanır; `net = oldModelNet + newModelNet` toplamı esas alınır ve aynı vardiyada ayrıca toplam `gross` üzerinden ikinci bir floor kısıtı kurulmaz. Çünkü `floor(a) + floor(b)` ile `floor(a + b)` aynı olmak zorunda değildir.

### 8.6. Lexicographic Amaç Fonksiyonu

Amaç fonksiyonu tek seferde karışık ağırlıklarla değil, sıralı çözüm şeklinde uygulanır. Her aşamada önceki aşamanın optimum değeri sabitlenir ve bir sonraki hedef çözülür. Her lexicographic aşamada solver statüsü `OPTIMAL` olmalıdır; yalnız `FEASIBLE` çözüm nihai plan olarak kabul edilmez.

1. OEM siparişleri için birim-vardiya gecikme ve plan sonu açık miktar minimize edilir.
2. OYC siparişleri için birim-vardiya gecikme ve plan sonu açık miktar minimize edilir.
3. OEM ve OYC optimumları sabitlendikten sonra sistem içi sabit operasyonel maliyet toplamı minimize edilir.

Plan sonu açık miktar, bir vardiyalık gecikmeden daha ağır cezalandırılır. Varsayılan `openOrderPenalty = |T| + 1` alınır; böylece bir birim açık miktar, aynı birimin plan ufku boyunca gecikmesinden daha ağırdır.

Operasyonel maliyet katmanı kullanıcıdan ayar almaz. Sistem, OEM/OYC optimumları bozulmadan sabit iç ağırlıklarla aşağıdaki davranışlardan kaçınır. Bu iç ağırlıklar girdi Excel workbook'u içinde yer almaz ve kullanıcı tarafından değiştirilemez; alt kalemler çıktı Excelindeki rapor sheet'lerinde ayrı gösterilir.

| Sistem İçi Maliyet Grubu | İçerik | Beklenen Etki |
|---|---|---|
| Opsiyonel dolgu maliyeti | SAG fırında opsiyonel maket / boş vagon doldurma miktarı | Gereksiz opsiyonel dolgu azalır; mecburi maket ihtiyacı etkilenmez. |
| Stok maliyeti | Plan sonu fazla bitmiş ürün stoku + azami stok aşımı | Terminleri bozmayacak ölçüde stok için üretim ve azami stok aşımı azalır. Azami stok aşımı sistem içinde daha ağır sayılır. |
| Değişim maliyeti | SAG setup tur kaybı + LSF-12 Pres model değişimi + başlatılan kampanya sayısı | Model değişimi, setup-only vardiya ve kısa kampanya eğilimi azalır; mevcut kampanyayı sürdürme eğilimi artar. |

Örnek çözüm akışı:

```text
Obj1 =
    sum(late[o,t] for o in O if orderType(o) = OEM for t > due(o))
  + openOrderPenalty * sum(openOrder[o] for o in O if orderType(o) = OEM)
Solve minimize Obj1
Add Obj1 = optimum_Obj1

Obj2 =
    sum(late[o,t] for o in O if orderType(o) = OYC for t > due(o))
  + openOrderPenalty * sum(openOrder[o] for o in O if orderType(o) = OYC)
Solve minimize Obj2
Add Obj2 = optimum_Obj2

Obj3 =
    optionalDummyInternalWeight * sum(optionalDummy[f,t] for f in F_SAG for t in T)
  + inventoryInternalWeight * (
        sum(extraStock[p] for p in P)
      + overMaxStockInternalWeight * sum(overMaxStock[p] for p in P)
    )
  + changeoverInternalWeight * (
        sum(setupLoss[f,t] for f in F_SAG for t in T)
      + presChangeInternalWeight * sum(presChange[t] for t in T)
      + campaignInternalWeight * sum(campStart[f,m,t] for f in F for m in M for t in T)
    )
Solve minimize Obj3
```

Tüm `...InternalWeight` değerleri kullanıcı girdisi değildir; uygulama içinde sabit tutulur ve raporlarda alt kalemlerin etkisi ayrıca gösterilir. Amaç, kullanıcıya ayar yükü vermeden stok aşımı, Pres değişimi ve kampanya açılışı gibi farklı ölçekli alt kalemleri solver içinde kaybetmemektir.

### 8.7. SAG Fırın Kısıtları

Model bazlı kalıp toplamı, vardiya içinde fırında bulunan üretim veya setup kalıplarını temsil eder. Ürün bazlı üretim kalıpları bu toplamı aşamaz; setup-only vardiyada `modelMolds` pozitif olabilirken `molds[p,f,t]` ve `produce[p,f,t]` sıfır kalabilir:

```text
sum(molds[p,f,t] for p in P(m)) <= modelMolds[f,m,t]     for f in F_SAG
```

Model kalıp kapasitesi aşılmaz:

```text
sum(modelMolds[f,m,t] for f in F_SAG) <= moldCap(m)
```

Bir ürün aynı anda iki farklı SAG fırında üretilemez:

```text
sum(produce[p,f,t] for f in F_SAG) <= 1
```

Aynı model aynı vardiyada iki farklı SAG fırında çalışamaz:

```text
sum(active[f,m,t] for f in F_SAG) <= 1
```

SAG ve LSF-12 paralel üretimi yalnız sistemin ilgili sipariş için türettiği `urgent(o) = 1` veya SAG kapasite yetmezliği varsa yapılabilir. Kapasite yetmezliği alt çözüm çalıştırmadan muhafazakar SAG-only kanıt testiyle değerlendirilir: ürün `p` için ilgili termin vardiyasına kadar kalan açık talebin, LSF-12 hariç SAG tarafında setup carry, temel malzeme kontrolü, model uyumu ve MOQ riskleri dikkate alınarak kesin karşılanabileceği kanıtlanamıyorsa paralel üretim kapısı açılır. Bu kapı optimizasyonun serbest karar değişkeni değildir; preprocessing `allowSagPresParallelParam[p,t]` değerini hesaplar. CP-SAT içinde `allowSagPresParallel[p,t]` değişkeni tutulursa bu parametreye eşitlenir. Kapı yalnız SAG-only planın açıkça yeterli olduğu durumda kapalı kalır; aksi halde operasyonel amaç gereksiz paralelliği zaten tercih etmez.

```text
allowSagPresParallelParam[p,t] = 1
    if urgent(o) = 1 for an order o of product p due in the relevant slice
    or sagOnlyFeasibilityProven[p,t] = 0

allowSagPresParallel[p,t] = allowSagPresParallelParam[p,t]

sum(produce[p,f,t] for f in F_SAG) + produce[p,LSF-12,t]
<= 1 + allowSagPresParallel[p,t]
```

SAG fırın açıldıysa en az bir üretim kalıbı veya gerçek setup kalıbı kullanılmalıdır. Fırın tamamen opsiyonel maketle açık sayılamaz:

```text
sum(modelMolds[f,m,t] for m in M) >= open[f,t]     for f in F_SAG
```

SAG fırınlarda üretim/setup kalıpları, mecburi maket ve opsiyonel maket toplamı fiziksel yükleme düzeni bazında vagon kapasitesini doldurur. Geçiş olmayan vardiyada tek yükleme düzeni vardır. Geçiş vardiyasında ise setup öncesi eski segment ve setup sonrası yeni segment ayrı fiziksel yükleme düzenleridir; eski ve yeni modelin kalıp/maketleri aynı anda fırına sığdırılmaya zorlanmaz.

```text
optionalDummy[f,t]
= normalOptionalDummy[f,t]
  + oldSegmentOptionalDummy[f,t]
  + newSegmentOptionalDummy[f,t]

# Geçiş olmayan veya setup-only tek yükleme düzeni.
singleLoadActive[f,t] <= open[f,t]
singleLoadActive[f,t] <= 1 - oldSegmentActive[f,t]
singleLoadActive[f,t] <= 1 - newSegmentActive[f,t]
singleLoadActive[f,t] >= open[f,t] - oldSegmentActive[f,t] - newSegmentActive[f,t]

sum(modelMolds[f,m,t] for m in M)
+ sum(dummy(m) * active[f,m,t] for m in M)
+ normalOptionalDummy[f,t]
= wagons(f)     only if singleLoadActive[f,t] = 1

normalOptionalDummy[f,t] <= wagons(f) * singleLoadActive[f,t]

# Geçiş vardiyasında eski segment ayrı kontrol edilir.
oldSegmentModelActive[f,m,t] = 1 iff
    sum(oldSegmentMolds[p,f,t] for p in P(m)) > 0

sum(oldSegmentMolds[p,f,t] for p in P)
+ sum(dummy(m) * oldSegmentModelActive[f,m,t] for m in M)
+ oldSegmentOptionalDummy[f,t]
= wagons(f) * oldSegmentActive[f,t]

# Geçiş vardiyasında yeni segment ayrı kontrol edilir.
newSegmentModelActive[f,m,t] = 1 iff
    sum(newSegmentMolds[p,f,t] for p in P(m)) > 0

sum(newSegmentMolds[p,f,t] for p in P)
+ sum(dummy(m) * newSegmentModelActive[f,m,t] for m in M)
+ newSegmentOptionalDummy[f,t]
= wagons(f) * newSegmentActive[f,t]
```

`singleLoadActive`, eski/yeni üretim segmentlerine ayrılmayan fiziksel yükleme düzenlerini kapsar; geçişsiz üretim ve setup-only vardiyaları bu yolla kapasiteye bağlanır. `oldSegmentModelActive` ve `newSegmentModelActive` yardımcıları da ürün kalıbı toplamının pozitifliğiyle çift yönlü bağlanır. Böylece yüksek kalıplı iki model arasında geçiş yapılırken eski segment ve yeni segmentin her biri ayrı ayrı fırına sığar, fakat ikisi aynı anda sığdırılmış gibi çift sayılmaz. `optionalDummy` yalnız kalan vagonu doldurur; tek başına açık fırın gerekçesi olamaz.

Kalıp kullanılabilmesi için ilgili model aktif olmalıdır. Ürün bazlı kalıp ve `produce` yalnız gerçek brüt/net üretim varsa pozitif olur; setup-only vardiyada model kalıbı/setup akışı raporlanır fakat ürün üretim bayrağı açılmaz:

```text
modelMolds[f,m,t] <= moldCap(m) * active[f,m,t]
modelMolds[f,m,t] >= active[f,m,t]
molds[p,f,t] <= moldCap(model(p)) * produce[p,f,t]
molds[p,f,t] >= produce[p,f,t]                         for f in F_SAG
setupActive[f,m,t] <= active[f,m,t]                    for f in F_SAG
setupOnly[f,t] <= open[f,t]                            for f in F_SAG
```

`setupOnly` değeri yalnız `setupOnly <= open` bağlantısıyla bırakılmaz; `productionTurns`, `setupLoss`, `hasProductionTurns` ve `hasSetupLoss` hesaplandıktan sonra aşağıdaki çift yönlü bağlarla kesinleştirilir.

SAG fırın açıkken vardiya sonunda bağlı kalıp sayısı, kalıp değişiminden sonra fırında kalacak son durumu gösterir. Vardiya içinde kullanılan kalıp sayısı, vardiya başında bağlı olan kalıplardan ve aynı vardiyada yeni bağlanan kalıplardan gelebilir; bu sayede setup öncesi eski model üretimi ve setup sonrası yeni model üretimi aynı vardiyada ayrı kampanyalara yazılabilir. Fırın kapalıyken bağlı kalıp sayısı yardımcı bağlantılar bölümündeki süreklilik kuralıyla korunur:

```text
modelMolds[f,m,t] <= afterCarryMolds[f,m,t] + boundMolds[f,m,t]     for f in F_SAG, m in M
modelMolds[f,m,t] <= moldCap(m) * active[f,m,t]                      for f in F_SAG, m in M
```

Opsiyonel maket yalnızca açık SAG fırında kullanılabilir:

```text
normalOptionalDummy[f,t] <= wagons(f) * singleLoadActive[f,t]
oldSegmentOptionalDummy[f,t] <= wagons(f) * oldSegmentActive[f,t]
newSegmentOptionalDummy[f,t] <= wagons(f) * newSegmentActive[f,t]
```

Her kalıp değişim operasyonu bir tur kaybı oluşturur. Bir kalıbın sökülüp başka kalıbın takılması tek operasyon sayılır; yalnız söküm veya yalnız bağlama varsa o hareket de bir operasyon sayılır. Çoklu model bağlı SAG fırınlarda aynı vardiyada birden fazla setup hareketi olabileceği için setup işi artık fırın-vardiya toplamı olarak değil, operasyon anahtarıyla izlenir. `setupStart[f,a,b,t]`, kaynak model `a`dan hedef model `b`ye başlatılan kalıp değişim operasyon sayısıdır. `Yok -> b` saf bağlama, `a -> Yok` saf söküm, `a -> b` ise bir söküm ve bir bağlamanın aynı turda eşlendiği gerçek değişim operasyonudur.

```text
rawSetupLoss[f,t] = sum(setupStart[f,a,b,t] for (a,b) in A_SETUP)
rawSetupLoss[f,t] <= BIG_M * open[f,t]
rawSetupLoss[f,t] <= BIG_M * hasNewSetupStart[f,t]
rawSetupLoss[f,t] >= hasNewSetupStart[f,t]
setupStart[f,a,b,t] <= max(moldCap(a), moldCap(b)) * open[f,t]     for (a,b) in A_SETUP

setupWorkForModel[f,m,t] =
    sum(setupStart[f,a,m,t] for a in M0 if (a,m) in A_SETUP)
  + sum(setupStart[f,m,b,t] for b in M0 if (m,b) in A_SETUP)
  + sum(carrySetupTurns[f,a,m,t] for a in M0 if (a,m) in A_SETUP)
  + sum(carrySetupTurns[f,m,b,t] for b in M0 if (m,b) in A_SETUP)

setupWorkForModel[f,m,t] <= BIG_M * setupActive[f,m,t]
setupActive[f,m,t] <=
    setupWorkForModel[f,m,t]
```

Bir setup operasyonu ancak tamamlandığı vardiyada bağlı kalıp durumunu değiştirir. Bu nedenle `boundMolds` farkı yeni başlatılan toplam işe değil, o vardiyada tamamlanan carry ve yeni setup turlarına bağlanır. Her tamamlanan `a -> b` operasyonu kaynak modelden bir kalıp düşer, hedef modele bir kalıp ekler; `Yok` tarafı yalnız saf bağlama/söküm farkını taşır:

```text
0 <= carrySetupTurns[f,a,b,t] <= previousSetupCarry[f,a,b,t]
0 <= newSetupTurns[f,a,b,t] <= setupStart[f,a,b,t]

completedToModel[f,m,t] =
    sum(carrySetupTurns[f,a,m,t] + newSetupTurns[f,a,m,t] for a in M0 if a != m)

completedFromModel[f,m,t] =
    sum(carrySetupTurns[f,m,b,t] + newSetupTurns[f,m,b,t] for b in M0 if b != m)

moldIncrease[f,m,t] = max(boundMolds[f,m,t] - previousBoundMolds[f,m,t], 0)
moldDecrease[f,m,t] = max(previousBoundMolds[f,m,t] - boundMolds[f,m,t], 0)

completedToModel[f,m,t] = moldIncrease[f,m,t]
completedFromModel[f,m,t] = moldDecrease[f,m,t]

totalCompletedSetup[f,t] =
    sum(carrySetupTurns[f,a,b,t] + newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)

totalRequiredSetup[f,t] =
    max(sum(moldIncrease[f,m,t] for m in M), sum(moldDecrease[f,m,t] for m in M))

totalCompletedSetup[f,t] = totalRequiredSetup[f,t]
```

Bağlı model bayrağı bağlı kalıp sayısıyla uyumlu tutulur. Kalıp sayısı `0` olan model vardiya sonunda bağlı sayılamaz; kalıp sayısı pozitifse model bağlıdır. Modelin kampanya başlangıcı ve bitişi bu bağlılık değişiminden türetilir:

```text
boundMolds[f,m,t] <= moldCap(m) * boundModel[f,m,t]
boundMolds[f,m,t] >= boundModel[f,m,t]     for f in F_SAG, m in M
```

Setup carry devirleri de aynı operasyon anahtarıyla tutulur. Böylece plan sonunda kalan carry yalnız "4 tur setup" olarak değil, örneğin `CHEVY_EXP -> V363_LOW` için `3`, `V363_HIGH -> Yok` için `1` gibi ayrıştırılmış şekilde sonraki plana aktarılır:

```text
setupCarry[f,a,b,t] =
    previousSetupCarry[f,a,b,t] - carrySetupTurns[f,a,b,t]
  + setupStart[f,a,b,t] - newSetupTurns[f,a,b,t]

setupLoss[f,t] =
    sum(carrySetupTurns[f,a,b,t] for (a,b) in A_SETUP)
  + sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)

newSetupRemaining[f,t] =
    sum(setupStart[f,a,b,t] - newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)

usableTurns[f,t] = turns(f) * open[f,t] - setupLoss[f,t]
productionTurns[f,t] = oldProdTurns[f,t] + newProdTurns[f,t]
productionTurns[f,t] = usableTurns[f,t]
usableTurns[f,t] >= 0
```

`previousSetupCarry[f,a,b,t]`, aynı fırının önceki açık SAG vardiyasından devreden `setupCarry[f,a,b,t]` değeridir; aradaki kapalı vardiyalarda değişmeden korunur. Toplam önceki carry pozitifse vardiya önce bu işleri tamamlar. Önceki carry tamamen sıfırlanmadan eski üretim, yeni setup veya yeni üretim açılamaz. CP-SAT uygulamasında bu "carry önce biter" kuralı toplam carry üzerinden reify edilir:

```text
previousCarryTotal[f,t] =
    sum(previousSetupCarry[f,a,b,t] for (a,b) in A_SETUP)

carrySetupTotal[f,t] =
    sum(carrySetupTurns[f,a,b,t] for (a,b) in A_SETUP)

carrySetupTotal[f,t] = min(previousCarryTotal[f,t], turns(f) * open[f,t])

remainingPreviousCarry[f,t] = previousCarryTotal[f,t] - carrySetupTotal[f,t]

oldProdTurns[f,t]
  + sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)
  + newProdTurns[f,t]
<= turns(f) * previousCarryCleared[f,t]

previousCarryCleared[f,t] = 1 iff remainingPreviousCarry[f,t] = 0

rawSetupLoss[f,t] <= BIG_M * previousCarryCleared[f,t]
sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP) >= hasNewSetupStart[f,t]
```

`previousSetupCarry` için uygulama "önceki açık vardiyayı" arayan ayrı bir indeks üretmez; tüm vardiyalar üzerinde operasyon anahtarlı recursive carry state kurulur:

```text
previousSetupCarry[f,a,b,first(T)] = initialSetupCarry(f,a,b)
previousSetupCarry[f,a,b,next(t)] = setupCarry[f,a,b,t]     for t != last(T)
```

Kapalı vardiyada bağlı kalıp durumu korunduğu için `rawSetupLoss = 0`, tüm operasyon anahtarlarında `carrySetupTurns = 0`, `newSetupTurns = 0` olur ve üstteki formül carry miktarını değiştirmeden sonraki vardiyaya taşır. İlk plan koşusunda `initial_furnace_setup_carry` satırı yoksa, sonraki rolling koşularda da önceki plandan devreden kayıt yoksa ilgili tüm `(a,b)` anahtarları için `initialSetupCarry(f,a,b) = 0` kabul edilir.

Setup kaybı tüm turları tüketebilir. Bu durumda `usableTurns[f,t] = 0` ve `setupOnly[f,t] = 1` olur; fırın açık ve setup için kullanılmış sayılır, ancak o vardiyada ürün `produce`, brüt ve net üretim çıkmaz. Örneğin 8 turluk bir SAG fırında `CHEVY_EXP -> V363_LOW` için 7, `V363_HIGH -> Yok` için 5 tur setup gerekiyorsa ilk vardiyada operasyon anahtarlı toplam 8 tur tamamlanır, kalan 4 tur ilgili kaynak-hedef anahtarlarıyla `setupCarry[f,a,b,t]` içinde sonraki açık SAG vardiyasına taşınır.

`setupOnly`, amaç fonksiyonuna güvenilerek tek yönlü bırakılmaz. Aşağıdaki yardımcı bayraklar `setupLoss > 0` ve `productionTurns > 0` koşullarını iki yönde bağlar; ardından `setupOnly = open AND hasSetupLoss AND NOT hasProductionTurns` olarak reify edilir:

```text
setupLoss[f,t] <= turns(f) * hasSetupLoss[f,t]
setupLoss[f,t] >= hasSetupLoss[f,t]

productionTurns[f,t] <= turns(f) * hasProductionTurns[f,t]
productionTurns[f,t] >= hasProductionTurns[f,t]

setupOnly[f,t] <= open[f,t]
setupOnly[f,t] <= hasSetupLoss[f,t]
setupOnly[f,t] <= 1 - hasProductionTurns[f,t]
setupOnly[f,t] >= open[f,t] + hasSetupLoss[f,t] + (1 - hasProductionTurns[f,t]) - 2

sum(produce[p,f,t] for p in P) <= BIG_M * hasProductionTurns[f,t]
```

SAG brüt üretimi geçiş olmayan normal vardiyada kalıp sayısı ve üretim tur sayısından hesaplanır. Ancak geçiş vardiyasında tek bir `usableTurns[f,t]` değeri tüm ürünlere aynı anda çarptırılmaz; aksi halde eski model ve yeni model aynı kullanılabilir turları birlikte tüketmiş gibi kapasite çift sayılır.

Geçiş vardiyasında tur hesabı segment bazında yapılır:

```text
sum(carrySetupTurns[f,a,b,t] for (a,b) in A_SETUP)
  + oldProdTurns[f,t]
  + sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)
  + newProdTurns[f,t]
<= turns(f) * open[f,t]

oldProdTurns[f,t] <= turns(f) * oldSegmentActive[f,t]
newProdTurns[f,t] <= turns(f) * newSegmentActive[f,t]
oldProdTurns[f,t] >= oldSegmentActive[f,t]
newProdTurns[f,t] >= newSegmentActive[f,t]

sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)
>= rawSetupLoss[f,t] - BIG_M * (1 - newSetupComplete[f,t])

sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP) <= rawSetupLoss[f,t]
newSetupRemaining[f,t] =
    rawSetupLoss[f,t] - sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP)
newSetupRemaining[f,t] <= BIG_M * (1 - newSetupComplete[f,t])
newSetupRemaining[f,t] >= 1 - BIG_M * newSetupComplete[f,t]
newProdTurns[f,t] <= turns(f) * newSetupComplete[f,t]

sum(oldSegmentMolds[p,f,t] for p in P(m)) <= afterCarryMolds[f,m,t]
sum(newSegmentMolds[p,f,t] for p in P(m)) <= boundMolds[f,m,t]

oldSegmentMolds[p,f,t] <= moldCap(model(p)) * afterCarryBoundModel[f,model(p),t]
newSegmentMolds[p,f,t] <= moldCap(model(p)) * boundModel[f,model(p),t]
oldSegmentMolds[p,f,t] <= moldCap(model(p)) * compatibility[f,p]
newSegmentMolds[p,f,t] <= moldCap(model(p)) * compatibility[f,p]
oldSegmentMolds[p,f,t] <= moldCap(model(p)) * oldSegmentActive[f,t]
newSegmentMolds[p,f,t] <= moldCap(model(p)) * newSegmentActive[f,t]

sum(oldSegmentMolds[p,f,t] for p in P) >= oldSegmentActive[f,t]
sum(newSegmentMolds[p,f,t] for p in P) >= newSegmentActive[f,t]

sum(newSetupTurns[f,a,b,t] for (a,b) in A_SETUP) <= turns(f) * hasSetupLoss[f,t]
oldSegmentActive[f,t] <= hasSetupLoss[f,t]
newSegmentActive[f,t] <= hasSetupLoss[f,t] + sameModelContinuation[f,t]
sameModelContinuation[f,t] <= open[f,t]
sameModelContinuation[f,t] <= 1 - hasSetupLoss[f,t]
sameModelContinuation[f,t] >= open[f,t] - hasSetupLoss[f,t]

molds[p,f,t] = oldSegmentMolds[p,f,t] + newSegmentMolds[p,f,t]     for f in F_SAG
productionTurns[f,t] = oldProdTurns[f,t] + newProdTurns[f,t]
productionTurns[f,t] = turns(f) * open[f,t] - setupLoss[f,t]
```

`newSetupRemaining` tamsayı olduğu için üstteki iki bağ `newSetupComplete = 1 iff newSetupRemaining = 0` mantığını kurar; yani aynı vardiyada başlatılan tüm operasyon anahtarlı setup işleri tamamlandıysa bayrak isteğe bağlı `0` kalamaz, en az bir anahtarda kalan iş varsa yeni model üretimi açılamaz. `rawSetupLoss = 0` olduğunda `newSetupRemaining = 0` olur ve `newSetupComplete = 1` zorlanır.

Operasyon anahtarlı `carrySetupTurns[f,a,b,t]` önce `previousSetupCarry[f,a,b,t]` yükünü kapatır; toplam carry vardiya kapasitesini tüketirse üretim ve yeni setup otomatik olarak `0` kalır. `oldProdTurns[f,t]` yalnız devreden carry tamamlandıktan sonraki `afterCarryMolds` ara bağlılık durumu için, `newSetupTurns[f,a,b,t]` yalnız aynı vardiyada başlatılan kalıp değişimi / bağlama-sökme işleri için, `newProdTurns[f,t]` yalnız bu yeni setup işlerinin tamamı bittikten sonraki vardiya sonu bağlılık durumu için kullanılabilir. `oldSegmentActive` ve `newSegmentActive`, pozitif üretim turu ve pozitif segment kalıbı ile çift yönlü bağlanır. Geçiş olmayan basit vardiyada `hasSetupLoss[f,t] = 0`, `oldSegmentActive[f,t] = 0`, tüm `(a,b)` anahtarlarında `newSetupTurns[f,a,b,t] = 0` olur ve uygulama tek aktif üretim segmentine indirger; `sameModelContinuation[f,t]` açık ve setup kaybı olmayan vardiyada zorunlu `1` olur. `molds[p,f,t]`, rapor ve genel kalıp kısıtları için segment kalıplarının toplamıdır; bağımsız atanamaz.

Bu nedenle SAG brüt üretimi segment bazında hesaplanır:

```text
oldGross[p,f,t] = oldSegmentMolds[p,f,t] * oldProdTurns[f,t]
newGross[p,f,t] = newSegmentMolds[p,f,t] * newProdTurns[f,t]
gross[p,f,t] = oldGross[p,f,t] + newGross[p,f,t]
```

Geçiş olmayan basit vardiyada bu formül tek üretim segmentine indirgenir. `molds[p,f,t] * usableTurns[f,t]` kısa yolu yalnız geçiş olmayan vardiyalar için kullanılabilir; kullanılsa bile `molds = oldSegmentMolds + newSegmentMolds` toplamı sonuç çıkarımı ve raporlamada korunmalıdır. CP-SAT uygulamasında segment çarpımları `AddMultiplicationEquality` ile veya olası kalıp-tur kombinasyonları tablo kısıtıyla kurulabilir.

### 8.8. LSF-12 Pres Kısıtları

LSF-12 aynı vardiyada tek model çalıştırır:

```text
sum(active[LSF-12,m,t] for m in M) = open[LSF-12,t]
open[LSF-12,t] = presAvailable(t)
```

LSF-12 arıza veya bakım olmadığı sürece açık planlanır. Yakın/uzak fırın açma sayıları yalnız SAG fırınlar için verildiğinden LSF-12 bu sayılara dahil edilmez.

Aynı modelin farklı bitmiş ürünleri LSF-12 üzerinde aynı vardiyada birlikte üretilebilir. Kapasite, aynı modeldeki uyumlu ürünler arasında karar değişkenleriyle dağıtılır; lexicographic amaç nedeniyle önce sipariş/termin ihtiyacını kapatan ürünlere, sonra fazla üretime gider.

Pres fırında vagon ve kalıp sayısı kullanılmaz:

```text
molds[p,LSF-12,t] = 0
```

LSF-12 üzerinde model değişimi varsa vardiya kapasitesi 700 yerine 350 olur:

```text
presChange[t] = modelChange[LSF-12,t]
presCapacityAt[t] = 700 * open[LSF-12,t] - 350 * presChange[t]
sum(gross[p,LSF-12,t] for p in P) + presSlack[t] = presCapacityAt[t]
presSlack[t] >= 0
gross[p,LSF-12,t] <= BIG_M * active[LSF-12,model(p),t]
```

Burada `presChange[t] = 1` ise model değişimi nedeniyle yarım vardiya, yani 4 saat, üretim dışı kalır. Kalan 350 adetlik nominal/brüt kapasite, sipariş kapatma veya kampanya tamamlama önceliklerine göre sökülen eski model (setup öncesi) ve yeni bağlanan model (setup sonrası) arasında paylaştırılabilir. Aynı model içinde farklı bitmiş ürün karışımına geçmek model değişimi değildir ve setup sayılmaz. Bu paylaşım gerçekleştikten sonra elde edilen X ve Y brüt üretim miktarları çıktı raporlarında detaylıca loglanır.

LSF-12 açık olduğunda kapasitesi ürün üretimiyle doldurulur; Pres için idle değişkeni yoktur. Sipariş sonrası fazla üretim SAG fırınlarla aynı şekilde değerlendirilir; fazla stok ve azami stok aşımı sistem içi operasyonel stok maliyetiyle yönetilir. Açık Pres vardiyasında statik olarak uyumlu ve üretilebilir ürün veya V710 alternatifi yoksa bu kapasite eşitliği gevşetilmez, precheck veya structured infeasible nedeni olarak raporlanır. Dinamik malzeme, V710 MOQ veya model sırası nedeniyle eşitlik sağlanamıyorsa `LSF12_FORCED_FULL_CAPACITY`, `LSF12_MATERIAL_BLOCKED`, `LSF12_V710_MOQ_BLOCKED` veya `LSF12_NO_COMPATIBLE_PRODUCT` neden kodlarından biri üretilmelidir.

LSF-12 üzerinde bir modelden başka bir modele doğrudan geçişte V710 ara kampanyası gerekir:

- `A -> B` geçişi, `A != B`, `A != V710`, `B != V710` ise yasaktır.
- Farklı iki V710 dışı model arasında mutlaka bir `V710` kampanyası bulunmalıdır.
- V710 kampanyasının üretim toplamı en az `presMOQ = 3000` kadar olmalıdır.
- LSF-12 üzerinde tüm modeller için kampanya minimumu modelden bağımsız `presMOQ = 3000` olarak uygulanır; `sagMoq(m)` burada kullanılmaz.
- V710 geçiş kuralı varsayılan olarak serttir. Sistem tarafından `urgent(o) = 1` olarak türetilen ilgili siparişi yetiştirmek için gereken doğrudan LSF-12 geçişinde gevşetilebilir; bu durum tercih edilmeyen istisna olarak raporlanır. Bu türetilmiş risk bayrağı yoksa veri eksikliği veya operasyonel maliyet tercihi istisna nedeni değildir.

Uygulamada bu kural iki yoldan biriyle kurulabilir:

- Tercih edilen yaklaşım OR-Tools `AddAutomaton` ile LSF-12 model sırası durum makinesi olarak tanımlanır.
- Eşdeğer olarak kampanya değişkenleri üzerinden, ardışık Pres kampanyaları arasında V710 kampanyası zorunlu kılınır.

Durum makinesi yaklaşımında model durumu kapalı vardiyalarda korunur. Fırın kapalıyken bağlı model değişmiş sayılmaz; bir sonraki açık vardiyada önceki bağlı modelden yeni modele geçiş varsa `presChange[t] = 1` olur. `A -> B` ve `A != B`, `A != V710`, `B != V710` olan doğrudan geçişler automaton veya eşdeğer geçiş kısıtlarıyla reddedilir; yalnız sistem tarafından riskli bulunan ilgili siparişi yetiştirmek için gereken geçişte istisnaya izin verilir ve istisna çıktıya yazılır.

İstisna değişkeni kullanılıyorsa doğrudan V710 dışı geçiş yalnız `v710Exception[t] = 1` olduğunda serbest bırakılır. Bu değişken ancak aynı geçişin yetiştirdiği ilgili siparişte sistem tarafından türetilmiş `urgent(o) = 1` ise `1` olabilir; risk bayrağı yalnız vardiya veya plan geneline yayılmaz.

İstisna kanıtı sipariş-vardiya seviyesinde bağlanır:

```text
directNonV710PresChange[t] <= v710Exception[t]
v710Exception[t] <= sum(v710ExceptionOrder[o,t] for o in O)

v710ExceptionOrder[o,t] <= urgent(o)
v710ExceptionOrder[o,t] <= producesDestinationModelForOrder[o,t]
v710ExceptionOrder[o,t] <= directTransitionNeededForDueDate[o,t]
v710ExceptionOrder[o,t] <= previousBoundModel[LSF-12,directTransitionSourceModel(o,t),t]

producesDestinationModelForOrder[o,t] <= active[LSF-12, model(product(o)), t]
producesDestinationModelForOrder[o,t] <= orderCanReceiveFromPresShift[o,t]
```

`orderCanReceiveFromPresShift[o,t]`, LSF-12'de vardiya `t` üretiminden oluşan `fgReceipt` miktarının sipariş `o` terminine kadar FIFO/OEM kapılarını bozmayacak şekilde siparişe atanabilir olduğunu gösteren yardımcı kanıttır. `directTransitionNeededForDueDate[o,t]` preprocessing ile üretilen sabit kanıttır ve yalnız şu koşullar birlikte sağlandığında `1` olabilir:

1. Sipariş `o` için sistem tarafından `urgent(o) = 1` türetilmiştir, hedef ürün LSF-12 üzerinde üretilebilir ve `t <= due(o)` olur.
2. Vardiya `t`deki geçiş `A -> B`, `A != B`, `A != V710`, `B != V710` biçiminde doğrudan V710 dışı geçiş adayıdır. Preprocessing bu kanıt için `directTransitionSourceModel(o,t) = A` yazar; hedef model `B = model(product(o))` olmalıdır.
3. `remainingDemandForProof[o,t]`, sipariş `o` için `t` başlangıcında mevcut/önceden oluşması kesin stok ve daha önceki LSF-12/SAG receipt üst sınırları düşüldükten sonra termin `due(o)` için açık kalabilecek miktar olarak hesaplanır.
4. `directReceiptUb[o,t]`, `t..due(o)` aralığında doğrudan `B` modeline geçilirse oluşabilecek en iyimser LSF-12 net receipt üst sınırıdır. İlk vardiyada model değişimi varsa `presChangeCapacity`, sonraki vardiyalarda `presCapacity` kullanılır; ürün uyumu, randıman, satın alınan malzeme için aynı vardiya stok uygunluğu ve OEM/FIFO kapısı üst sınır olarak dikkate alınır. Bitmiş ürün receipt'i üretim vardiyasında oluşur.
5. `viaV710ReceiptUb[o,t]`, aynı aralıkta önce V710 ara kampanyası ve `presMOQ = 3000` tamamlanmak zorunda bırakılırsa hedef `B` modeli için oluşabilecek en iyimser LSF-12 net receipt üst sınırıdır. Devreden `initialCampaignNet(LSF-12,V710)` varsa V710 kalan miktarından düşülür; V710 üretimi ve gerekli model değişim vardiyaları termin öncesi kapasiteden tüketilir.
6. Kanıt ancak `directReceiptUb[o,t] >= remainingDemandForProof[o,t]` ve `viaV710ReceiptUb[o,t] < remainingDemandForProof[o,t]` ise `1` olabilir.

Bu hesap muhafazakar olmalıdır: üst sınırlar veya stok atama kanıtı güvenilir kurulamazsa `directTransitionNeededForDueDate[o,t] = 0` alınır ve `directTransitionSourceModel(o,t)` boş kalır. CP-SAT uygulamasında kaynak model bağı yalnız kanıtı olan adaylar için oluşturulur; kanıt yoksa `v710ExceptionOrder[o,t] = 0` sabitlenir. Türetilmiş `urgent(o) = 1` bayrağı tek başına V710 kuralını gevşetmez; doğrudan geçişin gerçekten termin yetiştirdiğini gösteren kanıt da gerekir. Rapor, `v710ExceptionOrder` için `order_id`, kaynak model, hedef model, vardiya, `remainingDemandForProof`, `directReceiptUb` ve `viaV710ReceiptUb` değerlerini göstermelidir.

V710 kampanyası plan sonunda açık kalır ve `presMOQ = 3000` tamamlanmazsa sonraki rolling planda LSF-12 başlangıç durumu V710 olarak devralınır. Bu durumda V710 dışı modele geçiş, devreden `initialCampaignNet(LSF-12,V710)` ile yeni V710 net üretimi toplamı `presMOQ = 3000` değerine ulaşmadan yasaktır.

### 8.9. Kampanya ve MOQ Kısıtları

Bir kampanya, aynı modelin aynı fırında bağlı kaldığı dönemdir. Fırın kapalı vardiyalar kampanyayı kesmez. SAG fırınlarda kampanya, yalnız ilgili model fırından söküldüğünde biter; başka bir modelin aynı fırına eklenmesi veya aynı fırından sökülmesi bu modelin kampanyasını kesmez. Model bağlandığı vardiya setup nedeniyle net üretim `0` olsa bile kampanya başlangıcı sayılır.

Kampanya başlangıcı:

```text
campStart[f,m,t] = 1 if previousBoundModel[f,m,t] = 0 and boundModel[f,m,t] = 1
```

Kampanya bitişi:

```text
campEnd[f,m,t] = 1 if previousBoundModel[f,m,t] = 1 and boundModel[f,m,t] = 0
```

Bu tanımda `t+1` kullanılmaz; son vardiya için ayrıca sınır koşulu gerekmez. `t` ilk vardiya ise `previousBoundModel[f,m,t] = initialBoundModel(f,m)` alınır. Model `t` vardiyası sonunda sökülüyorsa, sökülecek eski modelin setup öncesi üretimi eski model kampanyasına yazılabilir. Açık veya gecikmiş talep kapanmadan söküm seçilirse operasyonel açık sipariş slakı doğar; bu durum yüksek öncelikli talep, kapasite veya malzeme/yarımamul kısıtlarıyla gerekli olabilir ve model salt MOQ dolduğu için otomatik sökülmez. Kalıp değişimi tamamlandıktan sonra tur kalırsa yeni bağlanan modele üretim yazılır. Bu nedenle geçiş vardiyasında setup öncesi eski üretim ve setup sonrası yeni üretim brüt ve net seviyede ayrı tutulur:

```text
oldGross[p,f,t] = oldSegmentMolds[p,f,t] * oldProdTurns[f,t]
newGross[p,f,t] = newSegmentMolds[p,f,t] * newProdTurns[f,t]
gross[p,f,t] = oldGross[p,f,t] + newGross[p,f,t]

SCALE * oldModelNet[p,f,t] <= yieldScaled(f,p) * oldGross[p,f,t]
SCALE * (oldModelNet[p,f,t] + 1) >= yieldScaled(f,p) * oldGross[p,f,t] + 1

SCALE * newModelNet[p,f,t] <= yieldScaled(f,p) * newGross[p,f,t]
SCALE * (newModelNet[p,f,t] + 1) >= yieldScaled(f,p) * newGross[p,f,t] + 1

net[p,f,t] = oldModelNet[p,f,t] + newModelNet[p,f,t]     for transition SAG vardiyaları
oldModelNet[p,f,t] > 0 only if model(p) was bound at vardiya başı
newModelNet[p,f,t] > 0 only if model(p) is bound at vardiya sonu
```

Ana kampanya formulasyonu, kampanya aralığı değişkenleri değil fırın-model bazlı rolling sayaçtır. Her açık kampanya için `campaignAccum[f,m,t]` biriken net üretimi taşır. Model sökülmek istendiğinde sayaç MOQ değerini sağlamıyorsa söküm yasaktır; plan sonunda bağlı kalan modelin sayacı sonraki rolling plana devredilir.

`campaignNet[p,f,t]`, MOQ ve carry hesabına girecek kampanya netidir; uygulamada serbest değişken gibi bırakılmaz:

```text
net[p,f,t] = oldModelNet[p,f,t] + newModelNet[p,f,t]          for f in F_SAG
campaignNet[p,f,t] = oldModelNet[p,f,t] + newModelNet[p,f,t]  for f in F_SAG

campaignNet[p,LSF-12,t] = net[p,LSF-12,t]
```

Normal SAG vardiyasında tek aktif üretim segmenti olduğu için bu toplam normal `net` değerine indirgenir. Geçiş vardiyasında setup öncesi eski kampanya için `oldModelNet[p,f,t]`, setup sonrası yeni kampanya için `newModelNet[p,f,t]` kullanılır. MOQ toplamına yalnız kampanyaya atanmış net üretim miktarları girer. Setup veya kapalı vardiyalar kampanya süresine dahil olabilir, ancak net üretim üretmedikleri için MOQ miktarına katkı vermez.

Sayaç akışı:

```text
previousCampaignAccum[f,m,t] =
    initialCampaignNet(f,m)     if t = first(T) and initialBoundModel(f,m) = 1
    campaignAccum[f,m,t-1]      otherwise

campaignAccumBeforeEnd[f,m,t] =
    previousCampaignAccum[f,m,t]
  + sum(campaignNet[p,f,t] for p in P(m))

campaignAccum[f,m,t] = campaignAccumBeforeEnd[f,m,t]     if boundModel[f,m,t] = 1
campaignAccum[f,m,t] = 0                                 if boundModel[f,m,t] = 0
```

Ön hazırlık adımında (preprocessing) otomatik olarak hesaplanan `moqExempt[f,m]` parametresi:
Eğer model `m`, `f` fırınında başlangıçta bağlı ise (`initialBoundModel(f,m) = 1`):
- `remaining_moq = max(0, sagMoq(m) - initialCampaignNet(f,m))` (veya LSF-12 için `presMOQ - initialCampaignNet(LSF-12,m)`)
- `total_demand`, model `m`'e ait bitmiş ürünlerin net açık sipariş toplamıdır.
- `max_possible_production`, eldeki + yoldaki malzeme/yarımamul stoklarının elverdiği maksimum model `m` üretim limitidir.
- `moqExempt[f,m] = 1` if `remaining_moq > 0` ve (`total_demand == 0` veya `max_possible_production < remaining_moq`)
- Diğer tüm durumlar için `moqExempt[f,m] = 0`.

Kampanya başlangıcından itibaren yeni bir kampanyanın başlayıp başlamadığını izleyen yardımcı `hasStartedNewCampaign[f,m,t]` ikili (binary) değişkeni:

```text
hasStartedNewCampaign[f,m,t] = sum(campStart[f,m,t'] for t' <= t)
```

Bu değişken, modelin başlangıç kampanyası sonlanana kadar `0` değerini alır. Model plan içinde yeni bir kampanyaya başladığında ise `1` olur.

Plan içinde kapanan kampanyalar için MOQ kısıtı, söküm vardiyasında `campaignAccumBeforeEnd` üzerinden uygulanır. Eğer başlangıç kampanyası otomatik muafiyet (`moqExempt[f,m] = 1`) kapsamındaysa, ilk sökümde MOQ kısıtından muaf tutulur; ancak sonraki yeni kampanyalarda kural sert uygulanmaya devam eder:

```text
campaignAccumBeforeEnd[f,m,t] >= sagMoq(m) * (campEnd[f,m,t] - moqExempt[f,m] * (1 - hasStartedNewCampaign[f,m,t]))         for f in F_SAG
campaignAccumBeforeEnd[LSF-12,m,t] >= presMOQ * (campEnd[LSF-12,m,t] - moqExempt[LSF-12,m] * (1 - hasStartedNewCampaign[LSF-12,m,t]))
```

MOQ eşitsizliği kampanyanın ne zaman biteceğini belirleyen bir hedef fonksiyonu değildir; yalnızca `campEnd` kararının izin verilen en erken noktasını tanımlar. Aynı model için açık sipariş ve üretilebilir vardiya kapasitesi kaldığında, `campEnd` erken seçilirse açık sipariş slakı doğar ve operasyonel amaç fonksiyonunda cezalandırılır. Böylece plan MOQ dolduğu anda modeli otomatik sökmez; kapasite ve sipariş varsa kampanya devam eder.

Ayrıca söküm vardiyasında eski modele ait açık siparişlerin kapatılması sert fizibilite kısıtı değildir; operasyonel amaç fonksiyonunda slakla cezalandırılan tercih olarak uygulanır. İki slak ailesi izlenir:
- `unboundSlack[o,f,t]`: Model `m(o)` fırın `f` üzerinden sökülürken teslim vadesi `t` veya öncesi olan sipariş `o` kapanmamışsa oluşan gecikmiş sipariş slakı.
- `unboundOpenOrderSlack[o,f,t]`: Model `m(o)` fırın `f` üzerinden sökülürken teslim vadesi `t` sonrasında olan sipariş `o` henüz kapanmamışsa oluşan ileri vadeli açık sipariş slakı.
- `cumulativeShip[o,t] = initialAllocated[o] + sum(ship[o,k] for k <= t)`: Sipariş bazlı kümülatif karşılanan miktar.

Model `m` fırın `f` üzerinden sökülürken (`campEnd[f,m,t] = 1`), ilgili siparişler için slaklı tercih kısıtları:

```text
cumulativeShip[o,t] + unboundSlack[o,f,t] >= quantity[o] * campEnd[f,m,t]              for due(o) <= t
cumulativeShip[o,t] + unboundOpenOrderSlack[o,f,t] >= quantity[o] * campEnd[f,m,t]     for due(o) > t
```

Bu slaklar yüksek ağırlıkla cezalandırılır. Sonuç olarak kapasite ve bileşen uygunluğu varsa sistem modelde kalıp üretime devam etmeyi, sırf MOQ tamamlandı diye sökmeye tercih eder; fakat daha yüksek öncelikli sipariş, kapasite veya malzeme/yarımamul çakışması varsa model sökümü fizibiliteyi kilitlemez.

Planlama modu rolling plandır. Plan ufku sonunda hâlâ bağlı olan kampanyalar açık kampanya olarak sonraki plana devredilir; bu kampanyalar için plan sonunda MOQ sert kısıtı uygulanmaz. Devreden miktar:

```text
carryOutCampaignNet[f,m] = campaignAccum[f,m,last(T)]     if boundModel[f,m,last(T)] = 1
carryOutCampaignNet[f,m] = 0                              if boundModel[f,m,last(T)] = 0
```

Önceki plandan devreden kampanyalar için `initialCampaignNet(f,m)` sayaç başlangıcıdır ve operasyonel kampanya başlatma maliyetine tekrar girmez. Plan içinde yeni bağlanan modeller için sayaç `0`dan başlar. CP-SAT uygulamasında koşullu eşitlikler reified doğrusal kısıtlarla kurulmalıdır. Raporlama için kampanya başlangıç/bitiş vardiyaları `campStart`, `campEnd` ve bağlılık değişimlerinden türetilir; modelin fizibilitesi bu raporlama aralığı değişkenlerine bağlı değildir.

Bu kural ürün bazlı değil model bazlıdır. Aynı modeldeki farklı bitmiş ürünler kampanya toplamına birlikte dahil edilir.

Plan sonunda sonraki rolling koşuya devredilecek tam durum paketi şunları içerir: `fgStock[p,last(T)]`, `compStock[c,last(T)]`, `boundModel[f,m,last(T)]`, `boundMolds[f,m,last(T)]`, LSF-12 bağlı modeli, `carryOutCampaignNet[f,m]`, pozitif olan her `setupCarry[f,a,b,last(T)]` için operasyon anahtarlı setup carry satırı ve henüz olgunlaşmamış `semiPrepCarryOut[c,t]` kayıtlarının kalan olgunlaşma süreleri. Setup carry satırında fırın, kaynak model, hedef model ve kalan setup turu birlikte yazılır; yalnız toplam tur yazılamaz. Satın alınan malzeme tüketimi üretim vardiyasında stoktan düşüldüğü için plan ufku dışına taşan ayrı malzeme tüketimi devri tutulmaz.

### 8.10. Stok, Ürün Ağacı ve Teslimat Kısıtları

Bitmiş ürün stoku, üretim vardiyasında stok/termin için kullanılabilir hale gelen `fgReceipt` girişinden güncellenir:

```text
fgStock[p,t] =
    previousFGStock[p,t]
  + fgReceipt[p,t]
  - sum(ship[o,t] for o in O if product(o) = p)
```

`previousFGStock[p,t]`, `t` ilk vardiya ise `initialFG(p)`; değilse `fgStock[p,t-1]` değeridir.

Bitmiş ürün stoku negatif olamaz:

```text
fgStock[p,t] >= 0
```

Azami stok sert kısıt değildir. Plan sonunda azami stok aşımı raporlanır, fakat operasyonel ceza yalnız siparişe, başlangıçtan gelen kaçınılmaz stoka veya kanıtlı sonraki plan devrine bağlanamayan fazla stok için uygulanır. Sipariş gereği erken üretilmiş ve açık/gelecek siparişe ayrılmış stok azami stok cezasına girmez. Başlangıçta zaten elde olan ve plan talebiyle eritilemeyen kaçınılmaz stok da solver kararından bağımsız olduğu için operasyonel fazla stok cezasına doğrudan yüklenmez:

```text
unavoidableInitialFG[p] = max(0, initialFG(p) - sum(demand(o) for o in O if product(o)=p))

orderReservedFG[p] =
    plan sonunda ürün p için henüz sevk edilmemiş açık/gelecek siparişlere ayrıldığı
    raporlanabilir şekilde kanıtlanan stok miktarı

orderReservedFG[p] <= fgStock[p,last(T)]
orderReservedFG[p] <= reservedDemandForStock[p]

penaltyEligibleFG[p] =
    max(0, fgStock[p,last(T)] - unavoidableInitialFG[p] - orderReservedFG[p])

extraStock[p] = penaltyEligibleFG[p]
overMaxStock[p] = max(0, penaltyEligibleFG[p] - maxStock(p))
```

`reservedDemandForStock[p]`, ürün `p` için plan sonunda stokta tutulması gereken kanıtlı sipariş/carry ihtiyacının üst sınırıdır. Bu değer açık sipariş bakiyesi, plan ufku dışına taşan onaylı sipariş ihtiyacı veya raporlanabilir sipariş rezervasyonu dışında artırılamaz. `orderReservedFG[p]` serbest bir af değişkeni değildir; gereksiz stok fazlasını ceza dışına almak için kullanılamaz. `extraStock[p]`, başlangıçta zaten elde olup plan talebiyle eritilemeyen kaçınılmaz stok kısmını ve siparişe ayrılmış stok kısmını cezalandırmaz.

Böylece plan içinde üretilip sipariş veya carry gerekçesi olmadan kalan stok cezalandırılır; talebi olmayan başlangıç stoku ve sipariş gereği üretilmiş rezerv stok ise solver kararından bağımsız veya müşteri talebi kaynaklı olduğu için ceza üretmez.

CP-SAT uygulamasında `penaltyEligibleFG` ve `overMaxStock` için `AddMaxEquality` veya eşdeğer doğrusal yardımcı değişken kullanılmalıdır. `maxStock(p)` her bitmiş ürün için `products` tablosundan geldiği için sınırsız azami stok istisnası yoktur.

Bileşen ihtiyacı net üretim miktarına göre hesaplanır. Satın alınan malzeme tüketimi üretim vardiyasında gerçekleşir; stoktan düşüm ve bitmiş ürün stok girişi aynı vardiyada oluşur. Satın alınan malzeme stokta yoksa yalnız üretim vardiyasına kadar kullanılabilir hale gelen yoldaki teslimatlar üretimi mümkün kılar.

Ürün ağacında aynı malzeme kodu birden fazla bitmiş üründe geçiyorsa, ilgili ürünlerin tüketimi aynı `componentUse[c,t]` toplamına yazılır ve aynı `compStock[c,t]` stok havuzundan düşülür. Bu kullanım ortak malzeme tüketimidir; aynı bileşenin farklı bitmiş ürünlerde görünmesi tekrarlı ana veri hatası değildir.

```text
materialUseNow[c,p,f,t] = bom(p,c) * net[p,f,t]                    for c in C_MAT

componentUse[c,t] =
    sum(materialUseNow[c,p,f,t] for p in P for f in F)

fgReceipt[p,t] =
    sum(net[p,f,t] for f in F)
```

Burada `ubNet[p,f,t]`, preprocessing ile hesaplanan net üretim üst sınırıdır. Satın alınan malzeme için gecikmeli tüketim bayrağı veya plan dışı malzeme tüketim devri kurulmaz; malzeme uygunluğu üretim vardiyasındaki stok dengesiyle sağlanır.

Yarımamullerde ürün ağacı satırları önce kök koda normalize edilir. Aynı köke ait `rM`, `rM1` ve `rM2` satırları aynı yarımamul ihtiyacının farklı stok biçimleridir; aynı ürün ağacında aynı kök birden fazla kez görünüyorsa miktar tek ihtiyaç olarak değerlendirilir. Aynı kök için çelişen `Bileşen Miktarı` değerleri veri hatasıdır. Aynı yarımamul kodunun veya aynı yarımamul kökünün birden fazla bitmiş üründe görünmesi ise veri hatası değildir; `semiRootUse[r,t]` bu ürünlerin ihtiyaçlarını toplar:

```text
semiRootUse[r,t] =
    sum(bomSemi(p,r) * net[p,f,t] for p in P for f in F)
```

Satın alınan malzemeler için stok vardiya sonunda güncellenir:

```text
compStock[c,t] =
    previousCompStock[c,t]
  + arrival(c,t)
  - componentUse[c,t]                 for c in C_MAT
```

Satın alınan malzeme stoku negatif olamaz:

```text
compStock[c,t] >= 0                   for c in C_MAT
```

Malzeme stokta yoksa ve yoldaki teslimat üretim vardiyasına yetişiyorsa, ilgili ürün o vardiyada üretime başlatılabilir. Bu durumda ürün üretim vardiyasında stok/termin için kullanılabilir sayılır ve satın alınan malzeme aynı vardiyada tüketilir. Malzeme üretim vardiyasına yetişmiyorsa ilgili ürün üretilemez; sipariş açık kalır ve OEM/OYC gecikme hedeflerinde cezaya girer. Sonuç raporunda bu açık miktar malzeme kaynaklı olarak işaretlenmelidir. Zorunlu SAG fırın açma sayısı nedeniyle hiçbir üretilebilir ürün bulunamıyorsa bu durum SAG fırın açma planı ile malzeme uygunluğu arasında çözümsüz çakışma olarak raporlanır.

Yarımamuller için eksik miktar 2 vardiya hazırlama süresiyle tamamlanabilir. Yarımamul hazırlama sınırsız kapasitelidir ve ayrıca malzeme veya fırın kapasitesi tüketmez:

```text
directSemiUse[r,t] + pairSemiUse[r,t] = semiRootUse[r,t]

componentUse[rM,t] = directSemiUse[r,t]      if rM in C_SEMI
componentUse[rM1,t] = pairSemiUse[r,t]       if rM1 in C_SEMI
componentUse[rM2,t] = pairSemiUse[r,t]       if rM2 in C_SEMI

directSemiUse[r,t] = 0                       if rM not in C_SEMI
pairSemiUse[r,t] = 0                         if rM1 not in C_SEMI or rM2 not in C_SEMI

compStock[c,t] =
    previousCompStock[c,t]
  + semiPrep[c,t-semiLeadTime]
  - componentUse[c,t]                 for c in C_SEMI

compStock[c,t] >= 0                   for c in C_SEMI
```

`t-semiLeadTime` plan başlangıcından önce kalıyorsa ilgili `semiPrep` değeri `0` kabul edilir. Bu nedenle başlangıçta stokta olmayan bir yarımamul, en erken 2 vardiya sonra üretimde kullanılabilir. Plan başlangıcında eksik olan tüm yarımamuller aynı anda hazırlığa alınabilir; ilk iki vardiyada bu eksik miktar kullanılamaz, üçüncü vardiyadan itibaren yarımamul hazırlama miktarı kapasiteyle sınırlanmaz.

`Yoldaki Teslimatlar` yarımamul için kullanılmaz; yarımamul stok akışında `arrival(c,t)` yoktur. `semiPrep`, yalnız planlanan bitmiş ürün üretiminin eksik yarımamul ihtiyacı kadar açılır; yarımamul stokunu gereksiz şişirmek için kullanılmaz. Plan içinde olgunlaşıp kullanılacak hazırlık ile sonraki rolling plana devredilecek hazırlık ayrı izlenir:

```text
semiPrep[c,t] = semiPrepForUse[c,t] + semiPrepCarryOut[c,t]

sum(semiPrepForUse[c,t] for t in T) <= sum(componentUse[c,t] for t in T)     for c in C_SEMI
compStock[c,last(T)] <= initialStock(c) + approvedSemiCarryQty(c)       for c in C_SEMI

semiPrepCarryOut[c,t] = 0
    if t + semiLeadTime <= last(T)

sum(semiPrepCarryOut[c,t] for t in T if t + semiLeadTime > last(T))
<= approvedSemiCarryQty(c)                                              for c in C_SEMI
```

`approvedSemiCarryQty(c)`, sonraki rolling plana devredilmesi kanıtlanan yarımamul ihtiyacının üst sınırıdır; doğrulama verisinde aksi belirtilmedikçe `0` alınır. Böylece plan içi kullanılabilir yarımamul stokunu gereksiz şişirme engellenir, fakat kanıtlı rolling carry ihtiyacı olan durumda plan sonu stoku veya olgunlaşacak carry tamamen yasaklanmaz.

`semiPrepCarryOut[c,t]`, plan sonunda henüz olgunlaşmayacak ve sonraki rolling plana devredilecek hazırlığı temsil eder. Plan içinde olgunlaşabilecek hazırlık `semiPrepForUse` veya stok dengesi üzerinden kapanmalıdır; `semiPrepCarryOut` içine yazılamaz. Bu kayıtlar plan içi `componentUse` tarafından tüketilmiş gibi sayılmaz; `carry_out` paketine kalan olgunlaşma süresiyle yazılır. Gereksiz yarımamul şişirmeyi engellemek için `semiPrepCarryOut`, yalnız rolling carry-out paketinde açık üretim veya plan dışına taşan ihtiyaç kanıtı varsa ve `approvedSemiCarryQty(c)` üst sınırı içinde açılabilir.

`sum(semiPrepForUse) <= sum(componentUse)` kuralı yalnız anti-inflation toplam sınırıdır; hazırlığın doğru vardiyada olgunlaşmasını tek başına ispatlamaz. Zaman fizibilitesi, `compStock[c,t] >= 0` stok dengesi ve `semiPrep[c,t-semiLeadTime]` olgunlaşma girişiyle sağlanır. Bu nedenle `t+1` tüketimi için `t` vardiyasında başlatılan hazırlık kullanılamaz; ancak `t+2` ve sonrası için stok dengesine girebilir.

Planlama sırasında aynı kökün doğrudan `M` stoku ile `M1/M2` çifti birlikte kullanılabilir kaynak havuzu oluşturur:

```text
pairStock[r,t] =
    min(compStock[rM1,t], compStock[rM2,t])   if rM1 in C_SEMI and rM2 in C_SEMI
    0                                        otherwise

usableSemi[r,t] =
    compStock[rM,t] + pairStock[r,t]          if rM in C_SEMI
    pairStock[r,t]                            otherwise
```

CP-SAT uygulamasında `min` ilişkisi `AddMinEquality(pairStock[r,t], [compStock[rM1,t], compStock[rM2,t]])` ile kurulabilir. Üretim `pairSemiUse[r,t]` kullandığında `rM1` ve `rM2` stoklarından aynı miktar düşer. `M1` veya `M2` kodlarından yalnız biri ana veride varsa çift kullanımı yapılamaz; ikisi de ana veride varsa fakat stok eksikse eksik taraf 2 vardiya hazırlık süresiyle tamamlanabilir.

### 8.11. Sipariş Karşılama ve Gecikme Kısıtları

Sipariş tablosundaki `Sipariş Miktarı`, planlama anında açık kalan müşteri talebidir. Bu değer üretim ihtiyacı olarak doğrudan modele yüklenmez. Veri hazırlığında aynı bitmiş ürün, sipariş türü ve termin tarihine sahip pozitif miktarlı satırlar tek sipariş satırına toplanır. Ardından başlangıç bitmiş ürün stoku aynı ürün içinde önce OEM siparişlere termin FIFO ile, sonra OYC siparişlere termin FIFO ile atanır. Başlangıç stoku ile kapanan miktar için üretim planlanmaz; stokla kapanmayan kalan açık miktar için üretim, sevkiyat, gecikme ve açık sipariş kararları değerlendirilir. Miktarı `0` olan satırlar optimizasyona alınmaz; negatif miktar veri hatasıdır. Farklı termin veya farklı sipariş türü olan satırlar `o` indeksiyle ayrı ayrı takip edilir.

Bu davranış stok dengesiyle korunur: ilk vardiyada `previousFGStock[p,t] = initialFG(p)` olduğu için `ship[o,t]` başlangıç stokundan karşılanabilir. Bir sipariş başlangıç stoku ile tamamen kapanabiliyorsa solver o sipariş için üretim yapmak zorunda değildir; üretim ancak kalan açık talep, stok hedefleri veya sonraki plan devri gibi başka geçerli gerekçeler varsa oluşur.

Bir siparişin karşılanan toplam miktarı sipariş miktarını aşamaz:

```text
sum(ship[o,t] for t in T) <= demand(o)
```

Siparişler parçalı karşılanabilir; aynı siparişin miktarı birden fazla vardiyada kapatılabilir.

Modelde `ship[o,t]`, siparişin termin karşılama kaydını temsil eder. Ürün `fgReceipt[p,t]` ile sevk edilebilir stok girişine dönüştüğü aynı vardiyada `ship[o,t]` için kullanılabilir; termin tarihinden önce oluşan `fgReceipt` siparişi erken kapatabilir. Fiziksel sevkiyat üretimi takip eden vardiyada yapılabilir; termin kontrolü için önemli olan, ilgili termin kesitinde ürünün sevk edilebilir stok girişinin oluşmuş olmasıdır.

Sipariş karşılama yalnızca ilgili bitmiş ürün stokundan yapılır:

```text
ship[o,t] contributes to fgStock[product(o),t]
```

Termin tarihi sadece gün olarak gelirse, `due(o)` ilgili günün son vardiyasıdır. Aynı günün son vardiyasında `fgReceipt` ile stokta kullanılabilir hale gelen üretim, o gün terminli sipariş için zamanında kabul edilir.

Aynı bitmiş ürün ve aynı sipariş türü içindeki siparişler termin FIFO ile kapatılır. Daha geç terminli siparişe `ship` yazılabilmesi için aynı ürün ve sipariş türündeki daha erken terminli siparişin ilgili vardiya sonunda tamamen kapanmış olması gerekir. Bunun için aynı ürün ve sipariş türüne sahip `o1`, `o2` siparişlerinde `due(o1) < due(o2)` ise şu bağlantı kullanılabilir:

Bu bölümdeki `O` sipariş kümesi yalnız pozitif miktarlı, preprocessing sonrası toplulaştırılmış siparişlerden oluşur. `demand(o) = 0` satırları bu kümeye girmeden atılır; aksi halde aşağıdaki `demand(o) - 1` sıkılaştırması sıfır talepli satırda yapay infeasible üretebilir.

```text
cumulativeShip[o,t] = sum(ship[o,k] for k <= t)

orderClosed[o1,t] = 1 if cumulativeShip[o1,t] = demand(o1)

cumulativeShip[o1,t] >= demand(o1) * orderClosed[o1,t]
cumulativeShip[o1,t] <= demand(o1) - 1 + demand(o1) * orderClosed[o1,t]
cumulativeShip[o2,t] <= demand(o2) * orderClosed[o1,t]
```

Bu kural aynı bitmiş ürün ve aynı sipariş türü için uygulanır. Ayrıca aynı bitmiş ürün için açık OEM talebi varken OYC siparişe stok atanmaz; OEM önceliği yalnız amaç fonksiyonunda değil, stok atama kısıtında da korunur:

```text
sum(ship[o2,t] for o2 in O if product(o2)=p and orderType(o2)=OYC)
<= BIG_M * allOEMClosed[p,t]

allOEMClosed[p,t] = 1 iff
    cumulativeShip[o,t] = demand(o)
    for all o in O where product(o)=p and orderType(o)=OEM
```

Uygulamada `allOEMClosed[p,t]` tek yönlü bırakılmaz. OEM sipariş kapanış bayrakları `orderClosed[o,t]` ile çift yönlü bağlanır ve ürün bazında şu mantık kurulur:

```text
allOEMClosed[p,t] <= orderClosed[o,t]
    for all o where product(o)=p and orderType(o)=OEM

allOEMClosed[p,t] >= 1 - sum(1 - orderClosed[o,t]
    for all o where product(o)=p and orderType(o)=OEM)
```

Bu sayede tüm OEM siparişleri kapandığında `allOEMClosed[p,t]` zorunlu olarak `1` olur; aksi halde `0` kalır. OYC sevk kısıtı bu kesin bayrağa dayanır ve amaç fonksiyonunun bayrağı sıkılaştırmasına güvenilmez.

Ürün `p` için hiç OEM siparişi yoksa `allOEMClosed[p,t] = 1` sabitlenir.

Termin sonrası açık miktar vardiya bazında hesaplanır:

```text
late[o,t] >= demand(o) - cumulativeShip[o,t]     for t > due(o)
late[o,t] >= 0
```

Gecikme cezası birim-vardiya gecikmedir. Bir sipariş termininden sonra 10 adet açık kalırsa ve bu açık 3 vardiya sürerse, amaç fonksiyonuna 30 birim gecikme yazılır.

Plan sonunda açık kalan sipariş miktarı ayrıca hesaplanır:

```text
openOrder[o] = demand(o) - sum(ship[o,t] for t in T)
openOrder[o] >= 0
```

### 8.12. SAG Fırın Açma Sayısı ve LSF-12 Kullanılabilirliği Kısıtları

Yakın plan vardiya SAG fırın sayısı varsa, ilgili vardiyada açılan SAG fırın sayısı hedeflenen sayıya eşit olmalıdır; ancak malzeme/talep eksikliği nedeniyle fırınların doldurulamadığı (dummy-only açılışın da yasak olduğu) durumlarda çözümsüzlüğü (infeasibility) önlemek amacıyla gevşetilebilir:

```text
sum(open[f,t] for f in F_SAG) + sagOpeningDeficit[t] = nearFurnaceReq(t)
sagOpeningDeficit[t] >= 0
```

Bu eşitlik yalnız sayıyı sabitler; hangi SAG fırınların açılacağı karar değişkenidir. Örneğin `nearFurnaceReq(t) = 3` ise model normal şartlarda tam olarak 3 SAG fırın açmak zorundadır. `sagOpeningDeficit[t]` yardımcı değişkeni amaç fonksiyonunda yüksek ceza maliyetiyle cezalandırılarak sıfıra zorlanır.

Uzak plan günlük toplam SAG fırın sayısı, yalnızca yakın plan vardiya verisi olmayan tarihlerde uygulanır ve benzer şekilde gevşetilebilir:

```text
sum(open[f,t] for f in F_SAG for t in T(d)) + sagOpeningDeficitDaily[d] = farFurnaceReq(d)
sagOpeningDeficitDaily[d] >= 0
```

Aynı tarih için hem yakın plan hem uzak plan verisi seçilen çalıştırma penceresine düşüyorsa model kurulmaz; bu durum precheck aşamasında kritik veri hatası olarak raporlanır. Plan penceresi dışında kalan tarihlerin çakışması ilgili plan çalıştırmayı bloklamaz, ancak UI veri kalite uyarısı olarak gösterebilir. Yakın planın uzak plana otomatik üstünlüğü yoktur, pencere içindeki veri açıkça tek kaynaklı olmalıdır.

Bu kısıtlar üst sınır veya alt sınır değildir; eşitlik olarak uygulanır. Verilen açılacak fırın sayısı yalnız SAG fırınlar içindir. LSF-12, arıza veya bakım olmadığı sürece ayrıca açık planlanır:

```text
open[LSF-12,t] = presAvailable(t)
```

Belirtilen sayıda SAG fırının açılması zorunludur. Bu eşitlikler ile malzeme/fırın uyumu çakışır ve üretilebilir ürün veya geçerli setup hareketi kalmazsa model gevşetilmez; SAG fırın dummy-only şekilde opsiyonel maketle açık gösterilmez. Durum ön kontrolde SAG fırın planı-veri uygunluğu çakışması olarak raporlanır.

### 8.13. Modelin Çıktıları

Model çözüldüğünde aşağıdaki çıktılar raporlanmalıdır:

Çıktılar tek bir Excel workbook olarak üretilmelidir. Python script başarılı koşuda `cikti_plan.xlsx` benzeri bir çıktı dosyası yazar; precheck veya infeasible durumda da aynı dosyada hata, neden kodu ve düzeltilmesi gereken veri satırlarını içeren sheet'ler bulunur. Operasyonel kullanımın ana çıktısı Excel workbook'tur; web arayüzü ve ayrı rapor ekranı bu aşamada kapsam dışıdır.

Kullanıcı girdi tablolarını Excel workbook içinde yönetir. Bu kapsam en az `orders`, `bom`, `stock`, `furnaces`, `products`, `sag_model_mold_capacity`, `sag_furnace_capacity`, `furnace_product_yield`, `sag_moq`, `material_arrivals`, `mandatory_dummy_models`, `near_sag_opening`, `far_sag_opening`, `initial_furnace_model_state` ve `initial_furnace_setup_carry` sheet'lerini içerir. `plan_calendar` kullanıcı girdisi değildir; sistem tarafından plan çalıştırıldığı günden başlayarak siparişlerin tamamı karşılanana kadar otomatik genişletilir. Operasyonel amaç ağırlıkları da kullanıcı girdisi değildir; sistem içinde sabit tutulur. Kullanıcı herhangi bir girdiyi değiştirdiğinde Python script tekrar çalıştırılır ve yeni çıktı Exceli ayrı dosya adıyla veya zaman damgasıyla üretilir.

Çıktı Excel workbook'unda `README` veya `Kolon_Aciklamalari` sheet'i bulunmalıdır. Bu sheet her çıktı tablosunun ne olduğunu, hangi plan kararlarını açıkladığını ve kolonların anlamını yazmalıdır. Kolon anlamları yalnız teknik dokümana bırakılmamalı; operasyonel kullanıcı çıktı dosyasını tek başına açtığında hangi sheet'e neden baktığını anlayabilmelidir.

Çıktı workbook'u yalnız teknik çözüm dökümü değil, iki kullanıcı rolüne göre okunabilir bir çıktı paketi olmalıdır:

- Saha paketi: ustabaşının vardiya başında "hangi fırında hangi iş var, kaç kalıp/maket/tur ile ne üretilecek, ilk ne yapacağım?" sorusuna cevap verir. İlk bakılacak sheet kısa iş emri listesi olmalı; her satır bir fırın-vardiya işini temsil etmeli ve aksiyon alanı numaralı, okunabilir talimat vermelidir. Teknik solver değişkenleri yerine fırın, iş emri, aksiyon, kalıp, mecburi maket, opsiyonel maket, toplam maket, tur, hedef üretim, malzeme durumu ve kritik uyarı öne çıkar. Gerçekleşen üretim, başladı/tamamlandı ve sapma nedeni gibi takip alanları bu çıktı paketinin parçası değildir.
- Planlama analiz paketi: planlama mühendisinin "planın ana riski ne, neden böyle planladı, hangi kısıt etkiledi?" sorusuna cevap verir. İlk bakılacak sheet planlama özeti olmalı; karar gerekçesi ve darboğaz detayına ilgili sheet'lerden inilmelidir. Darboğaz, neden kodu, karar gerekçesi, etki ve önerilen aksiyon açık görünür.

Çıktı Excel workbook'undaki varsayılan sheet sırası `README`, `Precheck_Hatalari`, `Planlama_Ozet`, `Saha_Is_Emri`, `Firin_Durum_Ozeti`, `Firin_Vardiya_Gantt`, `Plan_Karar_Aciklamalari` olmalıdır; teknik detay tabloları bunlardan sonra gelmelidir. `Precheck_Hatalari` yalnız hata varsa dolu olur.

Rapor çıktıları iki seviyedir. Kolon sözleşmesi sabitlenen ana çıktı tabloları `Siparis`, `Siparis_Karsilama`, `Uretim`, `Firin_Kullanim`, `SAG_Setup`, `Stok`, `Malzeme_Akisi` ve `Yarimamul_Akisi` sheet'leridir. Aşağıdaki diğer rapor adları ana tablo sözleşmesi değil; bu ana çıktılardan, solver durumundan ve precheck sonuçlarından türetilen özet/rapor sheet'leridir.

Çıktı Excel workbook'unda kullanılacak sheet ve türetilmiş rapor adları şunlardır:

- `Saha_Is_Emri`: ustabaşının ilk bakacağı kısa iş emri listesi; her satır bir fırın-vardiya işidir. Tarih/vardiya, fırın, iş emri no, model kodu/tanımı, ürün kodu/etiketi, kalıp, mecburi maket, opsiyonel maket, toplam maket, tur, tur başına adet, hedef net üretim, malzeme/yarımamul durumu, kritik uyarı ve numaralı aksiyon bulunur. Açık SAG fırında fiziksel vagon kapasitesi opsiyonel maketle doldurulduğu için "boş vagon" alanı raporlanmaz. Ürün adı ana veride yoksa `urun_etiketi` ürün kodundan türetilir.
- `Firin_Durum_Ozeti`: vardiya-fırın durumuna hızlı bakış tablosu; tarih/vardiya, fırın, vardiya durumu, ana iş, model/ürün etiketi, hedef net üretim, kalıp, mecburi maket, opsiyonel maket, toplam maket, tur, malzeme/yarımamul durumu, kritik uyarı sayısı, en kritik uyarı, ilk aksiyon ve ilgili `Saha_Is_Emri` referansı bulunur.
- `Firin_Vardiya_Gantt`: çıktı Excelinde fırın-vardiya seviyesinde kompakt zaman çizelgesidir. Satırlar fırınları, kolonlar kronolojik vardiyaları gösterir. Her hücre veya blokta tarih, vardiya, fırın, fırın tipi, iş durumu, model, ürün, önceki/yeni model, kalıp sayısı, bağlı kalıp, mecburi maket, opsiyonel maket, toplam maket, kullanılan vagon, tur sayısı, tur başına adet, hedef brüt, hedef net, setup/carry bilgisi, malzeme durumu, yarımamul durumu, kritik uyarı ve aksiyon okunabilir olmalıdır. Açık SAG bloklarında kullanılan vagon, vagon kapasitesine eşittir; kalan fiziksel yer opsiyonel maket olarak gösterilir.
- `Planlama_Ozet`: planlama mühendisinin ilk bakacağı analiz özeti; çalıştırma durumu, plan aralığı, ana risk seviyesi, ana risk özeti, toplam net üretim, OEM/OYC karşılama oranı, geciken/açık miktarlar, kritik darboğaz sayısı, malzeme/kapasite/MOQ/V710/stok aşımı riskleri, ilk 3 aksiyon ve ilgili karar referansı bulunur.
- `Plan_Karar_Aciklamalari`: planlama mühendisi için karar gerekçesi tablosu; karar tipi, kaynak kısıt, tarih/vardiya, fırın, model/ürün, sipariş, neden kodu, karar özeti, etkilenen miktar, etki, önerilen aksiyon, ilgili tablo/satır referansı ve makine okunur context bulunur.
- `Plan_Ozet`: çalıştırma durumu, plan aralığı, veri revision bilgisi, solver/objective özetleri, toplam brüt/net üretim, OEM/OYC karşılama, açık/geciken miktarlar, azami stok aşımı, setup ve ana neden kodu.
- `Firin_Yukleme_Plani`: sahada fırına ne yükleneceğini gösteren plan; fırın, segment, vagon kapasitesi, kullanılan vagon, kalıp/bağlı kalıp, mecburi/opsiyonel/toplam maket, tur, tur başına adet, brüt/net üretim ve yükleme notu. Açık SAG fırında kullanılan vagon kapasiteye eşitlenir; kalan yer varsa "boş vagon" olarak değil opsiyonel maket olarak raporlanır.
- `Kalip_Degisim_Talimati`: vardiya içinde yapılacak kalıp/model değişim talimatı; sökülecek/bağlanacak model ve kalıp, setup kaybı, devreden/tamamlanan setup, eski/yeni üretim turları, talimat ve uyarı.
- `Vardiya_Malzeme_Hazirlik`: vardiya başlamadan hazırlanması gereken malzeme ve yarımamul listesi; ihtiyaç, hazır miktar, eksik miktar, kaynak, hazırlık durumu, etkilenen fırın/iş emri ve önerilen aksiyon. Ortak kullanılan bileşenlerde ihtiyaç toplamı tüm ilgili bitmiş ürünlerden birleştirilir ve etkilenen ürün/iş emirleri birlikte gösterilir.
- `Vardiya_Uyarilari`: ustabaşının vardiya başında görmesi gereken kritik uyarılar; fırın, ürün/model, bileşen, iş emri, mesaj ve önerilen aksiyon.
- `Firin_Kullanim`: vardiya-fırın bazında açık/kapalı durum, fırın tipi, ana iş tipi, SAG tur kapasitesi, SAG vagon kapasitesi, üretim kalıbı, setup kalıbı, mecburi maket, opsiyonel maket, kullanılan vagon, Pres kapasite limiti, Pres kullanılan kapasite, setup/üretim turları, brüt/net üretim ve ilgili `Uretim` referansları. Açık SAG fırında kullanılan vagon, vagon kapasitesine eşittir; açık SAG vardiyasında setup sonrası kalan tüm tur üretim turudur.
- `Uretim`: planın ürettiği net üretim kararlarını gösterir. Bir satır; bir vardiyada, bir fırında, bir segmentte, bir bitmiş ürün için planlanan üretimi temsil eder. Yorum, neden, uyarı, sipariş bağlantısı ve malzeme detayları bu tabloda değil ilgili karar, sevkiyat ve malzeme tablolarında tutulur.
- `SAG_Setup`: SAG fırınlarda operasyon anahtarlı model/kalıp değişimi, kaynak/hedef model, vardiya başı/sonu setup carry, yeni/tamamlanan setup turu, setup-only durumu, sökülen/bağlanan kalıplar, setup öncesi/sonrası ürün kodları, ilgili `Uretim` referansları, eski/yeni model üretim turları, mecburi/opsiyonel maket ve kullanılan vagon.
- `LSF12_Sira`: LSF-12 model sırası, önceki/mevcut/sonraki model, Pres model değişimi, doğrudan V710 dışı geçiş, V710 istisnası ve kanıt siparişi, LSF-12 kullanılabilirliği, kapasite, brüt/net üretim, kampanya neti ve Pres MOQ.
- `Kampanya_Carry`: fırın-model kampanya kimliği, başlangıç/bitiş vardiyaları, plan sonunda açık kampanya, devreden başlangıç kampanya neti, plan içi kampanya neti, MOQ/Pres MOQ, MOQ sağlanma durumu ve carry-out neti.
- `Siparis`: sipariş bazında ürün/model, sipariş türü, aciliyet, termin vardiyası, sipariş miktarı, zamanında/geç karşılanan miktar, açık miktar, ilk/son karşılama zamanı, gecikme ve neden kodu.
- `Siparis_Karsilama`: siparişlerin hangi stok veya üretim kaynağıyla kapatıldığını gösteren miktar-kaynak eşleşme tablosudur. Bir sipariş birden fazla kaynaktan karşılanabilir; aynı üretim satırı da birden fazla siparişe dağıtılabilir. Fiziksel sevkiyat değil, plan içindeki sipariş karşılama kaydıdır.
- `Stok`: bitmiş ürün-vardiya bazında planın kullanabileceği vardiya başı stok, üretimden gelen net miktar, siparişe bağlanan plan içi tahsis, vardiya sonu kullanılabilir stok, azami stok ve ilgili `Uretim` / `Siparis_Karsilama` referansları. Siparişe bağlanan miktar fiziksel sevkiyat değildir.
- `Malzeme_Akisi`: satın alınan malzemeler için vardiya bazında vardiya başı stok, gelen miktar, üretim vardiyasında doğrudan düşülen kullanılan miktar, vardiya sonu stok ve ilgili `Uretim` referansları.
- `Yarimamul_Akisi`: yarımamuller için vardiya bazında vardiya başı stok, kullanılan miktar, başlatılan hazırlık, vardiya sonu stok ve ilgili `Uretim` referansları. Hazırlıktan gelen miktar ayrı kolon yapılmaz; olgunlaşan hazırlık vardiya başı stok içinde görünür.
- `Carry_Out`: plan ufku dışına taşan yarımamul hazırlığı, operasyon anahtarlı setup carry ve açık kampanya kayıtlarının tipi, hedef zamanı, kalan lead time ve miktarı. Setup carry kayıtlarında fırın, kaynak model, hedef model ve kalan setup turu birlikte yazılır. Satın alınan malzeme tüketimi üretim vardiyasında doğrudan düşüldüğü için carry-out'a plan dışı malzeme tüketimi yazılmaz.
- `Darbogazlar`: kapasite, malzeme, yarımamul, MOQ/setup, V710, SAG/LSF-12 paralel üretim ve SAG açma çakışmaları için gerekli/mevcut/eksik miktar, kaynak, ilgili sipariş/ürün/model/fırın/bileşen ve önerilen aksiyon.
- `Neden_Kodlari`: açık/geciken siparişler ve infeasible durumlar için kategori, tarih/vardiya, ürün/model/sipariş/bileşen/fırın bağlamı, miktar, mesaj ve makine okunur context.
- `Precheck_Infeasible`: ön kontrolde yakalanan kritik veri eksikleri için tablo, satır, alan, gerçek değer, beklenen kural, mesaj ve context.
- `Calistirma_Mesajlari`: plan çalıştırma sırasında oluşan bilgi, uyarı ve hata mesajlarının kronolojik listesi.

#### `Siparis_Karsilama` Kolon Sözleşmesi

`Siparis_Karsilama` tablosu, `Siparis` özet sonucunun hangi miktar-kaynak eşleşmeleriyle oluştuğunu açıklar. Bir satır, bir siparişin belirli bir miktarının belirli bir kaynakla karşılanmasını temsil eder. Bu tabloya gecikme nedeni, malzeme durumu veya darboğaz açıklaması yazılmaz; yalnız hangi miktarın hangi siparişe hangi kaynaktan ayrıldığı gösterilir.

| Kolon | Açıklama |
|---|---|
| Karşılama ID | Bu karşılama satırının benzersiz takip numarasıdır. Diğer raporlarda bu satıra referans vermek için kullanılır. |
| Sipariş ID | Karşılanan siparişin ID'sidir. `Siparis` tablosundaki `Sipariş ID` alanıyla bağ kurar. |
| Bitmiş Ürün Kodu | Karşılanan bitmiş ürün kodudur. Sipariş ve kaynak ürününün aynı ürün olduğunu kontrol etmek için görünür tutulur. |
| Sipariş Türü | Siparişin öncelik tipidir: `OEM` veya `OYC`. OEM/OYC önceliğinin raporda okunmasını sağlar. |
| Termin Tarihi | Siparişin istenen teslim tarihidir. FIFO ve zamanında karşılama kontrolünde kullanılır. |
| Karşılama Miktarı | Bu satırda ilgili siparişe ayrılan miktardır. Aynı sipariş birden fazla satırla parça parça karşılanabilir. |
| Karşılama Tarihi | Bu miktarın sipariş için kullanılabilir kabul edildiği tarihtir. Başlangıç stokundan karşılanıyorsa plan başlangıç tarihi, üretimden karşılanıyorsa ilgili üretimin stok giriş tarihi yazılır. |
| Karşılama Vardiyası | Bu miktarın sipariş için kullanılabilir kabul edildiği vardiyadır. Başlangıç stokundan karşılanıyorsa plan başlangıç vardiyası, üretimden karşılanıyorsa ilgili üretimin stok giriş vardiyası yazılır. |
| Zamanında mı? | Karşılama zamanı sipariş terminine yetişiyorsa `Evet`, termin sonrasıysa `Hayır` yazılır. |
| Kaynak Tipi | Miktarın nereden geldiğini gösterir: `Başlangıç Stoku`, `Üretim` veya `Carry-Out Devri`. |
| Kaynak ID | Kaynak `Üretim` ise `Uretim` tablosundaki `Üretim ID` yazılır. Kaynak başlangıç stokuysa `InitialStock`, carry devriyse ilgili carry kaydı yazılır. |
| Kaynak Tarihi | Kaynağın bitmiş ürün stoku olarak kullanılabilir olduğu tarihtir. Üretim kaynağında `Uretim` tablosundaki stok giriş tarihiyle aynıdır. |
| Kaynak Vardiyası | Kaynağın bitmiş ürün stoku olarak kullanılabilir olduğu vardiyadır. Üretim kaynağında `Uretim` tablosundaki stok giriş vardiyasıyla aynıdır. |
| OEM Kapısı Uygun mu? | Bu satır OYC siparişi karşılıyorsa, aynı ürünün OEM siparişleri kapanmadan OYC'ye stok ayrılmadığını gösterir. OEM satırlarında `Evet` yazılır. |
| FIFO Uygun mu? | Aynı ürün ve aynı sipariş türünde daha erken terminli siparişler kapanmadan bu siparişe miktar ayrılmadığını gösterir. |

#### `Firin_Kullanim` Kolon Sözleşmesi

`Firin_Kullanim` tablosu, üretim kararlarının fırın-vardiya seviyesindeki kapasite özetidir. Bir satır, bir fırının bir vardiyadaki açık/kapalı durumunu, ana iş tipini, SAG veya Pres kapasite kullanımını ve ilgili üretim satırlarını gösterir. Ürün bazlı üretim miktarı `Uretim` tablosunda, SAG setup ayrıntısı `SAG_Setup` tablosunda tutulur.

Açık SAG fırında fiziksel vagon kapasitesi boş bırakılmaz; üretim kalıbı, setup kalıbı, mecburi maket ve opsiyonel maket toplamı vagon kapasitesini doldurur. Açık SAG vardiyasında setup sonrası kalan tüm tur üretim turudur. Bu nedenle tabloda ayrı bir SAG kapasite artığı kolonu bulunmaz; kapasite dolumu kalıp, maket ve tur alanlarından okunur.

| Kolon | Açıklama |
|---|---|
| Tarih | Fırın kullanım durumunun geçerli olduğu takvim günüdür. |
| Vardiya | Fırın kullanım durumunun geçerli olduğu vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. Tarih/vardiya sıralamasında karışıklık olmaması için kullanılır. |
| Fırın Adı | Kullanımı raporlanan fırındır. Örneğin `LSF04`, `LSF05`, `LSF-12`. |
| Fırın Tipi | Fırının çalışma tipidir: `SAG` veya `Pres`. Bu alan hangi kapasite kolonlarının anlamlı olduğunu gösterir. |
| Fırın Durumu | Vardiyada fırının plan durumudur: `Açık` veya `Kapalı`. Kapalı fırında üretim, setup, tur ve kapasite kullanımı `0` olur. |
| Ana İş Tipi | Vardiyadaki ana işi özetler: `Üretim`, `Setup`, `Üretim + Setup` veya `Kapalı`. SAG geçiş vardiyalarında setup ve üretim aynı vardiyada birlikte görünebilir. |
| Aktif Model Sayısı | Vardiyada fırında bağlı veya üretimde kullanılan model sayısıdır. SAG fırında birden fazla olabilir; `LSF-12` için en fazla `1` olur. |
| Üretilen Ürün Sayısı | Bu fırın-vardiyada üretim planlanan farklı bitmiş ürün sayısıdır. Detay satırlar `Uretim` tablosunda bulunur. |
| Toplam Brüt Üretim | Bu fırın-vardiyada planlanan toplam brüt üretim adedidir. Aynı fırın-vardiyadaki tüm `Uretim` satırlarının brüt toplamıdır. |
| Toplam Net Üretim | Bu fırın-vardiyada beklenen toplam iyi ürün adedidir. Aynı fırın-vardiyadaki tüm `Uretim` satırlarının net toplamıdır. |
| SAG Tur Kapasitesi | SAG fırında vardiyanın toplam tur kapasitesidir. Fırın kapalıysa veya fırın tipi `Pres` ise `0` yazılır. |
| SAG Setup Turu | SAG fırında bu vardiyada setup/model değişimi için harcanan tur sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Üretim Turu | SAG fırında üretime ayrılan tur sayısıdır. Açık SAG vardiyasında `SAG Tur Kapasitesi - SAG Setup Turu` olarak okunur; Pres satırlarında `0` yazılır. |
| SAG Vagon Kapasitesi | SAG fırının vardiyadaki fiziksel vagon/kalıp alanı kapasitesidir. Pres satırlarında `0` yazılır. |
| SAG Üretim Kalıbı Sayısı | SAG fırında üretim için kullanılan kalıp sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Setup Kalıbı Sayısı | SAG fırında setup sırasında bağlanan veya sökülen kalıpların aynı vardiyada kapladığı kalıp/vagon alanıdır. Pres satırlarında `0` yazılır. |
| SAG Mecburi Maket Sayısı | Model/fırın kuralı nedeniyle zorunlu kullanılan maket sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Opsiyonel Maket Sayısı | Açık SAG fırında üretim kalıbı, setup kalıbı ve mecburi maketten sonra kalan fiziksel alanı dolduran opsiyonel maket sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Kullanılan Vagon | SAG fırında üretim kalıbı, setup kalıbı, mecburi maket ve opsiyonel maket toplamıdır. Açık SAG fırında `SAG Vagon Kapasitesi` değerine eşittir; Pres satırlarında `0` yazılır. |
| Pres Kapasite Limiti | `LSF-12` için vardiyada kullanılabilecek brüt Pres kapasitesidir. Normal vardiyada `700`, model geçiş vardiyasında `350` olur; SAG satırlarında `0` yazılır. |
| Pres Kullanılan Kapasite | `LSF-12` üzerinde bu vardiyada planlanan toplam brüt üretimdir. SAG satırlarında `0` yazılır. |
| İlgili Üretim ID'leri | Bu fırın-vardiya kullanımını oluşturan `Uretim` satırlarının ID listesidir. Aynı fırın-vardiyada birden fazla ürün veya segment varsa birden fazla ID bulunabilir. |

#### `SAG_Setup` Kolon Sözleşmesi

`SAG_Setup` tablosu, SAG fırınlarda model/kalıp değişiminin vardiya bazında nasıl ilerlediğini gösterir. Bir satır, bir SAG fırında bir vardiyada gerçekleşen tek bir operasyon anahtarlı setup hareketini veya önceki açık SAG vardiyasından devreden aynı anahtarlı setup carry tamamlamasını temsil eder. Aynı fırın-vardiyada birden fazla kaynak/hedef setup hareketi varsa her anahtar ayrı satır olarak yazılır. Pres/`LSF-12` geçişleri bu tabloda yer almaz.

Ürün bilgisi bu tabloda setup öncesi ve setup sonrası olarak özetlenir. Aynı model altında birden fazla bitmiş ürün üretilebildiği için ürün kodları liste olarak yazılır; ürün bazlı detay miktarlar `Uretim` tablosundaki üretim ID'leri üzerinden takip edilir. Üretim olmayan segmentlerde ürün ve ID alanlarına `Yok`, miktar ve tur alanlarına `0` yazılır.

| Kolon | Açıklama |
|---|---|
| Setup ID | Setup kaydının benzersiz takip numarasıdır. Diğer raporlarda bu setup satırına referans vermek için kullanılır. |
| Tarih | Setup işleminin gerçekleştiği takvim günüdür. |
| Vardiya | Setup işleminin gerçekleştiği vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Fırın Adı | Setup yapılan SAG fırındır. Pres/`LSF-12` bu tabloda yer almaz. |
| Kaynak Model Kodu | Operasyon anahtarındaki sökülecek/çıkılan modeldir. Saf bağlama varsa `Yok` yazılır. |
| Hedef Model Kodu | Operasyon anahtarındaki bağlanacak/girilen modeldir. Saf söküm varsa `Yok` yazılır. |
| Vardiya Başı Setup Carry Turu | Bu vardiyaya önceki açık SAG vardiyasından veya plan başlangıcı carry bilgisinden bu kaynak-hedef anahtarı için devreden tamamlanmamış setup turudur. Carry yoksa `0` yazılır. |
| Yeni Setup İhtiyaç Turu | Bu vardiyada aynı kaynak-hedef anahtarı için başlatılan yeni setup ihtiyacıdır. Yeni setup başlatılmıyorsa `0` yazılır. |
| Tamamlanan Setup Turu | Bu vardiyada aynı kaynak-hedef anahtarında fiilen tamamlanan setup turudur. Vardiya tur kapasitesini aşamaz. |
| Vardiya Sonu Setup Carry Turu | Bu vardiya sonunda sonraki açık SAG vardiyasına aynı kaynak-hedef anahtarıyla devreden tamamlanmamış setup turudur. Carry kalmadıysa `0` yazılır. |
| Setup Tamamlandı mı? | Vardiya sonunda ilgili kaynak-hedef setup işi tamamen bittiyse `Evet`, aynı anahtarla sonraki açık SAG vardiyasına carry devrediyorsa `Hayır` yazılır. |
| Setup Only mi? | Bu fırın-vardiyada üretim yok, yalnız setup yapıldıysa `Evet`; setup öncesi veya sonrası üretim varsa `Hayır` yazılır. |
| Sökülen Kalıp Sayısı | Kaynak modelden bu satırda tamamlanan operasyonla sökülen kalıp sayısıdır. Kaynak `Yok` ise `0` yazılır. |
| Bağlanan Kalıp Sayısı | Hedef model için bu satırda tamamlanan operasyonla bağlanan kalıp sayısıdır. Hedef `Yok` ise `0` yazılır. |
| Setup Öncesi Ürün Kodları | Setup öncesinde eski modelden üretilen bitmiş ürün kodlarıdır. Birden fazla ürün varsa liste olarak yazılır; üretim yoksa `Yok` yazılır. |
| Setup Öncesi Üretim ID'leri | Setup öncesi üretimi oluşturan `Uretim` satırlarının ID listesidir. Üretim yoksa `Yok` yazılır. |
| Setup Öncesi Brüt Üretim | Setup öncesi segmentte eski model ürünlerinden planlanan toplam brüt üretimdir. Üretim yoksa `0` yazılır. |
| Setup Öncesi Net Üretim | Setup öncesi segmentte eski model ürünlerinden beklenen toplam net üretimdir. Üretim yoksa `0` yazılır. |
| Setup Sonrası Ürün Kodları | Setup tamamlandıktan sonra yeni modelden üretilen bitmiş ürün kodlarıdır. Birden fazla ürün varsa liste olarak yazılır; üretim yoksa `Yok` yazılır. |
| Setup Sonrası Üretim ID'leri | Setup sonrası üretimi oluşturan `Uretim` satırlarının ID listesidir. Üretim yoksa `Yok` yazılır. |
| Setup Sonrası Brüt Üretim | Setup sonrası segmentte yeni model ürünlerinden planlanan toplam brüt üretimdir. Üretim yoksa `0` yazılır. |
| Setup Sonrası Net Üretim | Setup sonrası segmentte yeni model ürünlerinden beklenen toplam net üretimdir. Üretim yoksa `0` yazılır. |
| Eski Model Üretim Turu | Setup öncesinde eski modele ayrılan üretim turu sayısıdır. Eski model üretimi yoksa `0` yazılır. |
| Yeni Model Üretim Turu | Setup sonrası yeni modele ayrılan üretim turu sayısıdır. Yeni model üretimi yoksa `0` yazılır. |
| Mecburi Maket Sayısı | Bu fırın-vardiyada model/fırın kuralı nedeniyle zorunlu kullanılan maket sayısıdır. |
| Opsiyonel Maket Sayısı | Açık SAG fırında fiziksel vagon kapasitesini doldurmak için kullanılan opsiyonel maket sayısıdır. |
| Kullanılan Vagon | Bu setup kaydının bağlı olduğu fırın-vardiyada kullanılan toplam vagon alanıdır. Açık SAG fırında vagon kapasitesine eşittir. |

#### `Uretim` Kolon Sözleşmesi

`Uretim` tablosu karar açıklaması değil, üretim kararının sayısal dökümüdür. Aynı fırın-vardiyada setup öncesi ve setup sonrası üretim varsa bunlar ayrı segmentler olarak ayrı satırlarda görünür. Aynı model altında birden fazla bitmiş ürün üretiliyorsa her bitmiş ürün ayrı satır olur.

| Kolon | Açıklama |
|---|---|
| Üretim ID | Her üretim satırı için sistemin verdiği benzersiz numaradır. Diğer raporlarda bu üretim satırına referans vermek için kullanılır. |
| Tarih | Üretimin başlatıldığı takvim günüdür. Bitmiş ürün stok girişi de bu tarihte oluşur. |
| Vardiya | Üretimin başlatıldığı vardiyadır. Bitmiş ürün stok girişi de bu vardiyada oluşur. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. Tarih/vardiya sıralamasında karışıklık olmaması için kullanılır. |
| Fırın Adı | Üretimin planlandığı fırındır. Örneğin `LSF04`, `LSF05`, `LSF-12`. |
| Fırın Tipi | Fırının çalışma tipidir: `SAG` veya `Pres`. Bu alan hangi kapasite kurallarının uygulandığını gösterir. |
| Segment No | Aynı fırın-vardiya içinde birden fazla üretim parçası varsa sırasını gösterir. Setup olmayan normal vardiyada genelde `1` olur. |
| Segment Tipi | Üretimin vardiya içindeki yerini gösterir: `Normal`, `Setup Öncesi`, `Setup Sonrası`, `Pres Normal`, `Pres Geçiş`. SAG geçiş vardiyalarında eski model üretimi ve yeni model üretimi ayrı segmentlerde görünebilir. |
| Kampanya ID | Üretimin yazıldığı fırın-model kampanyasının takip numarasıdır. MOQ sayacı, açık kampanya ve carry-out takibi bu kimlik üzerinden bağlanır. |
| Model Kodu | Üretilen bitmiş ürünün bağlı olduğu modeldir. Kampanya, MOQ, kalıp ve model değişimi kuralları bu model üzerinden takip edilir. |
| Bitmiş Ürün Kodu | Üretilen nihai ürün kodudur. Sipariş kapama ve bitmiş ürün stok girişi bu kod üzerinden yapılır. |
| Brüt Üretim Adedi | Randıman uygulanmadan önce planlanan üretim adedidir. Fırının kapasite kullanımı bu miktar üzerinden okunur. |
| Randıman | İlgili fırın-ürün eşleşmesi için kullanılan iyi ürün oranıdır. `furnace_product_yield` tablosundan gelir. |
| Net Üretim Adedi | Randıman sonrası beklenen iyi ürün adedidir. Bitmiş ürün stokuna giren ve sipariş kapamada kullanılabilen miktar budur. |
| Stok Giriş Tarihi | Net üretimin bitmiş ürün stokunda kullanılabilir olduğu tarihtir. Bu sistemde üretim tarihiyle aynıdır. |
| Stok Giriş Vardiyası | Net üretimin bitmiş ürün stokunda kullanılabilir olduğu vardiyadır. Bu sistemde üretim vardiyasıyla aynıdır. |
| SAG Kalıp Sayısı | SAG fırında bu ürün için kullanılan üretim kalıbı sayısıdır. Pres/`LSF-12` satırlarında `0` yazılır. |
| SAG Üretim Tur Sayısı | SAG fırında bu ürün için üretime ayrılan tur sayısıdır. Pres/`LSF-12` satırlarında `0` yazılır. |
| Pres Kapasite Limiti | `LSF-12` satırında kullanılan brüt kapasite limitidir. Normal Pres üretiminde `700`, model geçiş vardiyasında `350` olur. SAG satırlarında `0` yazılır. |
| Satın Alınan Malzeme Var mı? | Ürünün BOM'unda `Bileşen Malzeme Türü = Malzeme` satırı olup olmadığını gösterir. `Evet` ise satın alınan malzeme tüketimi ayrıca malzeme tablosunda takip edilir. |
| Malzeme Kullanım Tarihi | Satın alınan malzeme tüketiminin yazıldığı tarihtir. Malzeme düşümü üretimle aynı vardiyada yapıldığı için satın alınan malzemesi olan üründe üretim tarihiyle aynıdır; üründe satın alınan malzeme yoksa `Yok` yazılır. |
| Malzeme Kullanım Vardiyası | Satın alınan malzeme tüketiminin yazıldığı vardiyadır. Malzeme düşümü üretimle aynı vardiyada yapıldığı için satın alınan malzemesi olan üründe üretim vardiyasıyla aynıdır; üründe satın alınan malzeme yoksa `Yok` yazılır. |

#### `Stok` Kolon Sözleşmesi

`Stok` tablosu, bitmiş ürün stokunun plan açısından vardiya bazında nasıl değiştiğini gösterir. Bu tablo gerçek sevkiyat veya ERP stok hareketi iddiası taşımaz; planın kullanabileceği stok, üretimden gelen miktar ve siparişe bağlanan miktar ayrımını gösterir.

`Siparişe Bağlanan` fiziksel sevkiyat değildir. Bu alan, planın aynı miktarı başka sipariş için tekrar kullanmaması adına kullanılabilir stoktan düşülen tahsistir. Gerçek sevkiyat tarihi ayrıca takip edilecekse ayrı bir operasyon/ERP tablosu gerekir.

| Kolon | Açıklama |
|---|---|
| Tarih | Stok durumunun raporlandığı takvim günüdür. |
| Vardiya | Stok durumunun raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Bitmiş Ürün Kodu | Stok durumu izlenen bitmiş ürün kodudur. |
| Model Kodu | Bitmiş ürünün bağlı olduğu modeldir. `products` tablosundan gelir. |
| Vardiya Başı Stok | Bu vardiya başında planın kullanabildiği bitmiş ürün miktarıdır. |
| Üretimden Gelen | Bu vardiyada üretimden bitmiş ürün stokuna giren net miktardır. |
| Siparişe Bağlanan | Bu vardiyada sipariş karşılama planına bağlanan miktardır. Fiziksel sevkiyat anlamına gelmez. |
| Vardiya Sonu Kullanılabilir Stok | Plan açısından sonraki vardiyalarda kullanılabilecek kalan stoktur. |
| Azami Stok Miktarı | `products` tablosundaki ürün bazlı stok referans sınırıdır. Üretim yasağı değildir. |
| Azami Stok Aşımı | Vardiya sonu kullanılabilir stok azami stok miktarını aşıyorsa aşan miktardır; aşmıyorsa `0` yazılır. |
| İlgili Üretim ID'leri | Bu vardiyadaki üretim girişlerini oluşturan `Uretim` ID listesidir. Üretim yoksa `Yok` yazılır. |
| İlgili Karşılama ID'leri | Bu vardiyada stoktan veya üretimden siparişe bağlanan `Siparis_Karsilama` ID listesidir. Tahsis yoksa `Yok` yazılır. |

#### `Malzeme_Akisi` Kolon Sözleşmesi

`Malzeme_Akisi` tablosu yalnız satın alınan malzemeler içindir. Bir satır, bir malzemenin bir vardiyadaki stok akışını gösterir. Malzeme tüketimi üretimle aynı vardiyada stoktan düşülür; bu tabloda `t+3`, gecikmeli tüketim veya plan dışı malzeme tüketim kolonu bulunmaz.

| Kolon | Açıklama |
|---|---|
| Tarih | Malzeme akışının raporlandığı takvim günüdür. |
| Vardiya | Malzeme akışının raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Malzeme Kodu | Satın alınan malzeme kodudur. `bom` ve `stock` tablolarındaki malzeme koduyla aynı olmalıdır. |
| Vardiya Başı Stok | Vardiya başında kullanılabilir olan malzeme miktarıdır. |
| Gelen Miktar | Bu vardiyada `material_arrivals` üzerinden kullanılabilir hale gelen malzeme miktarıdır. Teslimat yoksa `0` yazılır. |
| Kullanılan Miktar | Bu vardiyada başlatılan üretimler için aynı vardiyada stoktan düşülen malzeme miktarıdır. Kullanım yoksa `0` yazılır. |
| Vardiya Sonu Stok | Gelen miktar ve kullanılan miktar sonrası kalan malzeme stokudur. Negatif olamaz. |
| İlgili Üretim ID'leri | Kullanılan miktarı oluşturan `Uretim` satırlarının ID listesidir. Kullanım yoksa `Yok` yazılır. |

#### `Yarimamul_Akisi` Kolon Sözleşmesi

`Yarimamul_Akisi` tablosu yalnız yarımamuller içindir. Bir satır, bir yarımamulün bir vardiyadaki stok akışını gösterir. Yarımamul hazırlığı 2 vardiya sonra kullanılabilir hale gelir, ancak bu tabloda hazırlıktan gelen miktar ayrı kolon olarak gösterilmez; olgunlaşan hazırlık vardiya başı stok içinde görünür.

| Kolon | Açıklama |
|---|---|
| Tarih | Yarımamul akışının raporlandığı takvim günüdür. |
| Vardiya | Yarımamul akışının raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Yarımamul Kodu | Yarımamul kodudur. `bom` ve `stock` tablolarındaki yarımamul koduyla aynı olmalıdır. |
| Vardiya Başı Stok | Vardiya başında kullanılabilir olan yarımamul miktarıdır. Önceki vardiyalarda başlatılıp bu vardiyada olgunlaşan hazırlık varsa bu stok içinde görünür. |
| Kullanılan Miktar | Bu vardiyada başlatılan üretimler için stoktan düşülen yarımamul miktarıdır. Kullanım yoksa `0` yazılır. |
| Hazırlık Başlatılan Miktar | Bu vardiyada başlatılan yeni yarımamul hazırlığıdır. Bu miktar aynı vardiyada kullanılabilir stok sayılmaz; 2 vardiya sonra stokta görünür. |
| Vardiya Sonu Stok | Kullanım sonrası kalan kullanılabilir yarımamul stokudur. Negatif olamaz. |
| İlgili Üretim ID'leri | Kullanılan miktarı oluşturan `Uretim` satırlarının ID listesidir. Kullanım yoksa `Yok` yazılır. |

### 8.14. Uygulama Notları

- CP-SAT modelinde tüm miktar değişkenleri tamsayı üst sınırlarla tanımlanmalıdır.
- Model kurulmadan önce ön kontrol yapılmalıdır: ilk plan koşusunda `Başlangıç Fırın Model Durumu` Excel workbook içindeki yalnız başlangıçta bağlı olan fırın-model satırlarını içerir; başlangıçta boş fırın için satır yazılmaz. Sonraki rolling koşularda aynı bilgiler önceki `carry_out` paketinden devralınır. SAG fırınlarda aynı fırın için birden fazla başlangıç model satırı olabilir; başlangıç bağlı model sayısı `modelCap(f)` değerini aşmamalı, aynı model iki farklı SAG fırında başlangıç bağlı modeli olarak görünmemeli, `initialMolds(f,m)` pozitif olan her model için `initialBoundModel(f,m) = 1` olmalı, bağlı kalıp toplamı `moldCap(m)` değerini aşmamalı, `initial_furnace_setup_carry` tablosunda fırın-kaynak-hedef anahtarı tekil olmalı, kalan setup carry turu negatif olmamalı, Pres/LSF-12 satırı bulunmamalı, kaynak ve hedef aynı model olmamalı, iki taraf birden `Yok` olmamalı ve yazılan modeller ana veride tanımlı olmalı, `Başlangıç Kampanya Net Üretim Miktarı` negatif olmamalı, kampanya neti yalnız başlangıçta bağlı fırın-model satırında bulunmalı, mecburi maket ile başlangıç kalıpları vagon kapasitesine sığmalı ve LSF-12 için en fazla bir başlangıç modeli bulunmalıdır. Girdi workbook'undaki tüm bitmiş ürün kodları `products` tablosunda tekil ürün kartına ve en az bir geçerli `Fırın Ürün Randıman` satırına sahip olmalı; fırın-ürün-randıman satırı, ürün ağacında en az bir yarımamulün tanımlanmış olması (malzemenin ise hiç olmayabilmesi veya birden fazla olabilmesi), BOM'daki malzeme/yarımamul stok kayıtları, SAG tarafında üretilebilir modeller için `sag_moq` kayıtları, siparişler kapanana kadar genişleyen plan ufku için gereken SAG fırın açma sayısı ve V710 üretilebilirliği eksikse model çalıştırılmaz, kullanıcıdan veri tamamlaması istenir. Aynı malzeme veya yarımamulün birden fazla bitmiş ürünün BOM'unda bulunması precheck hatası değildir; stok kaydı bileşen kodu bazında tek havuz olarak doğrulanır.
- Zorunlu SAG fırın açma sayısı ile malzeme/talep uygunluğu çakışıyorsa ve dummy-only açılış yasağı nedeniyle fırınlar açılamıyorsa, model çözümsüz kalmak yerine açılış sayısı hedefini `sagOpeningDeficit[t]` gevşeme değişkeniyle otomatik olarak düşürür. Bu açık, amaç fonksiyonunda yüksek ceza maliyetiyle cezalandırılır ve planlama özetinde kapasite/malzeme darboğazı olarak raporlanır.
- LSF-12 arıza veya bakım yoksa açık planlanır. Ancak açık Pres vardiyasında aktif olan model ve geçiş alternatifi olan V710 modeli için gerekli bileşen malzeme/yarımamul eksikliği varsa, kapasite kuralı `presSlack[t]` gevşeme değişkeniyle otomatik esnetilir. LSF-12 bu durumlarda kapasite düşürebilir veya tamamen boş (idle) kalabilir. Bu eksiklik amaç fonksiyonunda yüksek maliyetle cezalandırılır ve darboğaz raporunda `LSF12_MATERIAL_BLOCKED` koduyla gösterilir.
- LSF-12 için V710 üretilebilirliği veri hazırlığında sağlanmış kabul edilir. V710 geçiş kuralı yalnız sistem tarafından `urgent(o) = 1` olarak türetilen ilgili siparişin gerektirdiği ve termin yetiştirme kanıtı bulunan geçişte istisna olarak gevşetilebilir; veri eksikliği veya operasyonel maliyet tercihi muafiyet nedeni değildir.
- Ön kontroller geçtikten sonra CP-SAT `INFEASIBLE` dönerse sonuç generic hata olarak bırakılmaz; sert kısıt çakışması adaylarını içeren yapılandırılmış "no feasible plan" raporu üretilir.
- `gross`, `net`, `ship`, `fgStock`, `compStock` ve benzeri değişkenlerin üst sınırları veri ön işleme aşamasında hesaplanmalıdır.
- Üretim uyumu olmayan fırın-ürün çiftleri için değişken oluşturulmaması model boyutunu küçültür.
- Operasyonel amaç ağırlıkları kullanıcı girdisi değildir; uygulamada sabit iç değerler olarak tutulmalı ve raporlanabilir alt kalemler opsiyonel maket, stok, setup/model değişimi ve kampanya kırılımında ayrı gösterilmelidir.
- Kampanya/MOQ kısıtları fırın-model bazlı rolling sayaçla kurulmalıdır. Kampanya aralığı değişkenleri ana fizibilite modelinin parçası değildir; başlangıç/bitiş bilgisi raporlama için `campStart`, `campEnd` ve bağlılık değişimlerinden türetilir.
- SAG üretiminde geçiş olmayan basit vardiyalar için `molds * usableTurns` çarpımı kullanılabilir. Geçiş vardiyalarında kapasite çift sayımını engellemek için `oldGross = oldSegmentMolds * oldProdTurns` ve `newGross = newSegmentMolds * newProdTurns` segment çarpımları kurulmalıdır. CP-SAT içinde bu çarpımlar `AddMultiplicationEquality` ile veya olası kalıp-tur kombinasyonları önceden listelenip tablo kısıtıyla kurulabilir.
- LSF-12 V710 geçiş kuralı için automaton yaklaşımı daha temizdir; kampanya sayaçları ile `campStart`/`campEnd` kayıtları ise raporlama ve sistem tarafından riskli bulunan ilgili sipariş istisnasını açıklamak açısından izlenebilirliği sağlar.
- Kanonik veri bu dokümanda oluşturulmaz; ancak uygulama sırasında siparişler kapanana kadar genişleyen kanonik plan koşusunda şu davranışlar ayrıca kontrol edilmelidir: LSF-12 kullanılabilirken kapasitenin tam doldurulması ve idle bırakılmaması, SAG bağlı modelin üretim zorunluluğu, söküm vardiyasında eski modele ait gecikmiş veya ileri vadeli açık sipariş kalırsa `unbound_slack` / `unbound_open_order_slack` cezasının oluşması ve kapasite varsa modelde kalmanın tercih edilmesi, MOQ tamamlanmadan model sökülememesi ve plan sonunda açık kampanyanın `carry_out` paketine devredilmesi, SAG-only yeterlilik kanıtlanamayan üründe SAG/LSF-12 paralel kapısının açılması, kalıp değişiminin vardiya tur kapasitesini aşınca `setupCarry[f,a,b,t]` ile kaynak-hedef anahtarı korunarak sonraki açık SAG vardiyasında önce tamamlanması, başlangıç setup carry bilgisinin `initial_furnace_setup_carry` tablosundan operasyon anahtarlı okunması, dummy-only SAG açılışının ön kontrol hatası olması, kapalı fırında kalıp kapasitesi tüketimi, V710 carry tamamlanmadan geçiş yasağı ve sistem tarafından riskli bulunan ilgili sipariş istisnası, net bazlı BOM tüketimi, ortak malzeme/yarımamul tüketiminin ürünler arasında tek stok havuzunda toplanması, satın alınan malzeme tüketiminin üretim vardiyasında doğrudan stoktan düşülmesi, bitmiş ürün stok girişinin üretim vardiyasında hemen oluşması, önce OEM sonra OYC olacak ve her grupta termin FIFO uygulanacak stok atama, sıfır siparişin yoksayılması, ilk koşunun manuel Excel `Başlangıç Fırın Model Durumu` ve `Başlangıç Fırın Setup Carry` tablolarından, sonraki koşunun ise `carry_out` paketinden başlaması, yapılandırılmış infeasible raporu.
- Veri dosyaları henüz oluşturulmadığı için bu doküman, Python koduna geçmeden önce kullanılacak matematiksel model sözleşmesi olarak kabul edilmelidir.

### 8.15. Kullanım Senaryosu

Planlamacı gün başında veya plan revizyonu gerektiğinde girdi Excel workbook'unu açar. Excel içinde yeni siparişleri, sipariş güncellemelerini, stok düzeltmelerini, ürün ağacı değişikliklerini, ürün-master kayıtlarını, fırın/kalıp/randıman verilerini, `sag_moq` satırlarını, SAG açılış sayılarını ve yoldaki malzeme teslimatlarını günceller. İlk kurulum veya bilinçli reset dışında planlamacı başlangıç fırın durumunu elle yönetmez.

Planlamacı proje klasöründeki Python giriş scriptini çalıştırır. Standart kullanım `python run_plan.py --input girdi.xlsx --output cikti_plan.xlsx` komutudur; bunun için ayrıca çift tıklanabilir bir `.bat` dosyası da hazırlanabilir. `run_plan.py` komutu uygulamayı başlatır, fakat okuma/doğrulama/model/çıktı işleri arka tarafta ayrı modüller tarafından yapılır. Script önce veri ön kontrolünü yapar. Eksik zorunlu worksheet/kolon, BOM'da yarımamulü olmayan bitmiş ürün, stok kaydı olmayan malzeme/yarımamul, eksik SAG MOQ satırı, genişleyen plan ufkunda çakışan veya eksik SAG açılış tarihi, geçersiz Pres/LSF-12 tanımı, hatalı başlangıç fırın durumu veya V710 kuralını bozan veri varsa optimizasyon kurulmaz. Kullanıcı hangi tablo, satır, alan ve kuralın düzeltilmesi gerektiğini çıktı Excelindeki `Precheck_Hatalari` sheet'inde görür; hatayı girdi Excelinde düzeltip scripti tekrar çalıştırır.

Ön kontroller geçerse plan otomatik üretilir ve çıktı Excel workbook'u yazılır. Planlamacı ilk olarak `Planlama_Ozet` sheet'ine bakar: zamanında kapanan OEM/OYC miktarı, geciken veya açık kalan siparişler, ana darboğazlar, kritik malzeme/yarımamul uyarıları ve kapasite uyarıları burada özetlenir. Siparişler veri veya sert kapasite kısıtları nedeniyle hiçbir ufukta tamamen kapanamıyorsa sistem açık kalan miktarı neden koduyla çıktı Exceline yazar.

Sonra planlamacı detay sheet'lere iner. `Siparis` ve `Siparis_Karsilama` ile hangi siparişin stoktan, üretimden veya açık kaldığını kontrol eder. `Uretim`, `Firin_Kullanim` ve `SAG_Setup` ile vardiya bazlı üretim ve fırın planını inceler. `Stok`, `Malzeme_Akisi` ve `Yarimamul_Akisi` ile planın stok, satın alınan malzeme ve yarımamul tarafında uygulanabilir olup olmadığını doğrular. Geciken veya açık kalan bir siparişte neden kodunu okuyarak malzeme, yarımamul, kapasite, MOQ, V710/LSF-12 veya SAG açılış etkisini görür.

Saha kullanıcısı ana tablo detaylarına girmek zorunda değildir. Ustabaşı çıktı Excelindeki `Saha_Is_Emri`, `Firin_Durum_Ozeti` ve ilgili vardiya sheet'lerinden vardiya bazında fırın, model, ürün, kalıp, tur, setup, mecburi/opsiyonel maket, malzeme-yarımamul hazırlığı ve kritik uyarıları görür. Bu sheet'ler yapılacak işi gösterir; planlama sheet'leri ise kararın nedenini ve hangi kısıtın etkili olduğunu açıklar.

Gün içinde sipariş, stok veya teslimat bilgisi değişirse planlamacı girdi Excelini günceller ve scripti tekrar çalıştırır. Yeni çıktı dosyası farklı dosya adıyla veya zaman damgasıyla üretilir; böylece eski plan sessizce ezilmez. Yeni plan üretildikten sonra planlamacı `Planlama_Ozet` ve kritik uyarı sheet'lerini kontrol ederek hangi planın sahaya verileceğine karar verir.
