from __future__ import annotations

from datetime import date

import pandas as pd
from openpyxl import load_workbook
from ortools.sat.python import cp_model

from otocam.calendar import build_calendar
from otocam.carry import apply_carry_out
from otocam.cli import main
from otocam.io import read_input_workbook
from otocam.output import write_plan_result, write_tables
from otocam.planner import _CpSatPlanBuilder, _infeasible_tables, solve_plan
from otocam.preprocess import estimate_planning_days, prepare_data
from otocam.sample_data import create_sample_workbook
from otocam.schemas import PlanOptions
from otocam.selftest import run_self_test
from otocam.specs import PRECHECK_COLUMNS, SCALE, SHEET_SPEC_BY_NAME
from otocam.validation import validate_workbook


def _replace_sheet_rows(wb, sheet_name: str, rows: list[list]) -> None:
    ws = wb[sheet_name]
    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)
    for row in rows:
        ws.append(row)


def _stock_quantity(stock: pd.DataFrame, code: str, stock_type: str):
    rows = stock[(stock["Kod"] == code) & (stock["Stok Türü"] == stock_type)]
    assert len(rows) == 1
    return rows.iloc[0]["Stok Miktarı"]


class _ZeroSolver:
    def Value(self, value):
        return int(value)


def _warning_builder(plan_start: date, days: int = 30):
    builder = _CpSatPlanBuilder.__new__(_CpSatPlanBuilder)
    builder.shifts = build_calendar(plan_start, days)
    builder.sag_open_deficit = {}
    builder.sag_daily_deficit = {}
    builder.pres_change = {shift.index: 0 for shift in builder.shifts}
    builder.active_pres = {}
    builder.gross = {}
    builder.product_model = {}
    return builder


def _warning_order_row(
    *,
    order_id: str,
    due_date,
    open_qty: int = 0,
    late_qty: int = 0,
) -> dict:
    return {
        "Sipariş ID": order_id,
        "Bitmiş Ürün Kodu": "FG_TEST",
        "Model Kodu": "TEST_MODEL",
        "Termin Tarihi": due_date.isoformat(),
        "Açık Miktar": open_qty,
        "Geç Karşılanan": late_qty,
    }


def _prepared_sample(input_path, plan_start: date, options: PlanOptions | None = None):
    workbook = read_input_workbook(input_path)
    shifts = build_calendar(plan_start, estimate_planning_days(workbook, plan_start, 30))
    options = options or PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []
    return prepare_data(workbook, options, shifts), options


def test_order_warnings_distinguish_open_late_and_horizon_messages():
    plan_start = date(2026, 6, 21)
    builder = _warning_builder(plan_start)
    rows = builder._warning_rows(
        _ZeroSolver(),
        [
            _warning_order_row(
                order_id="SIP_OPEN_NEAR",
                due_date=plan_start + pd.Timedelta(days=5),
                open_qty=25,
            ),
            _warning_order_row(
                order_id="SIP_LATE_CLOSED",
                due_date=plan_start + pd.Timedelta(days=5),
                late_qty=10,
            ),
            _warning_order_row(
                order_id="SIP_OPEN_BEYOND",
                due_date=plan_start + pd.Timedelta(days=35),
                open_qty=40,
            ),
        ],
    )

    near_open = next(row for row in rows if "SIP_OPEN_NEAR" in row["Mesaj"])
    assert near_open["Neden Kodu"] == "OPEN_DEMAND"
    assert "açık kaldı" in near_open["Mesaj"]
    assert "plan ufkuna sığmadı" not in near_open["Mesaj"]
    assert "--max-days" not in near_open["Önerilen Aksiyon"]

    late_closed = next(row for row in rows if "SIP_LATE_CLOSED" in row["Mesaj"])
    assert late_closed["Neden Kodu"] == "LATE_CAPACITY"
    assert "termininden sonra karşılandı" in late_closed["Mesaj"]

    beyond_open = next(row for row in rows if "SIP_OPEN_BEYOND" in row["Mesaj"])
    assert beyond_open["Neden Kodu"] == "OPEN_DEMAND"
    assert "plan ufkuna sığmadı" in beyond_open["Mesaj"]
    assert "--max-days" in beyond_open["Önerilen Aksiyon"]


def test_sample_workbook_solves_end_to_end(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sample_input.xlsx"
    create_sample_workbook(input_path, plan_start)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=15, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    builder = _CpSatPlanBuilder(prepared, options)
    assert not builder._sag_pres_parallel_allowed("FG_CHEVY_EXP", 0)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    assert not result.tables["Uretim"].empty
    assert int(result.tables["Siparis"]["Açık Miktar"].sum()) == 0

    output_path = tmp_path / "sample_output.xlsx"
    write_plan_result(output_path, result)
    output_wb = load_workbook(output_path, read_only=True)
    assert output_wb.sheetnames[:4] == [
        "README",
        "Precheck_Hatalari",
        "Planlama_Ozet",
        "Saha_Is_Emri",
    ]
    output_wb.close()
    precheck = pd.read_excel(output_path, sheet_name="Precheck_Hatalari")
    assert precheck.empty
    assert list(precheck.columns) == list(PRECHECK_COLUMNS)

    carry_out = pd.read_excel(output_path, sheet_name="Carry_Out")
    pres_state = carry_out[
        (carry_out["Kayıt Tipi"] == "Fırın Model Durumu")
        & (carry_out["Fırın"] == "LSF-12")
    ]
    assert len(pres_state) == 1

    seeded = apply_carry_out(read_input_workbook(input_path), output_path)
    carry_issues = validate_workbook(seeded, options, shifts)
    assert carry_issues == []


def test_stress_synthetic_workbook_validates(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "stress_input.xlsx"
    create_sample_workbook(input_path, plan_start, scenario="stress")

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=5, workers=8)
    issues = validate_workbook(workbook, options, shifts)

    assert issues == []


def test_self_test_runs_base_scenario_and_writes_report(tmp_path):
    plan_start = date(2026, 6, 21)
    result = run_self_test(
        tmp_path / "selftest",
        plan_start=plan_start,
        scenarios=("base",),
        time_limit=20,
        workers=8,
    )

    assert result.passed
    assert result.report_path.exists()
    summary = pd.read_excel(result.report_path, sheet_name="Self_Test_Ozet")
    failures = pd.read_excel(result.report_path, sheet_name="Self_Test_Hatalari")
    assert set(summary["Koşu"]) == {"ilk_plan", "rolling_carry_out"}
    assert set(summary["Başarılı mı?"]) == {"Evet"}
    assert failures.empty


def test_cli_writes_precheck_errors_for_missing_sheet(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "bad_input.xlsx"
    output_path = tmp_path / "bad_output.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    del wb["stock"]
    wb.save(input_path)

    exit_code = main(
        [
            "--input",
            str(input_path),
            "--output",
            str(output_path),
            "--plan-start",
            plan_start.isoformat(),
        ]
    )

    assert exit_code == 2
    output_wb = load_workbook(output_path, read_only=True)
    assert output_wb.sheetnames[:3] == ["README", "Precheck_Hatalari", "Planlama_Ozet"]
    output_wb.close()
    errors = pd.read_excel(output_path, sheet_name="Precheck_Hatalari")
    assert "stock" in set(errors["Tablo"])
    assert "REQUIRED_SHEET" in set(errors["Kural"])


def test_apply_carry_out_seeds_initial_state_and_stock(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sample_input.xlsx"
    carry_out_path = tmp_path / "carry_output.xlsx"
    create_sample_workbook(input_path, plan_start)

    carry_out = pd.DataFrame(
        [
            {
                "Kayıt Tipi": "Fırın Model Durumu",
                "Kod": "V363_LOW",
                "Fırın": "LSF05",
                "Kaynak Model": "",
                "Hedef Model": "V363_LOW",
                "Kalan Lead Time/Tur": "",
                "Miktar": 725,
                "Bağlı Kalıp Sayısı": 4,
                "Carry-Out Kampanya Neti": 725,
                "Açıklama": "",
            },
            {
                "Kayıt Tipi": "Setup Carry",
                "Kod": "V363_LOW->JEEP_AVG",
                "Fırın": "LSF05",
                "Kaynak Model": "V363_LOW",
                "Hedef Model": "JEEP_AVG",
                "Kalan Lead Time/Tur": 3,
                "Miktar": 3,
                "Bağlı Kalıp Sayısı": "",
                "Carry-Out Kampanya Neti": "",
                "Açıklama": "",
            },
            {
                "Kayıt Tipi": "Bitmiş Ürün Stok",
                "Kod": "FG_V710_A",
                "Fırın": "",
                "Kaynak Model": "",
                "Hedef Model": "",
                "Kalan Lead Time/Tur": "",
                "Miktar": 12,
                "Bağlı Kalıp Sayısı": "",
                "Carry-Out Kampanya Neti": "",
                "Açıklama": "",
            },
            {
                "Kayıt Tipi": "Malzeme Stok",
                "Kod": "COMP_SENSOR",
                "Fırın": "",
                "Kaynak Model": "",
                "Hedef Model": "",
                "Kalan Lead Time/Tur": "",
                "Miktar": 55.5,
                "Bağlı Kalıp Sayısı": "",
                "Carry-Out Kampanya Neti": "",
                "Açıklama": "",
            },
            {
                "Kayıt Tipi": "Yarımamul Stok",
                "Kod": "SEMI_FORD_M",
                "Fırın": "",
                "Kaynak Model": "",
                "Hedef Model": "",
                "Kalan Lead Time/Tur": "",
                "Miktar": 22,
                "Bağlı Kalıp Sayısı": "",
                "Carry-Out Kampanya Neti": "",
                "Açıklama": "",
            },
            {
                "Kayıt Tipi": "Yarımamul Hazırlık",
                "Kod": "SEMI_FORD_M",
                "Fırın": "",
                "Kaynak Model": "",
                "Hedef Model": "",
                "Kalan Lead Time/Tur": 2,
                "Miktar": 10,
                "Bağlı Kalıp Sayısı": "",
                "Carry-Out Kampanya Neti": "",
                "Açıklama": "",
            },
        ]
    )
    write_tables(carry_out_path, {"Carry_Out": carry_out})

    workbook = read_input_workbook(input_path)
    seeded = apply_carry_out(workbook, carry_out_path)

    model_state = seeded.sheets["initial_furnace_model_state"]
    assert list(model_state.columns) == list(SHEET_SPEC_BY_NAME["initial_furnace_model_state"].columns)
    assert model_state.to_dict("records") == [
        {
            "Fırın Adı": "LSF05",
            "Model Kodu": "V363_LOW",
            "Bağlı Kalıp Sayısı": 4,
            "Başlangıç Kampanya Net Üretim Miktarı": 725,
        }
    ]

    setup_carry = seeded.sheets["initial_furnace_setup_carry"]
    assert setup_carry.to_dict("records") == [
        {
            "Fırın Adı": "LSF05",
            "Kaynak Model Kodu": "V363_LOW",
            "Hedef Model Kodu": "JEEP_AVG",
            "Kalan Setup Carry Turu": 3,
        }
    ]

    stock = seeded.sheets["stock"]
    assert _stock_quantity(stock, "FG_V710_A", "Bitmiş Ürün") == 12
    assert _stock_quantity(stock, "FG_V710_B", "Bitmiş Ürün") == 0
    assert _stock_quantity(stock, "COMP_SENSOR", "Malzeme") == 55.5
    assert _stock_quantity(stock, "COMP_PVB_CLEAR", "Malzeme") == 0
    assert _stock_quantity(stock, "SEMI_FORD_M", "Yarımamul") == 22
    assert seeded.pending_semi_prep_scaled[("SEMI_FORD_M", 2)] == 10 * SCALE


def test_cli_applies_carry_out_before_validation(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sample_input.xlsx"
    carry_out_path = tmp_path / "bad_carry_output.xlsx"
    output_path = tmp_path / "bad_carry_result.xlsx"
    create_sample_workbook(input_path, plan_start)

    carry_out = pd.DataFrame(
        [
            {
                "Kayıt Tipi": "Fırın Model Durumu",
                "Kod": "CHEVY_EXP",
                "Fırın": "LSF05",
                "Kaynak Model": "",
                "Hedef Model": "CHEVY_EXP",
                "Kalan Lead Time/Tur": "",
                "Miktar": 100,
                "Bağlı Kalıp Sayısı": 2,
                "Carry-Out Kampanya Neti": 100,
                "Açıklama": "",
            }
        ]
    )
    write_tables(carry_out_path, {"Carry_Out": carry_out})

    exit_code = main(
        [
            "--input",
            str(input_path),
            "--carry-out",
            str(carry_out_path),
            "--output",
            str(output_path),
            "--plan-start",
            plan_start.isoformat(),
        ]
    )

    assert exit_code == 2
    errors = pd.read_excel(output_path, sheet_name="Precheck_Hatalari")
    assert "INITIAL_MODEL_COMPATIBLE_WITH_FURNACE" in set(errors["Kural"])


def test_infeasible_output_includes_readme_and_structured_sheet(tmp_path):
    output_path = tmp_path / "infeasible_output.xlsx"
    write_tables(output_path, _infeasible_tables("INFEASIBLE"))

    output_wb = load_workbook(output_path, read_only=True)
    assert output_wb.sheetnames[:3] == ["README", "Precheck_Hatalari", "Planlama_Ozet"]
    assert "Precheck_Infeasible" in output_wb.sheetnames
    output_wb.close()

    readme = pd.read_excel(output_path, sheet_name="README")
    assert readme.iloc[0, 1] == "INFEASIBLE"
    infeasible = pd.read_excel(output_path, sheet_name="Precheck_Infeasible")
    assert set(infeasible["Neden Kodu"]) == {"CP_SAT_INFEASIBLE"}


def test_v710_sag_yield_is_rejected(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "bad_v710.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    ws = wb["furnace_product_yield"]
    ws.append(["LSF04", "FG_V710_A", 0.95])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)

    assert any(issue.rule == "V710_ONLY_LSF12" for issue in issues)


def test_lsf12_blocks_direct_non_v710_transition(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "v710_bridge.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["products"].append(["FG_ALT_PRES", "ALT_PRES", "Alternatif Pres Model", 1000])
    wb["bom"].append(["FG_ALT_PRES", "SEMI_ALT_M", "Yarımamul", 1])
    wb["stock"].append(["SEMI_ALT_M", "Yarımamul", 5000])
    wb["furnace_product_yield"].append(["LSF-12", "FG_ALT_PRES", 1.0])
    wb["orders"].append(["FG_ALT_PRES", plan_start + pd.Timedelta(days=5), 200, "OEM"])

    initial = wb["initial_furnace_model_state"]
    initial["A2"] = "LSF-12"
    initial["B2"] = "CHEVY_EXP"
    initial["C2"] = 0
    initial["D2"] = 3000

    # Press başlangıç modeli CHEVY_EXP yapıldı; press her açık vardiyada tam kapasite (700)
    # ürettiğinden ve yarımamul hazırlığı 2 vardiya sonra olgunlaştığından ilk pencerede
    # yeterli başlangıç SEMI_CHEVY_M gerekir (aksi halde PRES_FULL_CAPACITY_SEMI_FEED).
    stock_ws = wb["stock"]
    for row in stock_ws.iter_rows(min_row=2):
        if str(row[0].value).strip() == "SEMI_CHEVY_M" and str(row[1].value).strip() == "Yarımamul":
            row[2].value = 2000
            break
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=20, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    lsf12 = result.tables["LSF12_Sira"]
    assert set(lsf12["Doğrudan V710 Dışı Geçiş"]) == {"Hayır"}
    changed = lsf12[lsf12["Pres Model Değişimi"] == "Evet"]
    assert set(changed["Önceki Model Pres MOQ Sağlandı mı?"]) == {"Evet"}

    alt_rows = lsf12[lsf12["Mevcut Model"] == "ALT_PRES"]
    assert not alt_rows.empty
    first_alt = alt_rows.iloc[0]
    assert int(first_alt["V710 Kampanya Neti"]) >= 3000


def test_order_allocation_respects_oem_before_oyc_for_same_product(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "priority.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["orders"].append(["FG_FORD_LDW", plan_start, 150, "OYC"])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=8, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    shipments = result.tables["Siparis_Karsilama"]
    orders = result.tables["Siparis"]
    ford_orders = orders[orders["Bitmiş Ürün Kodu"] == "FG_FORD_LDW"]
    ford_oem_ids = set(ford_orders[ford_orders["Sipariş Türü"] == "OEM"]["Sipariş ID"])
    ford_oyc_ids = set(ford_orders[ford_orders["Sipariş Türü"] == "OYC"]["Sipariş ID"])

    oem_last_shift = shipments[shipments["Sipariş ID"].isin(ford_oem_ids)]["Vardiya Sıra No"].max()
    oyc_first_shift = shipments[shipments["Sipariş ID"].isin(ford_oyc_ids)]["Vardiya Sıra No"].min()
    assert oem_last_shift <= oyc_first_shift


def test_sag_initial_setup_carry_consumes_capacity_before_production(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_carry.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["furnace_product_yield"].append(["LSF05", "FG_JEEP_DEC", 0.90])
    wb["initial_furnace_model_state"].append(["LSF05", "V363_LOW", 6, 1000])
    wb["initial_furnace_setup_carry"].append(["LSF05", "V363_LOW", "JEEP_AVG", 6])
    wb.save(input_path)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF05"
    source = "V363_LOW"
    target = "JEEP_AVG"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, source, 0)] == 0)
    builder.model.Add(builder.bound_sag[(furnace, target, 0)] == 1)
    builder.model.Add(builder.model_molds_sag[(furnace, source, 0)] == 0)
    builder.model.Add(builder.model_molds_sag[(furnace, target, 0)] == 6)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    assert solver.Value(builder.carry_setup_turns[(furnace, source, target, 0)]) == 6
    assert solver.Value(builder.setup_carry[(furnace, source, target, 0)]) == 0

    setup_rows = builder._sag_setup_rows(solver)
    first_setup = next(
        row
        for row in setup_rows
        if row["Fırın Adı"] == furnace
        and row["Kaynak Model Kodu"] == source
        and row["Hedef Model Kodu"] == target
    )
    assert first_setup["Tamamlanan Setup Turu"] == 6
    assert first_setup["Vardiya Sonu Setup Carry Turu"] == 0

    instructions = builder._change_instruction_rows(solver)
    lsf05_instruction = next(
        row
        for row in instructions
        if row["Fırın Adı"] == furnace
        and row["Kaynak Model"] == source
        and row["Hedef Model"] == target
    )
    assert lsf05_instruction["Devreden/Tamamlanan Setup"] == (
        "6 tur devreden, 6 tur tamamlanan, 0 tur kalan"
    )


def test_sag_new_model_activation_creates_setup_row(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_new_setup.xlsx"
    create_sample_workbook(input_path, plan_start)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=8, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    production = result.tables["Uretim"]
    sag_production = production[production["Fırın Tipi"] == "SAG"].sort_values(
        ["Fırın Adı", "Model Kodu", "Vardiya Sıra No"]
    )
    assert not sag_production.empty

    first_sag_rows = sag_production.groupby(["Fırın Adı", "Model Kodu"], as_index=False).first()
    setup = result.tables["SAG_Setup"]
    usage = result.tables["Firin_Kullanim"]
    for _idx, row in first_sag_rows.iterrows():
        matching_setup = setup[
            (setup["Fırın Adı"] == row["Fırın Adı"])
            & (setup["Hedef Model Kodu"] == row["Model Kodu"])
            & (setup["Vardiya Sıra No"] <= row["Vardiya Sıra No"])
        ]
        assert not matching_setup.empty
        assert int(matching_setup["Tamamlanan Setup Turu"].sum()) >= int(row["SAG Kalıp Sayısı"])

        usage_row = usage[
            (usage["Fırın Adı"] == row["Fırın Adı"])
            & (usage["Vardiya Sıra No"] == row["Vardiya Sıra No"])
        ].iloc[0]
        assert int(usage_row["SAG Setup Turu"]) >= 0


def test_sag_rebinding_same_model_requires_new_setup_turn(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_rebind_setup.xlsx"
    create_sample_workbook(input_path, plan_start)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    prepared.sag_moq["CHEVY_EXP"] = 0
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF04"
    model = "CHEVY_EXP"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.open_sag[(furnace, 2)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, model, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, model, 1)] == 0)
    builder.model.Add(builder.bound_sag[(furnace, model, 2)] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    assert solver.Value(builder.sag_new_setup_start[(furnace, model, 0)]) >= 1
    assert solver.Value(builder.sag_new_setup_start[(furnace, model, 2)]) >= 1


def test_sag_setup_need_matches_bound_mold_count(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_setup_mold_count.xlsx"
    create_sample_workbook(input_path, plan_start)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF04"
    model = "CHEVY_EXP"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, model, 0)] == 1)
    builder.model.Add(builder.model_molds_sag[(furnace, model, 0)] == 6)
    setup_to_model = sum(
        builder.setup_start[(furnace, source, model, 0)]
        for source in builder._compatible_models_for_furnace(furnace) + ["Yok"]
        if source != model
    )
    builder.model.Minimize(setup_to_model)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    assert solver.Value(setup_to_model) == 6


def test_sag_setup_start_requires_open_furnace(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_closed_setup.xlsx"
    create_sample_workbook(input_path, plan_start)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF04"
    model = "CHEVY_EXP"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 0)
    builder.model.Add(builder.setup_start[(furnace, "Yok", model, 0)] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status == cp_model.INFEASIBLE


def test_sag_unbinding_requires_setup_source_model(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_unbind_source.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["furnace_product_yield"].append(["LSF05", "FG_JEEP_DEC", 0.90])
    wb["initial_furnace_model_state"].append(["LSF05", "V363_LOW", 4, 1000])
    wb.save(input_path)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF05"
    source = "V363_LOW"
    target = "JEEP_AVG"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.open_sag[(furnace, 1)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, source, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, source, 1)] == 0)
    builder.model.Add(builder.bound_sag[(furnace, target, 1)] == 1)

    for next_model in builder._compatible_models_for_furnace(furnace) + ["Yok"]:
        if next_model != source:
            builder.model.Add(builder.setup_start[(furnace, source, next_model, 1)] == 0)
    builder.model.Add(builder.setup_start[(furnace, "Yok", target, 1)] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status == cp_model.INFEASIBLE


def test_initial_sag_model_can_unbind_after_moq(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "initial_sag_unbind_after_moq.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["furnace_product_yield"].append(["LSF05", "FG_JEEP_DEC", 0.90])
    wb["initial_furnace_model_state"].append(["LSF05", "V363_LOW", 4, 1000])
    wb.save(input_path)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF05"
    old_model = "V363_LOW"
    new_model = "JEEP_AVG"
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.open_sag[(furnace, 1)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, old_model, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, old_model, 1)] == 0)
    builder.model.Add(builder.bound_sag[(furnace, new_model, 1)] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)


def test_sag_campaign_moq_resets_after_rebind(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_moq_reset.xlsx"
    create_sample_workbook(input_path, plan_start)

    prepared, options = _prepared_sample(input_path, plan_start)
    prepared.sag_moq["CHEVY_EXP"] = 2
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()

    furnace = "LSF04"
    model = "CHEVY_EXP"
    product = "FG_CHEVY_EXP"
    for shift_index, bound in [(0, 1), (1, 0), (2, 1), (3, 0)]:
        builder.model.Add(builder.open_sag[(furnace, shift_index)] == 1)
        builder.model.Add(builder.bound_sag[(furnace, model, shift_index)] == bound)
    builder.model.Add(builder.net[(product, furnace, 0)] >= 2)
    builder.model.Add(builder.net[(product, furnace, 2)] == 1)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status == cp_model.INFEASIBLE


def test_unbinding_model_with_future_open_order_creates_slack(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "sag_unbind_future_order_slack.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["initial_furnace_model_state"].append(["LSF05", "V363_LOW", 4, 1000])
    wb.save(input_path)

    prepared, options = _prepared_sample(input_path, plan_start)
    builder = _CpSatPlanBuilder(prepared, options)
    builder._build_variables()
    builder._add_capacity_constraints()
    builder._add_unbound_completion_constraints()
    builder._add_unbound_open_order_slack_constraints()

    furnace = "LSF05"
    model = "V363_LOW"
    order = next(order for order in prepared.orders if order.product == "FG_FORD_LDW")
    slack = builder.unbound_open_order_slack[(order.order_id, furnace, 1)]
    builder.model.Add(builder.open_sag[(furnace, 0)] == 1)
    builder.model.Add(builder.open_sag[(furnace, 1)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, model, 0)] == 1)
    builder.model.Add(builder.bound_sag[(furnace, model, 1)] == 0)
    builder.model.Add(builder.ship[(order.order_id, 0)] == 0)
    builder.model.Add(builder.ship[(order.order_id, 1)] == 0)
    builder.model.Minimize(slack)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5
    solver.parameters.num_search_workers = 8
    status = solver.Solve(builder.model)

    assert status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    assert solver.Value(slack) == order.open_quantity


def test_same_product_cannot_run_on_multiple_sag_furnaces_same_shift(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "single_sag_furnace_per_product.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["furnace_product_yield"].append(["LSF04", "FG_FORD_LDW", 0.91])
    wb["furnace_product_yield"].append(["LSF08", "FG_FORD_LDW", 0.91])
    for row in wb["orders"].iter_rows(min_row=2):
        if row[0].value == "FG_FORD_LDW":
            row[2].value = 900
    for row in wb["stock"].iter_rows(min_row=2):
        if row[0].value in {"COMP_SENSOR", "SEMI_FORD_M"}:
            row[2].value = 3000
    for row in wb["near_sag_opening"].iter_rows(min_row=2):
        row[1].value = 3
        row[2].value = 3
        row[3].value = 3
    for row in wb["far_sag_opening"].iter_rows(min_row=2):
        row[1].value = 9
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=10, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    production = result.tables["Uretim"]
    sag_production = production[production["Fırın Tipi"] == "SAG"]
    assert not sag_production.empty

    for (_product, _shift), rows in sag_production.groupby(["Bitmiş Ürün Kodu", "Vardiya Sıra No"]):
        assert rows["Fırın Adı"].nunique() <= 1


def test_sag_pres_parallel_for_same_product_requires_due_or_capacity_need(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "parallel_gate_closed.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    _replace_sheet_rows(
        wb,
        "orders",
        [["FG_CHEVY_EXP", plan_start + pd.Timedelta(days=8), 120, "OEM"]],
    )
    initial = wb["initial_furnace_model_state"]
    initial["A2"] = "LSF-12"
    initial["B2"] = "CHEVY_EXP"
    initial["C2"] = 0
    initial["D2"] = 3000
    for row in wb["stock"].iter_rows(min_row=2):
        if row[0].value in {"COMP_GLASS_CLEAR", "SEMI_CHEVY_M"}:
            row[2].value = 5000
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=10, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    production = result.tables["Uretim"]
    chevy = production[production["Bitmiş Ürün Kodu"] == "FG_CHEVY_EXP"]
    for _shift, rows in chevy.groupby("Vardiya Sıra No"):
        assert rows["Fırın Tipi"].nunique() <= 1


def test_sag_pres_parallel_is_allowed_when_due_demand_needs_it(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "parallel_gate_open.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    _replace_sheet_rows(
        wb,
        "orders",
        [["FG_CHEVY_EXP", plan_start, 1500, "OEM"]],
    )
    initial = wb["initial_furnace_model_state"]
    initial["A2"] = "LSF-12"
    initial["B2"] = "CHEVY_EXP"
    initial["C2"] = 0
    initial["D2"] = 3000
    for row in wb["stock"].iter_rows(min_row=2):
        if row[0].value in {"COMP_GLASS_CLEAR", "SEMI_CHEVY_M"}:
            row[2].value = 5000
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=10, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    builder = _CpSatPlanBuilder(prepared, options)
    assert builder._sag_pres_parallel_allowed("FG_CHEVY_EXP", 0)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}


def test_carry_out_contains_open_campaign_model_state(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "campaign_carry_out.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    for row in wb["stock"].iter_rows(min_row=2):
        if row[0].value == "SEMI_CHEVY_M":
            row[2].value = 5000
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=8, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    campaigns = result.tables["Kampanya_Carry"]
    carry_out = result.tables["Carry_Out"]
    model_state = carry_out[carry_out["Kayıt Tipi"] == "Fırın Model Durumu"]
    carry_types = set(carry_out["Kayıt Tipi"])
    assert not campaigns.empty
    assert not model_state.empty
    assert "Malzeme Stok" in carry_types
    assert "Yarımamul Stok" in carry_types

    for _idx, row in model_state.iterrows():
        matching_campaign = campaigns[
            (campaigns["Fırın Adı"] == row["Fırın"])
            & (campaigns["Model Kodu"] == row["Kod"])
        ]
        assert not matching_campaign.empty
        assert int(row["Carry-Out Kampanya Neti"]) == int(matching_campaign.iloc[0]["Carry-Out Neti"])
        assert int(row["Bağlı Kalıp Sayısı"]) >= 0

    pres_state = model_state[model_state["Fırın"] == "LSF-12"]
    assert len(pres_state) <= 1


def test_sag_initial_bound_model_is_kept_active_when_furnace_opens(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "initial_sag_state.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["initial_furnace_model_state"].append(["LSF05", "V363_LOW", 4, 100])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start, solver_time_limit=8, workers=8)
    issues = validate_workbook(workbook, options, shifts)
    assert issues == []

    prepared = prepare_data(workbook, options, shifts)
    result = solve_plan(prepared, options)

    assert result.status in {"OPTIMAL", "FEASIBLE"}
    usage = result.tables["Firin_Kullanim"]
    lsf05_open = usage[(usage["Fırın Adı"] == "LSF05") & (usage["Fırın Durumu"] == "Açık")]
    assert not lsf05_open.empty
    assert int(lsf05_open["SAG Üretim Kalıbı Sayısı"].max()) >= 4

    production = result.tables["Uretim"]
    lsf05_production = production[production["Fırın Adı"] == "LSF05"]
    assert set(lsf05_production["Model Kodu"]) == {"V363_LOW"}
    first_lsf05_production = lsf05_production.sort_values("Vardiya Sıra No").iloc[0]
    assert int(first_lsf05_production["SAG Kalıp Sayısı"]) >= 4


def test_initial_sag_model_must_be_compatible_with_furnace(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "bad_initial_sag.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["initial_furnace_model_state"].append(["LSF05", "CHEVY_EXP", 2, 0])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)

    assert any(issue.rule == "INITIAL_MODEL_COMPATIBLE_WITH_FURNACE" for issue in issues)


def test_sag_master_duplicates_and_setup_carry_compatibility_are_validated(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "bad_sag_master_rows.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["sag_furnace_capacity"].append(["LSF04", 8, 26, 4])
    wb["sag_model_mold_capacity"].append(["V363_LOW", 6])
    wb["sag_model_mold_capacity"].append(["V710", 1])
    wb["sag_moq"].append(["V363_LOW", 300])
    wb["mandatory_dummy_models"].append(["JEEP_AVG", 1])
    wb["initial_furnace_setup_carry"].append(["LSF05", "CHEVY_EXP", "JEEP_AVG", 1])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)
    rules = {issue.rule for issue in issues}

    assert "UNIQUE_SAG_FURNACE_CAPACITY" in rules
    assert "UNIQUE_SAG_MOLD_MODEL" in rules
    assert "SAG_MOLD_MODEL_SAG_ONLY" in rules
    assert "UNIQUE_SAG_MOQ_MODEL" in rules
    assert "UNIQUE_MANDATORY_DUMMY_MODEL" in rules
    assert "SETUP_CARRY_MODEL_COMPATIBLE_WITH_FURNACE" in rules


def test_duplicate_sag_opening_dates_are_validated(tmp_path):
    plan_start = date(2026, 6, 21)
    input_path = tmp_path / "bad_opening_dates.xlsx"
    create_sample_workbook(input_path, plan_start)

    wb = load_workbook(input_path)
    wb["near_sag_opening"].append([plan_start, 1, 1, 1])
    wb["far_sag_opening"].append([plan_start + pd.Timedelta(days=7), 3])
    wb.save(input_path)

    workbook = read_input_workbook(input_path)
    days = estimate_planning_days(workbook, plan_start, 30)
    shifts = build_calendar(plan_start, days)
    options = PlanOptions(plan_start=plan_start)
    issues = validate_workbook(workbook, options, shifts)

    duplicate_issues = [issue for issue in issues if issue.rule == "UNIQUE_OPENING_DATE"]
    assert {issue.sheet for issue in duplicate_issues} == {
        "near_sag_opening",
        "far_sag_opening",
    }
