# Sistem Özeti

Bu sistem, otomotiv cam üretiminde siparişleri, stokları, malzeme/yarımamul durumunu, fırın kapasitelerini, kalıp ve kampanya kurallarını birlikte değerlendirerek hangi vardiyada hangi fırında hangi model/ürünün üretileceğini otomatik planlayacak; önce OEM sonra OYC siparişleri zamanında karşılamaya çalışacak, SAG ve LSF-12 fırınlarının sert çalışma kurallarını bozmayacak, malzeme eksikliği, MOQ, V710 geçişi, kalıp değişimi ve stok aşımı gibi darboğazları raporlayacak ve sonuçta hem sahadaki ustabaşı için uygulanabilir iş emirleri hem de planlama ekibi için neden-sonuç açıklamaları üretecek.

## Teknoloji Kararı

Kodlama dili `Python` olacaktır. Optimizasyon çözücüsü olarak `Google OR-Tools CP-SAT` kullanılacaktır. İlk uygulama web arayüzü veya veritabanı içermez; Python uygulaması girdi Excel workbook'unu okuyacak, modeli çözecek ve çıktı Excel workbook'u üretecektir. Kullanıcı komutu tek giriş noktası olan `run_plan.py` üzerinden çalıştırabilir; ancak uygulama kodu tek ve çok uzun bir Python dosyasına yığılmamalıdır. Excel okuma, veri doğrulama, veri hazırlama, CP-SAT model kurma, çözüm okuma ve çıktı Excel yazma işleri ayrı Python modüllerine bölünmelidir.

## Kampanya Nedir?

Dokümandaki kampanya, bir modelin belirli bir fırına bağlanıp o fırından sökülene kadar devam eden üretim dönemidir. Örneğin `V363_LOW` modeli `LSF05` fırınına bağlandıysa, o model sökülene kadar geçen süre bir kampanyadır. Bu süre içinde fırın bazı vardiyalarda kapalı olsa bile kampanya bitmiş sayılmaz; kampanya ancak model fırından sökülünce kapanır. Bunun önemi şudur: SAG fırınlarda bazı modeller için minimum üretim miktarı, yani `MOQ`, vardır; LSF-12 Pres fırında ise kampanya MOQ değeri modelden bağımsız olarak her zaman `3000` net üründür. Sistem "bu modeli bağladın, hemen 100 adet üretip sökemezsin; en az şu kadar net üretim yapmadan sökemezsin" kuralını kampanya üzerinden kontrol eder. Plan sonunda model hâlâ fırında bağlıysa kampanya açık kalır ve üretilen miktar sonraki plana `carry_out` olarak devreder.

**Otomatik MOQ Muafiyeti (Çıkmaz Çözümü):** Eğer plan başlangıcında fırına bağlı olan modelin açık kampanyasında üretilen miktar MOQ limitinin altındaysa ve sistemde bu modele ait ürünler için hiç açık sipariş kalmadıysa VEYA bu modeli MOQ limitine tamamlayacak kadar bileşen malzeme/yarımamul stoku bulunmuyorsa, sistem kilitlenmeyi (deadlock) önlemek için bu başlangıç kampanyasına özel olarak söküm esnasında MOQ kısıtını otomatik olarak gevşetir. Bu durum dışındaki normal koşullarda ve plan esnasında yeni başlatılan kampanyalarda MOQ kuralı sert kısıt olarak uygulanmaya devam eder.

**Söküm Esnasında Gecikmiş Talep Kapatma Muafiyeti (Malzeme Çıkmazı Çözümü):** Bir model fırından sökülürken, o modele ait vadesi geçmiş/gecikmiş tüm siparişlerin söküm vardiyasında tamamlanmış olması istenir. Ancak, eğer bu siparişlerin üretilmesi için gerekli bileşen malzeme/yarımamul eksikliği varsa (malzeme yetersizliği), söküm kısıtının fırını kilitlemesini önlemek için bu kapatma zorunluluğu eldeki ve beklenen malzeme stoklarının elverdiği maksimum üretilebilir miktar ile sınırlandırılır. Malzeme yetersizliği nedeniyle karşılanamayan talep, fırın sökümünü engellemez ve darboğaz/açık miktar olarak raporlanır.

## Carry-Out Nedir?

`carry_out`, bir plan bittiğinde sonraki rolling plana devredilmesi gereken durum paketidir. Sistem her planı sıfırdan başlamış gibi düşünmez; önceki planın sonunda fırınlarda hangi modellerin bağlı kaldığını, kaç kalıbın bağlı olduğunu, tamamlanmamış setup carry işlerini kaynak-hedef model anahtarıyla, açık kampanyalarda kaç net ürün üretildiğini, stokların son durumunu ve henüz olgunlaşmamış yarımamul hazırlıklarını bu paketle sonraki plana aktarır. Satın alınan malzeme tüketimi üretim vardiyasında doğrudan stoktan düşüldüğü için plan ufku dışına taşan ayrı malzeme tüketimi devri tutulmaz. Kısaca `carry_out`, "bir planın bıraktığı yerden bir sonraki planın doğru şekilde devam etmesini sağlayan devreden kayıtlar"dır.

## Girdi Tabloları ve Örnek Veriler

Tüm girdiler tek bir Excel workbook içinde tutulur. Aşağıdaki her başlık bir worksheet adını gösterir; örnek satırlar temsili veridir.

Not: Bu bölümdeki tablolar yalnızca beklenen tablo yapısını ve örnek kullanım şeklini göstermek için verilmiştir; içlerindeki ürün kodları, tarihler, miktarlar, stoklar, kapasite değerleri ve diğer satır verileri gerçek veri değildir.

`plan_calendar` kullanıcı tarafından verilen bir worksheet değildir. Sistem plan çalıştırıldığı günü plan başlangıcı kabul eder ve günde 3 vardiya kuralıyla plan takvimini siparişlerin tamamı karşılanana kadar otomatik uzatır. Eğer tüm siparişler veri, malzeme, yarımamul, kapasite, MOQ, V710/LSF-12 veya SAG açılış kısıtları nedeniyle karşılanamıyorsa sistem sonsuz döngüye girmez; açık kalan miktarı neden koduyla raporlar.

**LSF-12 Kapasite Gevşetmesi (Malzeme Engeli Çözümü):** LSF-12 Pres fırınının her açık vardiyada tam kapasiteyle çalışması hedeflenir (idle bırakılamaz). Ancak aktif model veya geçiş köprüsü olan V710 modeli için malzeme/yarımamul eksikliği bulunuyorsa, fırının kilitlenmesini veya planın çözümsüz kalmasını önlemek için kapasite kuralı otomatik olarak esnetilir. Fırın bu durumlarda kapasite düşürebilir veya tamamen boş (idle) kalabilir.

**SAG Fırın Açma Hedef Gevşetmesi (Kapasite/Dummy Çelişkisi Çözümü):** Planlamacı tarafından verilen vardiyalık veya günlük açık SAG fırın sayısı hedefleri sert kısıttır. Ancak, eldeki siparişler veya malzeme durumu fırınların tamamını doldurmaya yetmiyorsa (ve boş fırınların dummy-only açılması yasak olduğundan), sistem fırın açma hedefini otomatik olarak düşürür ve planın çözülebilmesini sağlar. Açık fırın adedindeki eksiklik darboğaz olarak raporlanır.

### `orders` - Sipariş Tablosu

Amaç: Hangi ürünün, ne miktarda ve hangi tarihe kadar karşılanması gerektiğini belirler. Sistem önce bu tabloya bakarak toplam talebi çıkarır, sonra başlangıç bitmiş ürün stoklarına bakarak eldeki stokla karşılanabilecek kısmı düşer. Üretim planına yalnız stokla kapanmayan açık ihtiyaç girer; eğer sipariş miktarı başlangıç stoku ile tamamen karşılanabiliyorsa sistem o sipariş için üretim planlamaz. Başlangıç bitmiş ürün stoku aynı ürün içinde önce OEM siparişlere termin sırasıyla, sonra OYC siparişlere termin sırasıyla dağıtılır. OEM/OYC önceliği ve gecikme riski de bu stok düşümü sonrası kalan açık miktar üzerinden hesaplanır. Aynı ürün, sipariş türü ve termin tarihindeki satırlar sistem tarafından tek talep satırına toplanır.

Sipariş tablosunda manuel aciliyet veya müşteri duruş riski kolonu bulunmaz. Sistem bu riski termin tarihi, açık miktar, eldeki stok, aynı ürün için OEM öncelik kapısı, aynı sipariş türü içindeki önceki terminli talepler, malzeme durumu ve üretilebilir kapasiteye göre kendisi hesaplar.

| Bitmiş Ürün Kodu | Termin Tarihi | Sipariş Miktarı | Sipariş Türü |
|---|---|---:|---|
| FG_V710_A | 2026-07-01 | 1200 | OEM |
| FG_V710_B | 2026-07-02 | 800 | OYC |
| FG_FORD_LDW | 2026-07-03 | 500 | OEM |
| FG_JEEP_DEC | 2026-07-04 | 300 | OEM |
| FG_CHEVY_EXP | 2026-07-05 | 650 | OYC |

### `bom` - Ürün Ağacı Tablosu

Amaç: Her bitmiş ürün üretildiğinde hangi malzeme veya yarımamulden ne kadar tüketileceğini belirler. Sistem net üretim miktarını bu tabloyla çarparak malzeme ihtiyacını, yarımamul ihtiyacını ve stoktan düşülecek miktarı hesaplar. Bu tabloda eksik bileşen varsa sistem ürünü yanlışlıkla üretilebilir sanabilir; fazla veya hatalı bileşen varsa gereksiz malzeme darboğazı oluşabilir. Bir bitmiş ürüne ait malzeme (Bileşen Malzeme Türü = Malzeme) girdisi ürün ağacında hiç bulunmayabileceği gibi, bir veya birden fazla da olabilir. Ancak her bitmiş ürünün ürün ağacında en az bir yarımamul (Bileşen Malzeme Türü = Yarımamul) girdisi bulunması zorunludur. Aynı malzeme birden fazla bitmiş üründe kullanılabilir; aynı şekilde aynı yarımamul de birden fazla bitmiş ürünün ürün ağacında yer alabilir. Yarımamul eksikliği `material_arrivals` ile gelen satın alınmış malzeme gibi ele alınmaz; başlangıç yarımamul stoku yetmiyorsa sistem eksik yarımamulü 2 vardiyalık hazırlama kuralıyla kullanılabilir hale getirir.

| Bitmiş Ürün Kodu | Bileşen Malzeme Kodu | Bileşen Malzeme Türü | Bileşen Miktarı |
|---|---|---|---:|
| FG_V710_A | COMP_PVB_CLEAR | Malzeme | 1 |
| FG_V710_A | SEMI_V710_M | Yarımamul | 1 |
| FG_V710_B | SEMI_V710_M | Yarımamul | 1 |
| FG_FORD_LDW | COMP_SENSOR | Malzeme | 1 |
| FG_FORD_LDW | SEMI_FORD_M | Yarımamul | 1 |
| FG_JEEP_DEC | SEMI_JEEP_M1 | Yarımamul | 1 |
| FG_CHEVY_EXP | COMP_GLASS_CLEAR | Malzeme | 2 |
| FG_CHEVY_EXP | SEMI_CHEVY_M | Yarımamul | 1 |

### `stock` - Stok Tablosu

Amaç: Plan başlangıcındaki bitmiş ürün, malzeme ve yarımamul stoklarını verir. Sistem önce bitmiş ürün stokuyla sipariş kapatmayı dener, sonra üretim için gereken malzeme ve yarımamulün hazır olup olmadığını kontrol eder. Ürün ağacında geçen her malzeme ve yarımamul burada kayıtlı olmalıdır; stok yoksa satır silinmez, miktar `0` yazılır. Bitmiş ürün için stok satırı yoksa başlangıç bitmiş ürün stoku `0` kabul edilir; ancak ürün ağacında geçen malzeme veya yarımamul için stok satırı yoksa bu durum veri hatasıdır.

| Kod | Stok Türü | Stok Miktarı |
|---|---|---:|
| FG_V710_A | Bitmiş Ürün | 100 |
| COMP_PVB_CLEAR | Malzeme | 5000 |
| COMP_SENSOR | Malzeme | 800 |
| SEMI_V710_M | Yarımamul | 600 |
| SEMI_JEEP_M1 | Yarımamul | 250 |
| SEMI_FORD_M | Yarımamul | 400 |
| SEMI_CHEVY_M | Yarımamul | 300 |

### `furnaces` - Fırınlar Tablosu

Amaç: Sistemdeki fırınları ve fırın tiplerini tanımlar. Sistem `SAG` fırınlara vagon, kalıp, tur ve maket kurallarını; `Pres` fırına ise LSF-12 kapasite ve V710 geçiş kurallarını uygular. Mevcut sistem sözleşmesinde Pres tarafı tek fırındır ve bu fırın `LSF-12` olarak tanımlanır; Pres kapasite, V710 geçişi ve sabit `3000` net kampanya MOQ kuralı bu fırına bağlıdır. Fırınlar tablosunda `Pres` tipinde `LSF-12` dışında satır bulunması veya birden fazla Pres satırı yazılması veri hatasıdır. Fırın tipi yanlış girilirse model tamamen farklı fiziksel kurallarla plan yapar.

| Fırın Adı | Fırın Tipi |
|---|---|
| LSF04 | SAG |
| LSF05 | SAG |
| LSF06 | SAG |
| LSF08 | SAG |
| LSF-12 | Pres |

### `products` - Ürün Master Tablosu

Amaç: Her bitmiş ürünün ürün kartını tek yerde tutar. Siparişler ürün koduyla gelir; kalıp kapasitesi, MOQ ve kampanya kararları model kodu üzerinden yürür, randıman ise fırın ve bitmiş ürün çifti üzerinden yürür. Bu nedenle sistem `products` tablosundaki model eşleşmesini kullanarak ürünün hangi modele bağlı olduğunu bulur.

Her bitmiş ürün bu tabloda tam olarak bir satırla bulunmalıdır. Aynı bitmiş ürün için birden fazla satır, eksik model kodu, eksik model tanımı veya negatif azami stok miktarı veri hatasıdır. Siparişte, ürün ağacında, bitmiş ürün stokunda, fırın-ürün randıman tablosunda veya başka bir bitmiş ürün alanında görünen ürün burada yoksa sistem optimizasyonu başlatmadan hata verir.

`Azami Stok Miktarı`, plan sonunda ürün bazında istenmeyen stok fazlasını ölçmek için referans sınırdır; üretim yasağı değildir. Siparişleri karşılamak, MOQ kampanyasını tamamlamak, SAG fırın açma eşitliklerini sağlamak veya LSF-12 kapasitesini doldurmak için gerekirse azami stok aşılabilir. Sipariş gereği erken üretilmiş ve açık/gelecek siparişe ayrılmış stok azami stok cezasına girmez; ceza yalnız siparişe, başlangıçtan gelen kaçınılmaz stoka veya kanıtlı sonraki plan devrine bağlanamayan gerçek fazla stok için uygulanır.

| Bitmiş Ürün Kodu | Model Kodu | Model Tanımı | Azami Stok Miktarı |
|---|---|---|---:|
| FG_V710_A | V710 | V710 Ana Model | 2500 |
| FG_V710_B | V710 | V710 Varyant | 1800 |
| FG_FORD_LDW | V363_LOW | Ford V363 Alçak | 900 |
| FG_JEEP_DEC | JEEP_AVG | Jeep Avenger | 700 |
| FG_CHEVY_EXP | CHEVY_EXP | Chevy Express | 1000 |

### `sag_model_mold_capacity` - SAG Model Kalıp Kapasitesi Tablosu

Amaç: SAG fırınlarda her model için elde kaç kalıp olduğunu belirtir. Sistem bir modelin aynı anda farklı SAG fırınlarda veya aynı fırında toplam kaç kalıpla çalışabileceğini bu kapasiteyle sınırlar. V710 bu tabloda yer almaz; çünkü V710 yalnız LSF-12 Pres fırında çalışır. Bu tablo sadece SAG modelleri içindir; pres fırınlar için kapasite zaten her zaman tek kalıptır, çünkü pres fırına aynı anda yalnızca tek bir kalıp bağlanabilir.

| Model Kodu | Kalıp Sayısı |
|---|---:|
| V363_LOW | 6 |
| V363_HIGH | 7 |
| JEEP_AVG | 6 |
| CHEVY_EXP | 6 |
| SPRINTER | 5 |

### `sag_furnace_capacity` - SAG Fırın Kalıp Model Kapasitesi Tablosu

Amaç: Her SAG fırının bir vardiyada ne kadar iş yapabileceğini üç ayrı kapasiteyle tarif eder. `Vardiyadaki Tur Sayısı`, fırının o vardiyadaki toplam tur bütçesidir. Kalıp değişimi yani setup gerekiyorsa bu bütçeden tur tüketir ve üretime kalan tur sayısı azalır. Kalıp değişimi yoksa brüt üretim üst sınırı kabaca kullanılan üretim kalıbı sayısı ile üretime kalan tur sayısının çarpımıdır.

`Vagon Sayısı`, fırının fiziksel doluluk sınırıdır. Aynı vardiyada kullanılan üretim kalıpları, kalıp değişimiyle bağlanan/sökülen kalıplar, mecburi maketler ve kapasite doldurmak için eklenen opsiyonel maketler toplamı bu sayıyı aşamaz. Açılan SAG fırında kapasite üretim kalıbı, kalıp değişimi işi, mecburi maket ve gerekiyorsa opsiyonel maketle doldurulur; fakat opsiyonel maket tek başına fırın açma gerekçesi olamaz.

`Vardiyadaki Çalışabileceği Farklı Model Sayısı`, aynı SAG fırında aynı vardiyada kaç farklı modelin aktif bağlı kalabileceğini sınırlar. Aynı modele bağlı farklı bitmiş ürünler bu sınırda tek model sayılır. Bu tablo hangi ürünün hangi fırında üretilebileceğini söylemez; o bilgi `furnace_product_yield` tablosundan gelir. Hangi modelden toplam kaç kalıp bulunduğunu da bu tablo belirlemez; o bilgi `sag_model_mold_capacity` tablosundan gelir. Bu tabloda yalnız SAG fırınları bulunmalıdır; LSF-12 Pres fırını burada yer almaz.

Örnek: `LSF04` için tur sayısı `8`, vagon sayısı `26`, farklı model kapasitesi `4` ise sistem bir vardiyada bu fırında en fazla 4 farklı SAG modelini birlikte çalıştırabilir. 5 üretim kalıbı ve 1 mecburi maket kullanılan bir model, vagon kapasitesinden 6 yer tüketir. Aynı vardiyada 2 tur setup kaybı varsa üretime kalan tur sayısı 6 olur; bu durumda 5 kalıp için brüt üretim üst sınırı yaklaşık `5 * 6 = 30` adettir ve net üretim ayrıca fırın-ürün randıman değeriyle hesaplanır.

| Fırın Adı | Vardiyadaki Tur Sayısı | Vagon Sayısı | Vardiyadaki Çalışabileceği Farklı Model Sayısı |
|---|---:|---:|---:|
| LSF04 | 8 | 26 | 4 |
| LSF05 | 8 | 30 | 4 |
| LSF06 | 10 | 26 | 4 |
| LSF07 | 10 | 26 | 3 |
| LSF08 | 8 | 34 | 5 |

### `furnace_product_yield` - Fırın Ürün Randıman Tablosu

Amaç: Hangi bitmiş ürünün hangi fırında üretilebileceğini ve o fırında brüt üretimin kaç net iyi ürüne dönüşeceğini tek tabloda tanımlar. Bu tablo beyaz listedir: satır varsa fırın-ürün çifti üretilebilir, satır yoksa o eşleşme yasaktır. `Randıman` kolonu aynı satırdaki üretilebilir eşleşmenin net üretim oranıdır.

Bir bitmiş ürün hem SAG fırında hem de `LSF-12`de üretilebiliyorsa bu tabloda aynı bitmiş ürün için en az iki ayrı satır olur: biri ilgili SAG fırını, biri `LSF-12` için. Bir bitmiş ürün yalnız `LSF-12` ile eşleşiyorsa sadece `LSF-12`de, yalnız belirli SAG fırınlarıyla eşleşiyorsa sadece o SAG fırınlarında üretilebilir. Aynı ürün farklı fırınlarda farklı randımanla çalışabilir; aynı modele bağlı iki farklı bitmiş ürünün aynı fırındaki randımanı da farklı olabilir.

Girdi workbook'unda bitmiş ürün kodu içeren tüm tablolardaki ürünler bu listede en az bir fırınla eşleşmelidir. Yani siparişte, ürün ağacında, bitmiş ürün stokunda, model-ürün eşleşmesinde veya azami stok tablosunda görünen bir bitmiş ürün burada yoksa sistem optimizasyonu hiç başlatmadan veri hatası verir; çünkü sistemde tanımlı görünen her bitmiş ürünün üretilebileceği en az bir fırın olmalıdır. `Randıman` değeri boş olamaz, 0 ile 1 arasında olmalıdır. Bu genel beyaz liste kuralı V710 için de geçerlidir; V710 yalnız `LSF-12` ile eşleştiği için SAG fırında V710 satırı yazılması veri hatasıdır.

| Fırın Adı | Bitmiş Ürün Kodu | Randıman |
|---|---|---:|
| LSF04 | FG_CHEVY_EXP | 0.92 |
| LSF-12 | FG_CHEVY_EXP | 0.94 |
| LSF05 | FG_FORD_LDW | 0.91 |
| LSF08 | FG_JEEP_DEC | 0.90 |
| LSF-12 | FG_V710_A | 0.95 |

### `sag_moq` - SAG MOQ Tablosu

Amaç: SAG fırınlarında bir model fırına bağlandıktan sonra sökülebilmesi için kampanya boyunca üretilmesi gereken minimum net miktarı belirler. Sistem SAG kampanya sayacını net üretimle artırır; sayaç MOQ altındayken modelin SAG fırından sökülmesine izin vermez. Bu tablo yalnız SAG kampanyaları içindir. LSF-12 Pres fırını bu tabloyu kullanmaz; LSF-12 için kampanya MOQ değeri modelden bağımsız olarak her zaman `3000` net üründür. Aynı model hem SAG hem LSF-12 üzerinde üretilebiliyorsa bu tablodaki değer yalnız SAG söküm kuralına uygulanır.

| Model Kodu | MOQ Miktarı |
|---|---:|
| V363_LOW | 600 |
| V363_HIGH | 700 |
| JEEP_AVG | 500 |

Sadece Pres/`LSF-12` üzerinde çalışan modeller, örneğin `V710`, bu tabloda yer almaz. SAG tarafında üretilebilir her model için bu tabloda satır bulunmalıdır. Bir SAG modelinde MOQ uygulanmayacaksa satır silinmez; `MOQ Miktarı` değeri `0` yazılır. SAG modeli için satır yoksa sistem bunu veri hatası olarak raporlar.

### `material_arrivals` - Yoldaki Teslimatlar Tablosu

Amaç: Satın alınmış veya teslimatı kesinleşmiş, ancak plan başlangıcında henüz fiziksel stokta olmayan malzemeleri gösterir. Bu tablo sipariş, üretim talebi veya bitmiş ürün stoku oluşturmaz; sadece ilgili malzemenin belirtilen tarihte kullanılabilir stokuna giriş ekler. Sistem önce `stock` tablosundaki mevcut malzeme stokunu kullanır, stok yetmiyorsa bu tablodaki yoldaki teslimatlara bakar.

Bu tablo yalnız ürün ağacında `Bileşen Malzeme Türü = Malzeme` olan satın alınan bileşenler için kullanılır. Bitmiş ürün, yarımamul veya model kodu bu tabloya yazılmaz. Yarımamul eksikliği yoldaki teslimatla değil, 2 vardiyalık yarımamul hazırlama kuralıyla ele alınır. Tablodaki `Malzeme` kodu, ürün ağacındaki ve stok tablosundaki malzeme koduyla birebir aynı olmalıdır; bilinmeyen kod veya negatif miktar veri hatasıdır.

`Beklenen Teslimat Tarihi`, malzemenin o tarihin ilk vardiyasından itibaren kullanılabilir kabul edildiği gündür. Aynı malzeme ve aynı tarih için birden fazla satır varsa sistem miktarları toplar. Üretim hangi vardiyada başlatılıyorsa satın alınan malzeme de aynı vardiyada stoktan düşülür; bu nedenle teslimatın üretim vardiyasına yetişmesi gerekir. Teslimat yetişiyorsa üretim başlatılabilir ve bitmiş ürün stok girişi aynı üretim vardiyasında oluşur; teslimat yetişmiyorsa ilgili üretim yapılamaz ve açık sipariş malzeme kaynaklı neden koduyla raporlanır.

| Malzeme | Beklenen Teslimat Tarihi | Miktar |
|---|---|---:|
| COMP_PVB_CLEAR | 2026-07-01 | 2000 |
| COMP_SENSOR | 2026-07-02 | 300 |
| COMP_GLASS_CLEAR | 2026-07-02 | 1500 |
| COMP_HEATER | 2026-07-03 | 400 |
| COMP_RAIN_SENSOR | 2026-07-04 | 250 |

### `mandatory_dummy_models` - Mecburi Maket Eklenecek Modeller Tablosu

Amaç: Bazı SAG modellerinde üretim kalıbı dışında zorunlu olarak fırında yer tutması gereken maket/vagon adedini belirtir. Mecburi maket üretim değildir; brüt üretim, net üretim, sipariş karşılama, stok girişi, ürün ağacı tüketimi veya MOQ sayacına miktar eklemez. Sadece SAG fırının fiziksel vagon kapasitesini işgal eder.

Sistem bir model ilgili SAG fırın-vardiyada aktif yükleme düzenine giriyorsa bu tablodaki mecburi maket adedini vagon kapasitesinden düşer. 1 kalıp da kullanılsa 10 kalıp da kullanılsa mecburi maket model başına bir kez sayılır; ürün sayısıyla, kullanılan kalıp sayısıyla veya tur sayısıyla çarpılmaz. Aynı modelin birden fazla bitmiş ürünü aynı vardiyada üretiliyorsa yine tek mecburi maket adedi uygulanır.

Bu tablo yalnız SAG modelleri içindir. `V710` veya sadece Pres/`LSF-12` üzerinde çalışan modeller burada yer almaz. Bir model bu tabloda yoksa mecburi maket adedi `0` kabul edilir; istenirse açık görünürlük için `0` satırı yazılabilir. Aynı model için birden fazla satır olmamalıdır; tekrar eden model satırı veya negatif maket adedi veri hatasıdır.

Mecburi maket ile opsiyonel maket farklıdır. Mecburi maket modelin teknik gereği olarak zorunludur; opsiyonel maket ise açılmış SAG fırında boş kalan vagonu doldurmak için sistemin kullandığı tamamlayıcı yer tutucudur. Opsiyonel maket tek başına fırın açma gerekçesi olamaz, mecburi maket de üretim miktarı yerine geçmez.

| Model | Mecburi Maket Adeti |
|---|---:|
| V363_LOW | 1 |
| V363_HIGH | 1 |
| JEEP_AVG | 2 |
| CHEVY_EXP | 0 |
| SPRINTER | 1 |

### `near_sag_opening` - Yakın Plan Vardiya Fırın Sayısı Tablosu

Amaç: Yakın tarihlerde her vardiyada kaç SAG fırının çalışacağını kesin olarak belirler. Sistem bu sayıyı üst sınır veya öneri olarak değil, sert eşitlik olarak uygular; yani belirtilen vardiyada tam olarak o kadar SAG fırın açık olmalıdır. Kullanıcı burada hangi fırınların açılacağını seçmez, sadece açılacak SAG fırın sayısını verir. Örneğin bir vardiyada `3` yazıyorsa, açılacak en mantıklı 3 SAG fırını sipariş, stok, malzeme, model bağlılığı, kalıp durumu ve kapasiteye göre optimizasyon modeli seçer. Plan ufkundaki her tarih ya `near_sag_opening` ya da `far_sag_opening` tablosunda bulunmalıdır. Aynı tarih iki tabloda birden varsa çakışma hatasıdır; iki tabloda da yoksa eksik SAG açılış planı nedeniyle veri hatasıdır.

| Tarih | 1. Vardiyada Açılacak SAG Fırın Sayısı | 2. Vardiyada Açılacak SAG Fırın Sayısı | 3. Vardiyada Açılacak SAG Fırın Sayısı |
|---|---:|---:|---:|
| 2026-07-01 | 3 | 3 | 2 |
| 2026-07-02 | 3 | 2 | 2 |
| 2026-07-03 | 4 | 3 | 3 |
| 2026-07-04 | 2 | 2 | 2 |
| 2026-07-05 | 3 | 3 | 3 |

### `far_sag_opening` - Uzak Plan Toplam Fırın Sayısı Tablosu

Amaç: Uzak tarihler için vardiya kırılımı yerine günlük toplam kaç SAG fırın açılacağını belirler. Sistem o günün 3 vardiyasındaki açık SAG fırın toplamını bu sayıya eşitler, hangi vardiyada hangi fırınların açılacağını optimizasyon seçer. Yakın plan verisi olan tarihlerde bu tablo kullanılmaz. Plan ufkundaki her tarih için ya yakın plan vardiya kırılımı ya da uzak plan günlük toplamı verilmelidir; eksik tarih veri hatasıdır.

| Tarih | 3 Vardiya Toplamında Açılacak SAG Fırın Sayısı |
|---|---:|
| 2026-07-06 | 8 |
| 2026-07-07 | 9 |
| 2026-07-08 | 7 |
| 2026-07-09 | 8 |
| 2026-07-10 | 9 |

### `initial_furnace_model_state` - Başlangıç Fırın Model Durumu

Amaç: İlk plan koşusunda fırınların hangi model, kaç bağlı kalıp ve hangi açık kampanya sayacıyla başladığını tek tabloda belirtir. Sistem fırının plan başlangıcı vardiyasındaki bağlı modellerini, bağlı kalıp sayılarını ve açık kampanyanın o ana kadar üretilmiş net miktarını buradan alır. Bu tablo yalnız ilk manuel başlangıç için kullanılır; sonraki rolling koşularda başlangıç fırın-model durumu kullanıcıdan tekrar alınmaz, önceki planın `carry_out` paketinden devralınır.

SAG fırınlarda aynı fırın için birden fazla satır olabilir; çünkü aynı SAG fırında aynı anda birden fazla model bağlı kalabilir. Her satır bir fırın-model bağlılığını gösterir. Örneğin `LSF04` üzerinde hem `CHEVY_EXP` hem `V363_LOW` bağlıysa, `LSF04` için iki ayrı satır yazılır ve her satırda o modele ait bağlı kalıp sayısı verilir. Başlangıçta üzerinde model bağlı olmayan fırın için satır yazılmaz; satır yokluğu o fırının plan başlangıcında boş olduğu anlamına gelir.

Aynı model plan başlangıcında iki farklı SAG fırına bağlı yazılamaz. Böyle bir veri, "aynı model aynı vardiyada yalnız tek SAG fırında çalışabilir" kuralını daha model kurulmadan ihlal eder ve sistem precheck hatası verir.

`Başlangıç Kampanya Net Üretim Miktarı`, o fırın-model kampanyasının plan başlamadan önce biriktirmiş olduğu net üretim miktarıdır. Sistem MOQ sayacını sıfırdan değil bu değerden başlatır; böylece önceki planda başlamış ama henüz kapanmamış kampanya doğru şekilde devam eder. İlk kez bağlanmış veya kampanya sayacı olmayan model için `0` yazılır.

LSF-12 Pres fırında aynı anda tek model bağlı olabilir. Plan başlangıcında `LSF-12` üzerinde model bağlıysa en fazla bir başlangıç model satırı yazılır; bağlı kalıp sayısı Pres için kullanılmaz ve `0` yazılabilir. `LSF-12` için satır yoksa Pres fırın başlangıçta boş kabul edilir; aynı anda birden fazla `LSF-12` başlangıç model satırı veri hatasıdır. SAG fırında bağlı kalıp sayısı negatif olamaz, modelin toplam kalıp kapasitesini aşamaz ve fırının vagon kapasitesi/mecburi maket sınırlarına sığmalıdır.

| Fırın Adı | Model Kodu | Bağlı Kalıp Sayısı | Başlangıç Kampanya Net Üretim Miktarı |
|---|---|---:|---:|
| LSF04 | CHEVY_EXP | 6 | 480 |
| LSF04 | V363_LOW | 2 | 320 |
| LSF05 | V363_HIGH | 5 | 420 |
| LSF-12 | V710 | 0 | 2100 |
| LSF08 | JEEP_AVG | 6 | 260 |

### `initial_furnace_setup_carry` - Başlangıç Fırın Setup Carry Tablosu

Amaç: İlk plan koşusunda SAG fırınları için önceki plandan devreden tamamlanmamış kalıp değişimi/setup işlerini operasyon anahtarıyla belirtir. Her satır bir fırın, kaynak model ve hedef model kombinasyonundaki kalan setup turunu gösterir. Sonraki rolling koşularda bu tablo kullanıcıdan tekrar alınmaz, önceki planın `carry_out` paketinden devralınır.

Bu tablo yalnız SAG fırınları içindir. Aynı fırında birden fazla carry satırı bulunabilir; ancak aynı fırın-kaynak-hedef anahtarı tekrarlanamaz. Saf bağlama veya saf söküm için karşı taraf `Yok` yazılır; iki taraf birden `Yok` olamaz. Satır yoksa ilgili operasyon anahtarı için carry `0` kabul edilir. Negatif değer, Pres/`LSF-12` satırı, bilinmeyen model, kaynak ve hedefin aynı model olması veya iki tarafın da `Yok` olması veri hatasıdır.

| Fırın Adı | Kaynak Model Kodu | Hedef Model Kodu | Kalan Setup Carry Turu |
|---|---|---|---:|
| LSF04 | CHEVY_EXP | V363_LOW | 3 |
| LSF04 | V363_HIGH | Yok | 1 |

## Amaç Fonksiyonu ve Kullanıcı Deneyimi

Sistemin temel amacı, eldeki siparişleri, stokları, fırın kapasitelerini, malzeme/yarımamul uygunluğunu ve kampanya kurallarını birlikte değerlendirerek sahada uygulanabilir en iyi üretim planını oluşturmaktır. Sistem önce OEM siparişlerini zamanında karşılamaya çalışır; OEM hedefi korunduktan sonra OYC siparişlerini iyileştirir. Sipariş hedefleri sağlandıktan sonra gereksiz stok, gereksiz model değişimi, opsiyonel maket kullanımı, azami stok aşımı ve kampanya/setup maliyeti gibi operasyonel yükleri azaltır. Yani sistem tek seferde "her şeyden biraz" taviz veren bir ağırlık hesabı yapmaz; önce müşteri önceliğini, sonra operasyonel kaliteyi koruyan sıralı bir karar mantığıyla çalışır.

Bu sistemi ana olarak planlama ekibi kullanır. Planlamacı girdi Excel workbook'unu günceller, proje klasöründeki Python scriptini çalıştırır ve oluşan çıktı Excel workbook'unu inceler. Sistem çalışma gününden başlayarak siparişler kapanana kadar gerekli vardiya ufkunu otomatik oluşturur. Çıktı Exceli planlamacıya hangi siparişlerin stoktan kapandığını, hangi siparişler için üretim gerektiğini, hangi siparişlerin gecikme riski taşıdığını, hangi darboğazın hangi siparişi etkilediğini ve çözümün neden böyle kurulduğunu gösterir. Eğer veri eksikliği, malzeme eksikliği, SAG açma sayısı çakışması, MOQ kuralı veya LSF-12/V710 kuralı nedeniyle üretim yapılamıyorsa sistem bunu genel hata olarak bırakmaz; ilgili ürün, model, fırın, tarih, malzeme veya kural üzerinden açıklanabilir neden koduyla çıktı Exceline yazar.

Sahadaki ustabaşı ve üretim ekibi ise sistemin matematiksel detayını görmek zorunda değildir. Onlar için çıktı Excelinde vardiya bazında hangi fırının açık olacağı, hangi modelin bağlı kalacağı veya değişeceği, hangi ürünün üretileceği, kaç kalıp kullanılacağı, kaç tur yapılacağı, mecburi/opsiyonel maket durumu, malzeme-yarımamul hazırlığı ve kritik uyarılar şeklinde okunabilir iş emri sheet'leri bulunur. Böylece planlama sheet'leri kararın nedenini, saha iş emri sheet'leri yapılacak işi gösterir.

Yönetim ve takip tarafı için sistem; OEM/OYC karşılama oranı, geciken veya açık kalan sipariş miktarı, malzeme kaynaklı açıklar, kapasite darboğazları, azami stok aşımı, açık kampanyalar ve sonraki plana devredecek `carry_out` kayıtlarını özetler. Amaç yalnız bir çizelge üretmek değil, her plan koşusunda "ne üretilecek, neden böyle üretilecek, ne yetişmiyor ve bir sonraki planda ne devralınacak?" sorularına aynı veri üzerinden cevap verebilmektir.

## Çıktı Tabloları

Bu bölümde kolonları tanımlanan tablolar çıktı Excel workbook'undaki ana sheet'lerdir: `Siparis`, `Siparis_Karsilama`, `Uretim`, `Firin_Kullanim`, `SAG_Setup`, `Stok`, `Malzeme_Akisi` ve `Yarimamul_Akisi`. Planlama özeti, saha iş emri, darboğaz, neden kodu, carry-out özeti ve uyarı sheet'leri bu ana tablolardan ve solver durumundan türetilen rapor sheet'leridir; ayrı ana çıktı tablosu olarak çoğaltılmaz.

### `Siparis` - Sipariş Sonuç Tablosu

Amaç: Her siparişin plan sonunda ne kadarının stoktan, ne kadarının üretimden, ne kadarının zamanında veya geç karşılandığını gösterir. Planlamacı bu tabloya bakarak hangi siparişin tamamen kapandığını, hangisinin geciktiğini, hangisinin açık kaldığını ve açık/gecikme varsa ana sebebin ne olduğunu görür.

| Kolon | Açıklama |
|---|---|
| Sipariş ID | Sistem içinde siparişi takip etmek için verilen benzersiz kayıt numarası. |
| Bitmiş Ürün Kodu | Sipariş edilen bitmiş ürün kodu. |
| Model Kodu | Bitmiş ürünün bağlı olduğu model kodu. |
| Sipariş Türü | Siparişin öncelik tipi: `OEM` veya `OYC`. |
| Termin Tarihi | Siparişin istenen teslim tarihi. |
| Sipariş Miktarı | Kullanıcının girdiği toplam sipariş miktarı. |
| Stoktan Karşılanan | Plan başlangıcındaki bitmiş ürün stokuyla karşılanan miktar. |
| Üretimle Karşılanan | Plan içinde üretilerek karşılanan miktar. |
| Zamanında Karşılanan | Termin tarihine kadar karşılanan miktar. |
| Geç Karşılanan | Termin tarihinden sonra karşılanan miktar. |
| Açık Kalan | Plan sonunda hâlâ karşılanamayan miktar. |
| Sipariş Durumu | Siparişin okunabilir sonucu: `Tam Zamanında`, `Kısmi Gecikmeli`, `Açık` veya `Stoktan Kapandı`. |
| Ana Neden | Gecikme veya açık miktar varsa ana sebep: malzeme, yarımamul, kapasite, MOQ, V710/LSF-12 veya SAG açılış gibi. |

### `Siparis_Karsilama` - Sipariş Karşılama Detay Tablosu

Amaç: Siparişlerin hangi stok veya üretim kaynağıyla kapatıldığını gösterir. `Siparis` tablosu siparişin özet sonucunu verir; `Siparis_Karsilama` tablosu ise bu sonucun hangi miktar-kaynak eşleşmeleriyle oluştuğunu açıklar. Bir sipariş birden fazla kaynaktan karşılanabilir; aynı üretim satırı da birden fazla siparişe dağıtılabilir.

Bir satır; bir siparişin belirli bir miktarının belirli bir kaynakla karşılanmasını temsil eder.

| Kolon | Açıklama |
|---|---|
| Karşılama ID | Bu karşılama satırının benzersiz takip numarasıdır. Diğer raporlarda bu satıra referans vermek için kullanılır. |
| Sipariş ID | Karşılanan siparişin ID'sidir. `Siparis` tablosundaki `Sipariş ID` alanıyla bağ kurar. |
| Bitmiş Ürün Kodu | Karşılanan bitmiş ürün kodudur. Sipariş ve kaynak ürününün aynı ürün olduğunu kontrol etmek için görünür tutulur. |
| Sipariş Türü | Siparişin öncelik tipidir: `OEM` veya `OYC`. OEM/OYC önceliğinin raporda okunmasını sağlar. |
| Termin Tarihi | Siparişin istenen teslim tarihidir. FIFO ve zamanında karşılama kontrolünde kullanılır. |
| Karşılama Miktarı | Bu satırda ilgili siparişe ayrılan miktardır. Aynı sipariş birden fazla satırla parça parça karşılanabilir. |
| Karşılama Tarihi | Bu miktarın sipariş için kullanılabilir kabul edildiği tarihtir. Başlangıç stokundan karşılanıyorsa plan başlangıç tarihi, üretimden karşılanıyorsa ilgili üretimin stok giriş tarihi yazılır. |
| Karşılama Vardiyası | Bu miktarın sipariş için kullanılabilir kabul edildiği vardiyadır. Başlangıç stokundan karşılanıyorsa plan başlangıç vardiyası, üretimden karşılanıyorsa ilgili üretimin stok giriş vardiyası yazılır. |
| Zamanında mı? | Karşılama zamanı sipariş terminine yetişiyorsa `Evet`, termin sonrasıysa `Hayır` yazılır. |
| Kaynak Tipi | Miktarın nereden geldiğini gösterir: `Başlangıç Stoku`, `Üretim` veya `Carry-Out Devri`. |
| Kaynak ID | Kaynak `Üretim` ise `Uretim` tablosundaki `Üretim ID` yazılır. Kaynak başlangıç stokuysa `InitialStock`, carry devriyse ilgili carry kaydı yazılır. |
| Kaynak Tarihi | Kaynağın bitmiş ürün stoku olarak kullanılabilir olduğu tarihtir. Üretim kaynağında `Uretim` tablosundaki stok giriş tarihiyle aynıdır. |
| Kaynak Vardiyası | Kaynağın bitmiş ürün stoku olarak kullanılabilir olduğu vardiyadır. Üretim kaynağında `Uretim` tablosundaki stok giriş vardiyasıyla aynıdır. |
| OEM Kapısı Uygun mu? | Bu satır OYC siparişi karşılıyorsa, aynı ürünün OEM siparişleri kapanmadan OYC'ye stok ayrılmadığını gösterir. OEM satırlarında `Evet` yazılır. |
| FIFO Uygun mu? | Aynı ürün ve aynı sipariş türünde daha erken terminli siparişler kapanmadan bu siparişe miktar ayrılmadığını gösterir. |

Bu tabloya gecikme nedeni, malzeme durumu veya darboğaz açıklaması yazılmaz. Bu tablo yalnız "hangi miktar, hangi siparişe, hangi kaynaktan gitti?" sorusunu cevaplar.

### `Uretim` - Üretim Sonuç Tablosu

Amaç: Planın ürettiği net üretim kararlarını gösterir. Bu tablo yorum veya neden açıklaması tablosu değildir; hangi vardiyada, hangi fırında, hangi segmentte, hangi model/ürün için ne kadar brüt ve net üretim planlandığını sayısal olarak gösterir.

Bir satır; bir vardiyada, bir fırında, bir segmentte, bir bitmiş ürün için planlanan üretimi temsil eder. Aynı fırın-vardiyada setup öncesi ve setup sonrası üretim varsa bunlar ayrı segmentler olarak ayrı satırlarda görünür. Aynı model altında birden fazla bitmiş ürün üretiliyorsa her bitmiş ürün ayrı satır olur.

| Kolon | Açıklama |
|---|---|
| Üretim ID | Her üretim satırı için sistemin verdiği benzersiz numaradır. Diğer raporlarda bu üretim satırına referans vermek için kullanılır. |
| Tarih | Üretimin başlatıldığı takvim günüdür. Bitmiş ürün stok girişi de bu tarihte oluşur. |
| Vardiya | Üretimin başlatıldığı vardiyadır. Bitmiş ürün stok girişi de bu vardiyada oluşur. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. Tarih/vardiya sıralamasında karışıklık olmaması için kullanılır. |
| Fırın Adı | Üretimin planlandığı fırındır. Örneğin `LSF04`, `LSF05`, `LSF-12`. |
| Fırın Tipi | Fırının çalışma tipidir: `SAG` veya `Pres`. Bu alan hangi kapasite kurallarının uygulandığını gösterir. |
| Segment No | Aynı fırın-vardiya içinde birden fazla üretim parçası varsa sırasını gösterir. Setup olmayan normal vardiyada genelde `1` olur. |
| Segment Tipi | Üretimin vardiya içindeki yerini gösterir: `Normal`, `Setup Öncesi`, `Setup Sonrası`, `Pres Normal`, `Pres Geçiş`. SAG geçiş vardiyalarında eski model üretimi ve yeni model üretimi ayrı segmentlerde görünebilir. |
| Kampanya ID | Üretimin yazıldığı fırın-model kampanyasının takip numarasıdır. MOQ sayacı, açık kampanya ve carry-out takibi bu kimlik üzerinden bağlanır. |
| Model Kodu | Üretilen bitmiş ürünün bağlı olduğu modeldir. Kampanya, MOQ, kalıp ve model değişimi kuralları bu model üzerinden takip edilir. |
| Bitmiş Ürün Kodu | Üretilen nihai ürün kodudur. Sipariş kapama ve bitmiş ürün stok girişi bu kod üzerinden yapılır. |
| Brüt Üretim Adedi | Randıman uygulanmadan önce planlanan üretim adedidir. Fırının kapasite kullanımı bu miktar üzerinden okunur. |
| Randıman | İlgili fırın-ürün eşleşmesi için kullanılan iyi ürün oranıdır. `furnace_product_yield` tablosundan gelir. |
| Net Üretim Adedi | Randıman sonrası beklenen iyi ürün adedidir. Bitmiş ürün stokuna giren ve sipariş kapamada kullanılabilen miktar budur. |
| Stok Giriş Tarihi | Net üretimin bitmiş ürün stokunda kullanılabilir olduğu tarihtir. Bu sistemde üretim tarihiyle aynıdır. |
| Stok Giriş Vardiyası | Net üretimin bitmiş ürün stokunda kullanılabilir olduğu vardiyadır. Bu sistemde üretim vardiyasıyla aynıdır. |
| SAG Kalıp Sayısı | SAG fırında bu ürün için kullanılan üretim kalıbı sayısıdır. Pres/`LSF-12` satırlarında `0` yazılır. |
| SAG Üretim Tur Sayısı | SAG fırında bu ürün için üretime ayrılan tur sayısıdır. Pres/`LSF-12` satırlarında `0` yazılır. |
| Pres Kapasite Limiti | `LSF-12` satırında kullanılan brüt kapasite limitidir. Normal Pres üretiminde `700`, model geçiş vardiyasında `350` olur. SAG satırlarında `0` yazılır. |
| Satın Alınan Malzeme Var mı? | Ürünün BOM'unda `Bileşen Malzeme Türü = Malzeme` satırı olup olmadığını gösterir. `Evet` ise satın alınan malzeme tüketimi ayrıca malzeme tablosunda takip edilir. |
| Malzeme Kullanım Tarihi | Satın alınan malzeme tüketiminin yazıldığı tarihtir. Malzeme düşümü üretimle aynı vardiyada yapıldığı için satın alınan malzemesi olan üründe üretim tarihiyle aynıdır; üründe satın alınan malzeme yoksa `Yok` yazılır. |
| Malzeme Kullanım Vardiyası | Satın alınan malzeme tüketiminin yazıldığı vardiyadır. Malzeme düşümü üretimle aynı vardiyada yapıldığı için satın alınan malzemesi olan üründe üretim vardiyasıyla aynıdır; üründe satın alınan malzeme yoksa `Yok` yazılır. |

### `Firin_Kullanim` - Fırın Vardiya Kullanım Tablosu

Amaç: Her fırının her vardiyada açık mı kapalı mı olduğunu, hangi kapasite kurallarıyla çalıştığını ve üretim/setup kapasitesinin nasıl kullanıldığını gösterir. Bu tablo üretim satırlarının fırın-vardiya seviyesindeki özetidir; ürün bazlı detay `Uretim` tablosunda, setup detayı ise `SAG_Setup` tablosunda tutulur.

Bir satır; bir fırının bir vardiyadaki kullanım durumunu temsil eder. SAG fırın açıksa fiziksel vagon kapasitesi boş bırakılmaz; üretim kalıbı, setup kalıbı, mecburi maket ve opsiyonel maket toplamı vagon kapasitesini doldurur. Açık SAG vardiyasında setup sonrası kalan tüm tur üretim turudur.

| Kolon | Açıklama |
|---|---|
| Tarih | Fırın kullanım durumunun geçerli olduğu takvim günüdür. |
| Vardiya | Fırın kullanım durumunun geçerli olduğu vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. Tarih/vardiya sıralamasında karışıklık olmaması için kullanılır. |
| Fırın Adı | Kullanımı raporlanan fırındır. Örneğin `LSF04`, `LSF05`, `LSF-12`. |
| Fırın Tipi | Fırının çalışma tipidir: `SAG` veya `Pres`. Bu alan hangi kapasite kolonlarının anlamlı olduğunu gösterir. |
| Fırın Durumu | Vardiyada fırının plan durumudur: `Açık` veya `Kapalı`. Kapalı fırında üretim, setup, tur ve kapasite kullanımı `0` olur. |
| Ana İş Tipi | Vardiyadaki ana işi özetler: `Üretim`, `Setup`, `Üretim + Setup` veya `Kapalı`. SAG geçiş vardiyalarında setup ve üretim aynı vardiyada birlikte görünebilir. |
| Aktif Model Sayısı | Vardiyada fırında bağlı veya üretimde kullanılan model sayısıdır. SAG fırında birden fazla olabilir; LSF-12 için normal vardiyada en fazla `1`, model geçiş (setup) vardiyasında ise `2` (eski ve yeni model) olabilir. |
| Üretilen Ürün Sayısı | Bu fırın-vardiyada üretim planlanan farklı bitmiş ürün sayısıdır. Detay satırlar `Uretim` tablosunda bulunur. |
| Toplam Brüt Üretim | Bu fırın-vardiyada planlanan toplam brüt üretim adedidir. Aynı fırın-vardiyadaki tüm `Uretim` satırlarının brüt toplamıdır. |
| Toplam Net Üretim | Bu fırın-vardiyada beklenen toplam iyi ürün adedidir. Aynı fırın-vardiyadaki tüm `Uretim` satırlarının net toplamıdır. |
| SAG Tur Kapasitesi | SAG fırında vardiyanın toplam tur kapasitesidir. Fırın kapalıysa veya fırın tipi `Pres` ise `0` yazılır. |
| SAG Setup Turu | SAG fırında bu vardiyada setup/model değişimi için harcanan tur sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Üretim Turu | SAG fırında üretime ayrılan tur sayısıdır. Açık SAG vardiyasında `SAG Tur Kapasitesi - SAG Setup Turu` olarak okunur; Pres satırlarında `0` yazılır. |
| SAG Vagon Kapasitesi | SAG fırının vardiyadaki fiziksel vagon/kalıp alanı kapasitesidir. Pres satırlarında `0` yazılır. |
| SAG Üretim Kalıbı Sayısı | SAG fırında üretim için kullanılan kalıp sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Setup Kalıbı Sayısı | SAG fırında setup sırasında bağlanan veya sökülen kalıpların aynı vardiyada kapladığı kalıp/vagon alanıdır. Pres satırlarında `0` yazılır. |
| SAG Mecburi Maket Sayısı | Model/fırın kuralı nedeniyle zorunlu kullanılan maket sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Opsiyonel Maket Sayısı | Açık SAG fırında üretim kalıbı, setup kalıbı ve mecburi maketten sonra kalan fiziksel alanı dolduran opsiyonel maket sayısıdır. Pres satırlarında `0` yazılır. |
| SAG Kullanılan Vagon | SAG fırında üretim kalıbı, setup kalıbı, mecburi maket ve opsiyonel maket toplamıdır. Açık SAG fırında `SAG Vagon Kapasitesi` değerine eşittir; Pres satırlarında `0` yazılır. |
| Pres Kapasite Limiti | `LSF-12` için vardiyada kullanılabilecek brüt Pres kapasitesidir. Normal vardiyada `700`, model geçiş vardiyasında `350` olur; SAG satırlarında `0` yazılır. |
| Pres Kullanılan Kapasite | `LSF-12` üzerinde bu vardiyada planlanan toplam brüt üretimdir. SAG satırlarında `0` yazılır. |
| İlgili Üretim ID'leri | Bu fırın-vardiya kullanımını oluşturan `Uretim` satırlarının ID listesidir. Aynı fırın-vardiyada birden fazla ürün veya segment varsa birden fazla ID bulunabilir. |

**LSF-12 Model Geçişi Kapasite Paylaşımı ve Raporlanması:**
LSF-12 Pres fırınında model değişimi yapılan vardiyada 4 saatlik setup (350 brüt kapasite kaybı) gerçekleşir ve geriye 350 adetlik brüt üretim kapasitesi kalır. Bu kapasite, sipariş kapatma veya kampanya tamamlama durumuna göre setup öncesindeki eski modele ve setup sonrasındaki yeni modele paylaştırılabilir. Bu paylaşım gerçekleştiğinde:
1. `Uretim` tablosunda o vardiyada LSF-12 için hem eski modelin ürünleri hem de yeni modelin ürünleri brüt/net miktarlarıyla iki ayrı satır halinde listelenir.
2. `Firin_Kullanim` tablosunda o vardiyada LSF-12 için `Aktif Model Sayısı` değeri `2` ve `Ana İş Tipi` değeri `Üretim + Setup` olarak raporlanır.
3. Çıktı Excel'indeki `Planlama_Ozet` ve `Uyarılar` kısımlarında *"LSF-12 model geçişi (X -> Y) gerçekleştirildi ve 350 brüt kapasite paylaştırıldı: X = [miktar], Y = [miktar]"* şeklinde detaylı bir log açıklaması üretilir.


### `SAG_Setup` - SAG Setup Detay Tablosu

Amaç: SAG fırınlarda model/kalıp değişiminin hangi vardiyada nasıl ilerlediğini, setup carry durumunu ve setup öncesi/sonrası ürün üretimini gösterir. Bu tablo yalnız SAG fırınlar içindir; Pres/`LSF-12` model geçişleri bu tabloda yer almaz.

Bir satır; bir SAG fırında bir vardiyada gerçekleşen tek bir kaynak-hedef setup hareketini veya önceki vardiyadan devreden aynı kaynak-hedef setup carry tamamlamasını temsil eder. Aynı fırın-vardiyada birden fazla setup hareketi varsa her kaynak-hedef anahtarı ayrı satır olur. Ürün bilgisi bu tabloda özet olarak yer alır; ürün bazlı detay miktarlar `Uretim` tablosundaki üretim ID'leri üzerinden takip edilir.

| Kolon | Açıklama |
|---|---|
| Setup ID | Setup kaydının benzersiz takip numarasıdır. Diğer raporlarda bu setup satırına referans vermek için kullanılır. |
| Tarih | Setup işleminin gerçekleştiği takvim günüdür. |
| Vardiya | Setup işleminin gerçekleştiği vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Fırın Adı | Setup yapılan SAG fırındır. Pres/`LSF-12` bu tabloda yer almaz. |
| Kaynak Model Kodu | Operasyon anahtarındaki sökülecek/çıkılan modeldir. Saf bağlama varsa `Yok` yazılır. |
| Hedef Model Kodu | Operasyon anahtarındaki bağlanacak/girilen modeldir. Saf söküm varsa `Yok` yazılır. |
| Vardiya Başı Setup Carry Turu | Bu vardiyaya önceki açık SAG vardiyasından veya plan başlangıcı carry bilgisinden bu kaynak-hedef anahtarı için devreden tamamlanmamış setup turudur. Carry yoksa `0` yazılır. |
| Yeni Setup İhtiyaç Turu | Bu vardiyada aynı kaynak-hedef anahtarı için başlatılan yeni setup ihtiyacıdır. Yeni setup başlatılmıyorsa `0` yazılır. |
| Tamamlanan Setup Turu | Bu vardiyada aynı kaynak-hedef anahtarında fiilen tamamlanan setup turudur. Vardiya tur kapasitesini aşamaz. |
| Vardiya Sonu Setup Carry Turu | Bu vardiya sonunda sonraki açık SAG vardiyasına aynı kaynak-hedef anahtarıyla devreden tamamlanmamış setup turudur. Carry kalmadıysa `0` yazılır. |
| Setup Tamamlandı mı? | Vardiya sonunda ilgili kaynak-hedef setup işi tamamen bittiyse `Evet`, aynı anahtarla sonraki açık SAG vardiyasına carry devrediyorsa `Hayır` yazılır. |
| Setup Only mi? | Bu fırın-vardiyada üretim yok, yalnız setup yapıldıysa `Evet`; setup öncesi veya sonrası üretim varsa `Hayır` yazılır. |
| Sökülen Kalıp Sayısı | Kaynak modelden bu satırda tamamlanan operasyonla sökülen kalıp sayısıdır. Kaynak `Yok` ise `0` yazılır. |
| Bağlanan Kalıp Sayısı | Hedef model için bu satırda tamamlanan operasyonla bağlanan kalıp sayısıdır. Hedef `Yok` ise `0` yazılır. |
| Setup Öncesi Ürün Kodları | Setup öncesinde eski modelden üretilen bitmiş ürün kodlarıdır. Birden fazla ürün varsa liste olarak yazılır; üretim yoksa `Yok` yazılır. |
| Setup Öncesi Üretim ID'leri | Setup öncesi üretimi oluşturan `Uretim` satırlarının ID listesidir. Üretim yoksa `Yok` yazılır. |
| Setup Öncesi Brüt Üretim | Setup öncesi segmentte eski model ürünlerinden planlanan toplam brüt üretimdir. Üretim yoksa `0` yazılır. |
| Setup Öncesi Net Üretim | Setup öncesi segmentte eski model ürünlerinden beklenen toplam net üretimdir. Üretim yoksa `0` yazılır. |
| Setup Sonrası Ürün Kodları | Setup tamamlandıktan sonra yeni modelden üretilen bitmiş ürün kodlarıdır. Birden fazla ürün varsa liste olarak yazılır; üretim yoksa `Yok` yazılır. |
| Setup Sonrası Üretim ID'leri | Setup sonrası üretimi oluşturan `Uretim` satırlarının ID listesidir. Üretim yoksa `Yok` yazılır. |
| Setup Sonrası Brüt Üretim | Setup sonrası segmentte yeni model ürünlerinden planlanan toplam brüt üretimdir. Üretim yoksa `0` yazılır. |
| Setup Sonrası Net Üretim | Setup sonrası segmentte yeni model ürünlerinden beklenen toplam net üretimdir. Üretim yoksa `0` yazılır. |
| Eski Model Üretim Turu | Setup öncesinde eski modele ayrılan üretim turu sayısıdır. Eski model üretimi yoksa `0` yazılır. |
| Yeni Model Üretim Turu | Setup sonrası yeni modele ayrılan üretim turu sayısıdır. Yeni model üretimi yoksa `0` yazılır. |
| Mecburi Maket Sayısı | Bu fırın-vardiyada model/fırın kuralı nedeniyle zorunlu kullanılan maket sayısıdır. |
| Opsiyonel Maket Sayısı | Açık SAG fırında fiziksel vagon kapasitesini doldurmak için kullanılan opsiyonel maket sayısıdır. |
| Kullanılan Vagon | Bu setup kaydının bağlı olduğu fırın-vardiyada kullanılan toplam vagon alanıdır. Açık SAG fırında vagon kapasitesine eşittir. |

### `Stok` - Bitmiş Ürün Stok Görünümü

Amaç: Bitmiş ürün stokunun plan açısından vardiya bazında nasıl değiştiğini gösterir. Bu tablo gerçek sevkiyat veya ERP stok hareketi iddiası taşımaz; planın kullanabileceği stok, üretimden gelen miktar ve siparişe bağlanan miktar ayrımını gösterir.

`Siparişe Bağlanan` fiziksel sevkiyat değildir. Bu alan, planın aynı miktarı başka sipariş için tekrar kullanmaması adına kullanılabilir stoktan düşülen tahsistir. Gerçek sevkiyat tarihi ayrıca takip edilecekse ayrı bir operasyon/ERP tablosu gerekir.

| Kolon | Açıklama |
|---|---|
| Tarih | Stok durumunun raporlandığı takvim günüdür. |
| Vardiya | Stok durumunun raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Bitmiş Ürün Kodu | Stok durumu izlenen bitmiş ürün kodudur. |
| Model Kodu | Bitmiş ürünün bağlı olduğu modeldir. `products` tablosundan gelir. |
| Vardiya Başı Stok | Bu vardiya başında planın kullanabildiği bitmiş ürün miktarıdır. |
| Üretimden Gelen | Bu vardiyada üretimden bitmiş ürün stokuna giren net miktardır. |
| Siparişe Bağlanan | Bu vardiyada sipariş karşılama planına bağlanan miktardır. Fiziksel sevkiyat anlamına gelmez. |
| Vardiya Sonu Kullanılabilir Stok | Plan açısından sonraki vardiyalarda kullanılabilecek kalan stoktur. |
| Azami Stok Miktarı | `products` tablosundaki ürün bazlı stok referans sınırıdır. Üretim yasağı değildir. |
| Azami Stok Aşımı | Vardiya sonu kullanılabilir stok azami stok miktarını aşıyorsa aşan miktardır; aşmıyorsa `0` yazılır. |
| İlgili Üretim ID'leri | Bu vardiyadaki üretim girişlerini oluşturan `Uretim` ID listesidir. Üretim yoksa `Yok` yazılır. |
| İlgili Karşılama ID'leri | Bu vardiyada stoktan veya üretimden siparişe bağlanan `Siparis_Karsilama` ID listesidir. Tahsis yoksa `Yok` yazılır. |

### `Malzeme_Akisi` - Satın Alınan Malzeme Akış Tablosu

Amaç: Satın alınan malzemelerin vardiya bazında giriş, kullanım ve kalan stok durumunu sade şekilde gösterir. Bu tablo yalnız `Bileşen Malzeme Türü = Malzeme` olan satın alınan bileşenler içindir; yarımamul hareketleri bu tabloda yer almaz.

Bir satır; bir malzemenin bir vardiyadaki stok akışını temsil eder. Malzeme tüketimi üretimle aynı vardiyada stoktan düşülür; bu tabloda `t+3` veya gecikmeli tüketim kolonu bulunmaz.

| Kolon | Açıklama |
|---|---|
| Tarih | Malzeme akışının raporlandığı takvim günüdür. |
| Vardiya | Malzeme akışının raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Malzeme Kodu | Satın alınan malzeme kodudur. `bom` ve `stock` tablolarındaki malzeme koduyla aynı olmalıdır. |
| Vardiya Başı Stok | Vardiya başında kullanılabilir olan malzeme miktarıdır. |
| Gelen Miktar | Bu vardiyada `material_arrivals` üzerinden kullanılabilir hale gelen malzeme miktarıdır. Teslimat yoksa `0` yazılır. |
| Kullanılan Miktar | Bu vardiyada başlatılan üretimler için aynı vardiyada stoktan düşülen malzeme miktarıdır. Kullanım yoksa `0` yazılır. |
| Vardiya Sonu Stok | Gelen miktar ve kullanılan miktar sonrası kalan malzeme stokudur. Negatif olamaz. |
| İlgili Üretim ID'leri | Kullanılan miktarı oluşturan `Uretim` satırlarının ID listesidir. Kullanım yoksa `Yok` yazılır. |

### `Yarimamul_Akisi` - Yarımamul Akış Tablosu

Amaç: Yarımamullerin vardiya bazında stok, kullanım ve yeni hazırlık durumunu sade şekilde gösterir. Bu tablo yalnız `Bileşen Malzeme Türü = Yarımamul` olan bileşenler içindir; satın alınan malzemeler bu tabloda yer almaz.

Bir satır; bir yarımamulün bir vardiyadaki stok akışını temsil eder. Yarımamul hazırlığı 2 vardiya sonra kullanılabilir hale gelir, ancak bu tabloda hazırlıktan gelen miktar ayrı kolon olarak gösterilmez; kullanıcı vardiya başı ve vardiya sonu stokla toplam durumu görür.

| Kolon | Açıklama |
|---|---|
| Tarih | Yarımamul akışının raporlandığı takvim günüdür. |
| Vardiya | Yarımamul akışının raporlandığı vardiyadır. |
| Vardiya Sıra No | Plan ufku içindeki kronolojik vardiya numarasıdır. |
| Yarımamul Kodu | Yarımamul kodudur. `bom` ve `stock` tablolarındaki yarımamul koduyla aynı olmalıdır. |
| Vardiya Başı Stok | Vardiya başında kullanılabilir olan yarımamul miktarıdır. Önceki vardiyalarda başlatılıp bu vardiyada olgunlaşan hazırlık varsa bu stok içinde görünür. |
| Kullanılan Miktar | Bu vardiyada başlatılan üretimler için stoktan düşülen yarımamul miktarıdır. Kullanım yoksa `0` yazılır. |
| Hazırlık Başlatılan Miktar | Bu vardiyada başlatılan yeni yarımamul hazırlığıdır. Bu miktar aynı vardiyada kullanılabilir stok sayılmaz; 2 vardiya sonra stokta görünür. |
| Vardiya Sonu Stok | Kullanım sonrası kalan kullanılabilir yarımamul stokudur. Negatif olamaz. |
| İlgili Üretim ID'leri | Kullanılan miktarı oluşturan `Uretim` satırlarının ID listesidir. Kullanım yoksa `Yok` yazılır. |

## Kullanım Senaryosu

Planlamacı gün başında veya plan revizyonu gerektiğinde girdi Excel workbook'unu açar. Excel içinde yeni siparişleri, sipariş güncellemelerini, stok düzeltmelerini, ürün ağacı değişikliklerini, ürün-master kayıtlarını, fırın/kalıp/randıman verilerini, SAG açılış sayılarını ve yoldaki malzeme teslimatlarını günceller. İlk kurulum veya bilinçli reset dışında planlamacı başlangıç fırın durumunu elle yönetmez.

Planlamacı proje klasöründeki Python scriptini çalıştırır. Standart kullanım `python run_plan.py --input girdi.xlsx --output cikti_plan.xlsx` komutudur; bunun için ayrıca çift tıklanabilir bir `.bat` dosyası da hazırlanabilir. Script önce veri ön kontrolünü yapar. Eksik veya hatalı veri varsa optimizasyon başlamaz; çıktı Excelinde `Precheck_Hatalari` sheet'i oluşur ve kullanıcı hangi tablo, satır, kolon ve kuralın düzeltilmesi gerektiğini görür. Planlamacı hatayı girdi Excelinde düzeltir ve scripti tekrar çalıştırır.

Ön kontroller geçerse plan otomatik üretilir ve çıktı Excel workbook'u yazılır. Planlamacı ilk olarak `Planlama_Ozet` sheet'ine bakar: zamanında kapanan OEM/OYC miktarı, geciken veya açık kalan siparişler, ana darboğazlar, kritik malzeme/yarımamul uyarıları ve kapasite uyarıları burada özetlenir. Siparişler veri veya kapasite kısıtları nedeniyle hiçbir ufukta tamamen kapanamıyorsa sistem açık kalan miktarı neden koduyla çıktı Exceline yazar.

Sonra planlamacı detay sheet'lere iner. `Siparis` ve `Siparis_Karsilama` ile hangi siparişin stoktan, üretimden veya açık kaldığını kontrol eder. `Uretim`, `Firin_Kullanim` ve `SAG_Setup` ile vardiya bazlı üretim ve fırın planını inceler. `Stok`, `Malzeme_Akisi` ve `Yarimamul_Akisi` ile planın stok, satın alınan malzeme ve yarımamul tarafında uygulanabilir olup olmadığını doğrular. Geciken veya açık kalan bir siparişte neden kodunu okuyarak malzeme, yarımamul, kapasite, MOQ, V710/LSF-12 veya SAG açılış etkisini görür.

Saha ekibi aynı planın matematiksel detayını değil, çıktı Excelindeki `Saha_Is_Emri`, `Firin_Durum_Ozeti` ve ilgili vardiya sheet'lerini kullanır. Ustabaşı hangi vardiyada hangi fırının açık olduğunu, hangi model/ürünün üretileceğini, kaç kalıp ve kaç tur kullanılacağını, setup olup olmadığını, mecburi/opsiyonel maket durumunu ve malzeme-yarımamul hazırlık uyarılarını görür.

Gün içinde sipariş, stok veya yoldaki teslimat bilgisi değişirse planlamacı girdi Excelini günceller ve scripti tekrar çalıştırır. Yeni çıktı dosyası farklı dosya adıyla veya zaman damgasıyla üretilir; böylece eski plan sessizce ezilmez. Planlamacı yeni `Planlama_Ozet` ve kritik uyarı sheet'lerini kontrol ederek hangi planın sahaya verileceğine karar verir.
